import json
import os
import random
import re
import socket
import string
import subprocess
import sys
from typing import Any, Dict, List, Optional, Tuple, Union

try:
    import psutil
except ImportError:
    psutil = None

import Details
from LoggerManager import DEFAULT_LOGGER, OperationState

try:
    import winreg
except ImportError:
    winreg = None


class MOFManager:
    """
    Safe Hardware, WMI, SMBIOS, and Network Adapter Inspection & Management Layer.
    - Forces UTF-8 output encoding in PowerShell (`[Console]::OutputEncoding = [System.Text.Encoding]::UTF8`)
      so Arabic Windows interface names (e.g., `شبكة Wi-Fi` or `إيثرنت`) never turn into `??¬ è. Wi-Fi`.
    """

    VIRTUAL_ADAPTER_KEYWORDS = (
        "vmware",
        "virtualbox",
        "vbox",
        "hyper-v",
        "vethernet",
        "docker",
        "tap-windows",
        "tap adapter",
        "tun",
        "wireguard",
        "wintun",
        "nordlynx",
        "protonvpn",
        "openvpn",
        "loopback",
        "wan miniport",
        "teredo",
        "isatap",
        "npcap",
    )

    PROTECTED_CIM_CLASSES = (
        "Win32_Processor",
        "Win32_BIOS",
        "Win32_BaseBoard",
        "Win32_ComputerSystemProduct",
        "Win32_SystemEnclosure",
        "Win32_DiskDrive",
        "Win32_PhysicalMemory",
        "Win32_VideoController",
    )

    NETWORK_CLASS_KEY = r"SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}"

    def __init__(self) -> None:
        self.last_error: Optional[str] = None

    def run_hidden(self, cmd: Union[str, List[str]], timeout: int = 15) -> subprocess.CompletedProcess:
        use_shell = isinstance(cmd, str)
        return subprocess.run(
            cmd,
            shell=use_shell,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            check=False,
            **Details.get_subprocess_kwargs(),
        )

    def run_powershell(self, script: str, timeout: int = 15) -> Union[Dict[str, Any], List[Any]]:
        """
        Execute a PowerShell script with explicit UTF-8 output encoding so localized Arabic/Unicode
        adapter names and hardware descriptions are never corrupted into question marks (`??`).
        """
        utf8_script = f"[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; {script}"
        try:
            result = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    utf8_script,
                ],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                check=True,
                shell=False,
                **Details.get_subprocess_kwargs(),
            )
            stdout = (result.stdout or "").strip()
            if not stdout:
                return {}
            return json.loads(stdout)
        except subprocess.TimeoutExpired as e:
            self.last_error = f"PowerShell timeout after {timeout}s"
            DEFAULT_LOGGER.log_operation(
                operation_name="PowerShellQuery",
                target_item=script[:80],
                result=OperationState.FAILED.value,
                error_message=self.last_error,
                exception=e,
            )
            return {}
        except (subprocess.CalledProcessError, json.JSONDecodeError, FileNotFoundError) as e:
            self.last_error = f"PowerShell query error: {e}"
            DEFAULT_LOGGER.log_operation(
                operation_name="PowerShellQuery",
                target_item=script[:80],
                result=OperationState.FAILED.value,
                error_message=self.last_error,
                exception=e,
            )
            return {}
        except Exception as e:
            self.last_error = f"Unexpected PowerShell error: {e}"
            DEFAULT_LOGGER.log_operation(
                operation_name="PowerShellQuery",
                target_item=script[:80],
                result=OperationState.FAILED.value,
                error_message=self.last_error,
                exception=e,
            )
            return {}

    @staticmethod
    def _clean_display_text(val: Any) -> str:
        """Strip invisible directional marks (LRM/RLM) and leading garbled question-mark artifacts."""
        if val is None:
            return ""
        s = str(val).replace("\u200f", "").replace("\u200e", "").replace("\ufeff", "").strip()
        # Clean leading '??' OEM codepage artifacts if any came from old cached strings
        s = re.sub(r"^[?\ufffd]+[\s¬è.]*", "", s).strip()
        return s or str(val).strip()

    @staticmethod
    def _first_dict(data: Union[Dict[str, Any], List[Any], None]) -> Dict[str, Any]:
        if isinstance(data, dict):
            return data
        if isinstance(data, list) and data and isinstance(data[0], dict):
            return data[0]
        return {}

    @staticmethod
    def _as_dict_list(data: Union[Dict[str, Any], List[Any], None]) -> List[Dict[str, Any]]:
        if isinstance(data, dict) and data:
            return [data]
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
        return []

    def diagnose_wmi_service(self) -> Dict[str, Any]:
        diag: Dict[str, Any] = {
            "service_name": "Winmgmt",
            "service_running": False,
            "repository_consistent": False,
            "repository_message": "Not checked",
            "cim_query_ok": False,
            "errors": [],
        }

        if not sys.platform.startswith("win"):
            diag["repository_message"] = "Non-Windows environment (simulated/mock mode)"
            return diag

        try:
            svc_res = self.run_powershell(
                "Get-Service -Name Winmgmt | Select-Object Name, Status, StartType | ConvertTo-Json",
                timeout=10,
            )
            svc_dict = self._first_dict(svc_res)
            status_val = svc_dict.get("Status")
            diag["service_running"] = status_val in (4, "4", "Running")
        except Exception as e:
            diag["errors"].append(f"Service check error: {e}")

        try:
            repo_proc = self.run_hidden(["winmgmt", "/verifyrepository"], timeout=15)
            repo_out = ((repo_proc.stdout or "") + " " + (repo_proc.stderr or "")).strip()
            diag["repository_message"] = repo_out or f"ExitCode={repo_proc.returncode}"
            diag["repository_consistent"] = repo_proc.returncode == 0 and (
                "not consistent" not in repo_out.lower() and "inconsistent" not in repo_out.lower()
            )
        except Exception as e:
            diag["errors"].append(f"Repository verification error: {e}")

        bios_test = self._first_dict(self.get_hardware_info("bios"))
        diag["cim_query_ok"] = bool(bios_test.get("SerialNumber") or bios_test.get("SMBIOSBIOSVersion"))
        if not diag["cim_query_ok"]:
            diag["errors"].append("Test query to Win32_BIOS returned empty or incomplete data.")

        return diag

    def get_hardware_info(self, category: str) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        ps_scripts = {
            "computer_system": "Get-CimInstance Win32_ComputerSystemProduct | Select-Object Name, Vendor, Version, UUID, IdentifyingNumber | ConvertTo-Json",
            "bios": "Get-CimInstance Win32_BIOS | Select-Object SMBIOSBIOSVersion, Manufacturer, Name, SerialNumber | ConvertTo-Json",
            "processor": "Get-CimInstance Win32_Processor | Select-Object DeviceID, Name, ProcessorId, PartNumber, SerialNumber | ConvertTo-Json",
            "baseboard": "Get-CimInstance Win32_BaseBoard | Select-Object Manufacturer, Product, SerialNumber, Name | ConvertTo-Json",
            "system_enclosure": "Get-CimInstance Win32_SystemEnclosure | Select-Object Manufacturer, LockPresent, SerialNumber, SMBIOSAssetTag, SecurityStatus | ConvertTo-Json",
            "disk_drive": "Get-CimInstance Win32_DiskDrive | Select-Object DeviceID, SerialNumber, Model, Caption, MediaType, InterfaceType | ConvertTo-Json",
            "physical_memory": "Get-CimInstance Win32_PhysicalMemory | Select-Object Tag, SerialNumber, Manufacturer, PartNumber | ConvertTo-Json",
            "video_controller": "Get-CimInstance Win32_VideoController | Select-Object Name, Description, PNPDeviceID | ConvertTo-Json",
        }

        if category not in ps_scripts:
            return {}

        raw = self.run_powershell(ps_scripts[category])
        if category in ("disk_drive", "physical_memory", "video_controller"):
            return self._as_dict_list(raw)
        return self._first_dict(raw)

    def get_hardware_vs_wmi_comparison(self) -> Dict[str, Any]:
        wmi_serials = self.get_all_serials()
        firmware_data: Dict[str, Any] = {
            "source": "Firmware / Registry HardwareConfig & Storage Device Descriptor",
            "SystemBIOSVersion": "N/A",
            "BaseBoardProduct": "N/A",
            "BIOSVendor": "N/A",
            "BIOSReleaseDate": "N/A",
            "HardwareConfigUUID": "N/A",
        }

        if winreg is not None:
            bios_reg_path = r"HARDWARE\DESCRIPTION\System\BIOS"
            for val_name in ("SystemBIOSVersion", "BaseBoardProduct", "BIOSVendor", "BIOSReleaseDate", "SystemManufacturer", "SystemProductName"):
                try:
                    k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, bios_reg_path, 0, winreg.KEY_READ)
                    v, _ = winreg.QueryValueEx(k, val_name)
                    winreg.CloseKey(k)
                    firmware_data[val_name] = v
                except Exception:
                    pass

            hw_cfg_path = r"SYSTEM\HardwareConfig"
            try:
                k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, hw_cfg_path, 0, winreg.KEY_READ)
                v, _ = winreg.QueryValueEx(k, "LastConfig")
                winreg.CloseKey(k)
                firmware_data["HardwareConfigUUID"] = v
            except Exception:
                pass

        return {
            "wmi_layer": {
                "note": "Values reported by WMI (root\\CIMv2 Win32_* classes)",
                "data": wmi_serials,
            },
            "real_hardware_firmware": firmware_data,
        }

    @classmethod
    def is_virtual_adapter(cls, name: str, description: str = "", pnp_device_id: str = "") -> bool:
        combined = f"{name} {description} {pnp_device_id}".lower()
        if any(keyword in combined for keyword in cls.VIRTUAL_ADAPTER_KEYWORDS):
            return True
        if pnp_device_id.upper().startswith(("ROOT\\", "SWD\\")):
            return True
        return False

    def get_detailed_network_adapters(self, include_virtual: bool = False) -> List[Dict[str, Any]]:
        adapters: List[Dict[str, Any]] = []
        ps_query = (
            "Get-CimInstance Win32_NetworkAdapter -Filter 'PhysicalAdapter=True' | "
            "Select-Object DeviceID, Name, NetConnectionID, MACAddress, PNPDeviceID, "
            "AdapterType, NetEnabled, Manufacturer, GUID | ConvertTo-Json"
        )
        wmi_adapters = self._as_dict_list(self.run_powershell(ps_query))

        if wmi_adapters:
            for item in wmi_adapters:
                raw_name = str(item.get("Name") or "")
                raw_net_id = str(item.get("NetConnectionID") or raw_name)
                name = self._clean_display_text(raw_name)
                net_id = self._clean_display_text(raw_net_id)
                pnp_id = str(item.get("PNPDeviceID") or "")
                device_id = str(item.get("DeviceID") or "")
                is_virt = self.is_virtual_adapter(net_id, name, pnp_id)
                if is_virt and not include_virtual:
                    continue

                lower_combined = f"{net_id} {name}".lower()
                if "bluetooth" in lower_combined or pnp_id.upper().startswith("BTH\\"):
                    adapter_kind = "Bluetooth"
                elif any(k in lower_combined for k in ("wi-fi", "wifi", "wireless", "wlan", "802.11")):
                    adapter_kind = "Wi-Fi"
                else:
                    adapter_kind = "Ethernet"

                reg_support = self.check_adapter_registry_support(device_id, adapter_name=name)
                adapters.append(
                    {
                        "device_id": device_id,
                        "name": name,
                        "net_connection_id": net_id,
                        "raw_net_connection_id": raw_net_id,
                        "mac_address": str(item.get("MACAddress") or "Unknown").replace("-", ":"),
                        "pnp_device_id": pnp_id,
                        "adapter_kind": adapter_kind,
                        "is_virtual": is_virt,
                        "net_enabled": bool(item.get("NetEnabled", False)),
                        "guid": str(item.get("GUID") or ""),
                        "supports_mac_override": reg_support.get("supported", False),
                        "registry_subkey": reg_support.get("subkey_path"),
                        "current_override": reg_support.get("current_override"),
                    }
                )
            return adapters

        if psutil is not None:
            addrs = psutil.net_if_addrs()
            stats = psutil.net_if_stats()
            af_link = getattr(psutil, "AF_LINK", -1)
            for idx, (iface, addr_list) in enumerate(addrs.items()):
                clean_iface = self._clean_display_text(iface)
                is_virt = self.is_virtual_adapter(clean_iface)
                if is_virt and not include_virtual:
                    continue
                mac_val = None
                for addr in addr_list:
                    if getattr(addr, "family", None) == af_link and getattr(addr, "address", None):
                        candidate = addr.address.replace("-", ":").upper()
                        if candidate and candidate != "00:00:00:00:00:00":
                            mac_val = candidate
                            break
                if not mac_val:
                    continue
                lower_iface = clean_iface.lower()
                if "bluetooth" in lower_iface or "bth" in lower_iface:
                    kind = "Bluetooth"
                elif any(w in lower_iface for w in ("wi-fi", "wifi", "wlan", "wireless")):
                    kind = "Wi-Fi"
                else:
                    kind = "Ethernet"
                st = stats.get(iface)
                adapters.append(
                    {
                        "device_id": str(idx),
                        "name": clean_iface,
                        "net_connection_id": clean_iface,
                        "raw_net_connection_id": iface,
                        "mac_address": mac_val,
                        "pnp_device_id": "",
                        "adapter_kind": kind,
                        "is_virtual": is_virt,
                        "net_enabled": bool(st.isup) if st else True,
                        "guid": "",
                        "supports_mac_override": False,
                        "registry_subkey": None,
                        "current_override": None,
                    }
                )
        return adapters

    def check_adapter_registry_support(self, device_id: str, adapter_name: str = "") -> Dict[str, Any]:
        info: Dict[str, Any] = {
            "supported": False,
            "subkey_path": None,
            "driver_desc": None,
            "current_override": None,
            "has_ndi_param": False,
            "reason": "Registry not available or adapter key not found",
        }
        if winreg is None or not str(device_id).isdigit():
            return info

        padded_candidates = [f"{int(device_id):04d}"]
        for candidate in padded_candidates:
            subkey_path = f"{self.NETWORK_CLASS_KEY}\\{candidate}"
            try:
                sk = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, subkey_path, 0, winreg.KEY_READ)
                try:
                    driver_desc, _ = winreg.QueryValueEx(sk, "DriverDesc")
                    info["driver_desc"] = driver_desc
                    info["subkey_path"] = subkey_path
                    try:
                        curr_mac, _ = winreg.QueryValueEx(sk, "NetworkAddress")
                        info["current_override"] = curr_mac
                    except FileNotFoundError:
                        info["current_override"] = None

                    try:
                        ndi_sk = winreg.OpenKey(
                            winreg.HKEY_LOCAL_MACHINE,
                            f"{subkey_path}\\Ndi\\params\\NetworkAddress",
                            0,
                            winreg.KEY_READ,
                        )
                        winreg.CloseKey(ndi_sk)
                        info["has_ndi_param"] = True
                    except FileNotFoundError:
                        info["has_ndi_param"] = False

                    info["supported"] = True
                    info["reason"] = "Driver class key verified"
                    return info
                finally:
                    winreg.CloseKey(sk)
            except FileNotFoundError:
                continue
            except PermissionError as e:
                info["reason"] = f"Permission denied reading adapter registry key: {e}"
                return info
            except Exception as e:
                info["reason"] = f"Error checking adapter registry key: {e}"
                return info

        return info

    def get_network_info(self) -> Dict[str, str]:
        macs: Dict[str, str] = {}
        for adapter in self.get_detailed_network_adapters(include_virtual=False):
            label = adapter.get("net_connection_id") or adapter.get("name") or "Unknown"
            mac = adapter.get("mac_address")
            if mac and mac != "Unknown":
                macs[label] = mac
        return macs

    def get_partition_serials(self) -> List[Dict[str, Any]]:
        script = (
            "Get-CimInstance Win32_LogicalDisk | "
            "Select-Object DeviceID, VolumeName, FileSystem, DriveType, VolumeSerialNumber, Size, FreeSpace | "
            "ConvertTo-Json"
        )
        return self._as_dict_list(self.run_powershell(script))

    def get_hostname(self) -> str:
        return socket.gethostname()

    def generate_serial(self, original: str, is_uuid: bool = False, is_upper: bool = False) -> str:
        if is_uuid:
            chars = "0123456789ABCDEF"
            return (
                f"{''.join(random.choices(chars, k=8))}-"
                f"{''.join(random.choices(chars, k=4))}-"
                f"{''.join(random.choices(chars, k=4))}-"
                f"{''.join(random.choices(chars, k=4))}-"
                f"{''.join(random.choices(chars, k=12))}"
            )
        chars = (string.ascii_uppercase if is_upper else string.ascii_letters) + string.digits
        length = len(original) if original and len(original) >= 4 else 10
        return "".join(random.choices(chars, k=length))

    def generate_disk_serial(self) -> str:
        def random_hex_segment(length: int = 4) -> str:
            return "".join(random.choices("0123456789ABCDEF", k=length))
        return "_".join(random_hex_segment(4) for _ in range(8))

    def generate_gpu_serial(self, original_serial: str) -> str:
        vendor_ids = {"8086": "INTEL", "10DE": "NVIDIA", "1002": "AMD"}
        vendor_id_map = {"INTEL": "8086", "NVIDIA": "10DE", "AMD": "1002"}

        pattern = r"^PCI\\+VEN_([0-9A-Fa-f]{4})&DEV_[0-9A-Fa-f]{4}&SUBSYS_[0-9A-Fa-f]{8}&REV_[0-9A-Fa-f]{2}\\+[0-9]&[0-9A-Fa-f]{8}&[0-9]&[0-9]{2}([0-9]{2})?$"
        match = re.match(pattern, original_serial or "")
        if not match:
            raise ValueError("Invalid GPU PNPDeviceID format.")

        extracted_vendor_id = match.group(1).upper()
        detected_vendor = vendor_ids.get(extracted_vendor_id, "UNKNOWN")
        vendor_id = vendor_id_map.get(detected_vendor, extracted_vendor_id)

        device_id = "".join(random.choices("0123456789ABCDEF", k=4))
        subsystem_id = "".join(random.choices("0123456789ABCDEF", k=8))
        revision_id = "".join(random.choices("0123456789ABCDEF", k=2))
        hw_p1 = random.randint(0, 9)
        hw_p2 = "".join(random.choices("0123456789ABCDEF", k=8))
        hw_p3 = random.randint(0, 9)
        hw_p4 = "".join(random.choices(string.digits, k=random.choice([2, 4])))
        return f"PCI\\VEN_{vendor_id}&DEV_{device_id}&SUBSYS_{subsystem_id}&REV_{revision_id}\\{hw_p1}&{hw_p2}&{hw_p3}&{hw_p4}"

    @classmethod
    def validate_mof_content(cls, content: str) -> Tuple[bool, str]:
        if not content or not isinstance(content, str) or not content.strip():
            return False, "MOF content is empty."

        if "#pragma namespace" not in content:
            return False, "Missing #pragma namespace directive in MOF content."

        if content.count("{") != content.count("}") or content.count("{") == 0:
            return False, "Unbalanced braces in MOF content."

        for protected_cls in cls.PROTECTED_CIM_CLASSES:
            class_redef_pattern = rf"\bclass\s+{re.escape(protected_cls)}\b"
            if re.search(class_redef_pattern, content, re.IGNORECASE):
                return (
                    False,
                    f"Blocked unsafe MOF class redefinition of '{protected_cls}'. "
                    "Redefining core CIMv2 classes via mofcomp corrupts the WMI repository "
                    "and only spoofs the WMI presentation layer without changing real hardware.",
                )

        return True, "MOF syntax and safety validation passed."

    def create_mof_file(self, content: str, allow_unsafe_mof: bool = False) -> bool:
        is_valid, reason = self.validate_mof_content(content)
        if not is_valid and not allow_unsafe_mof:
            self.last_error = reason
            DEFAULT_LOGGER.log_operation(
                operation_name="MOFCompileBlocked",
                target_item="root\\CIMv2",
                result="Blocked",
                error_message=reason,
            )
            return False

        wmi_diag = self.diagnose_wmi_service()
        if not wmi_diag.get("service_running") or not wmi_diag.get("repository_consistent"):
            self.last_error = (
                f"WMI Service/Repository check failed before mofcomp: {wmi_diag.get('repository_message')}"
            )
            DEFAULT_LOGGER.log_operation(
                operation_name="MOFCompileAborted",
                target_item="Winmgmt",
                result=OperationState.FAILED.value,
                error_message=self.last_error,
            )
            return False

        mof_path = None
        try:
            import tempfile
            fd, mof_path = tempfile.mkstemp(suffix=".mof", text=True)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(content)

            check_res = self.run_hidden(["mofcomp", "-check", mof_path], timeout=15)
            if check_res.returncode != 0:
                self.last_error = f"mofcomp -check failed: {check_res.stdout} {check_res.stderr}".strip()
                DEFAULT_LOGGER.log_operation(
                    operation_name="MOFSyntaxCheck",
                    target_item=mof_path,
                    result=OperationState.FAILED.value,
                    error_message=self.last_error,
                )
                return False

            comp_res = self.run_hidden(["mofcomp", mof_path], timeout=20)
            if comp_res.returncode != 0:
                self.last_error = f"mofcomp execution failed: {comp_res.stdout} {comp_res.stderr}".strip()
                DEFAULT_LOGGER.log_operation(
                    operation_name="MOFCompile",
                    target_item=mof_path,
                    result=OperationState.FAILED.value,
                    error_message=self.last_error,
                )
                return False

            DEFAULT_LOGGER.log_operation(
                operation_name="MOFCompile",
                target_item="root\\CIMv2",
                result=OperationState.COMPLETED.value,
            )
            return True
        except Exception as e:
            self.last_error = str(e)
            DEFAULT_LOGGER.log_operation(
                operation_name="MOFCompile",
                target_item="root\\CIMv2",
                result=OperationState.FAILED.value,
                error_message=str(e),
                exception=e,
            )
            return False
        finally:
            if mof_path and os.path.exists(mof_path):
                try:
                    os.remove(mof_path)
                except OSError:
                    pass

    def spoof_smbios_serials(
        self,
        cpu_info: Optional[Dict[str, Any]] = None,
        cs_info: Optional[Dict[str, Any]] = None,
        baseboard_info: Optional[Dict[str, Any]] = None,
        enclosure_info: Optional[Dict[str, Any]] = None,
        bios_info: Optional[Dict[str, Any]] = None,
    ) -> bool:
        self.last_error = (
            "SMBIOS/BIOS WMI class redefinition is disabled to protect WMI repository integrity "
            "and comply with system safety policy (BIOS/SMBIOS hardware data cannot be safely modified via MOF)."
        )
        DEFAULT_LOGGER.log_operation(
            operation_name="SpoofSMBIOSBlocked",
            target_item="Win32_BIOS/Win32_BaseBoard/Win32_Processor",
            result="Blocked",
            error_message=self.last_error,
        )
        return False

    def spoof_hard_disks(self, disks: Optional[Any] = None) -> bool:
        self.last_error = (
            "Win32_DiskDrive MOF class redefinition is disabled to preserve WMI repository integrity."
        )
        DEFAULT_LOGGER.log_operation(
            operation_name="SpoofDiskDriveBlocked",
            target_item="Win32_DiskDrive",
            result="Blocked",
            error_message=self.last_error,
        )
        return False

    def spoof_memory(self, memory_modules: Optional[Any] = None) -> bool:
        self.last_error = (
            "Win32_PhysicalMemory MOF class redefinition is disabled to preserve WMI repository integrity."
        )
        DEFAULT_LOGGER.log_operation(
            operation_name="SpoofMemoryBlocked",
            target_item="Win32_PhysicalMemory",
            result="Blocked",
            error_message=self.last_error,
        )
        return False

    def spoof_gpus(self) -> bool:
        self.last_error = (
            "Win32_VideoController MOF class redefinition is disabled to preserve WMI repository integrity."
        )
        DEFAULT_LOGGER.log_operation(
            operation_name="SpoofGPUBlocked",
            target_item="Win32_VideoController",
            result="Blocked",
            error_message=self.last_error,
        )
        return False

    def restore_originals(self) -> Tuple[bool, str]:
        cim_mof = r"C:\Windows\System32\wbem\cimwin32.mof"
        if not os.path.exists(cim_mof):
            msg = f"System MOF file not found at {cim_mof}"
            self.last_error = msg
            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreStandardCIMv2",
                target_item=cim_mof,
                result=OperationState.FAILED.value,
                error_message=msg,
            )
            return False, msg

        try:
            res = self.run_hidden(["mofcomp", cim_mof], timeout=30)
            if res.returncode == 0:
                DEFAULT_LOGGER.log_operation(
                    operation_name="RestoreStandardCIMv2",
                    target_item=cim_mof,
                    result=OperationState.COMPLETED.value,
                    restore_status="Restored",
                )
                return True, "Standard CIMv2 WMI definitions restored successfully."
            msg = f"mofcomp cimwin32.mof failed (code {res.returncode}): {res.stderr or res.stdout}".strip()
            self.last_error = msg
            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreStandardCIMv2",
                target_item=cim_mof,
                result=OperationState.FAILED.value,
                error_message=msg,
            )
            return False, msg
        except Exception as e:
            self.last_error = str(e)
            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreStandardCIMv2",
                target_item=cim_mof,
                result=OperationState.FAILED.value,
                error_message=str(e),
                exception=e,
            )
            return False, str(e)

    def get_all_serials(self) -> Dict[str, Any]:
        serials_data: Dict[str, Any] = {}
        try:
            bios_info = self._first_dict(self.get_hardware_info("bios"))
            serials_data["BIOS"] = {
                "SMBIOSBIOSVersion": bios_info.get("SMBIOSBIOSVersion", "Unknown"),
                "Manufacturer": bios_info.get("Manufacturer", "Unknown"),
                "Name": bios_info.get("Name", "Unknown"),
                "SerialNumber": bios_info.get("SerialNumber", "Unknown"),
            }

            baseboard_info = self._first_dict(self.get_hardware_info("baseboard"))
            serials_data["BaseBoard"] = {
                "Manufacturer": baseboard_info.get("Manufacturer", "Unknown"),
                "Product": baseboard_info.get("Product", "Unknown"),
                "SerialNumber": baseboard_info.get("SerialNumber", "Unknown"),
                "Name": baseboard_info.get("Name", "Unknown"),
            }

            processor_info = self._first_dict(self.get_hardware_info("processor"))
            serials_data["Processor"] = {
                "DeviceID": processor_info.get("DeviceID", "CPU0"),
                "Name": processor_info.get("Name", "Unknown"),
                "ProcessorId": processor_info.get("ProcessorId", "Unknown"),
                "SerialNumber": processor_info.get("SerialNumber", "Unknown"),
                "PartNumber": processor_info.get("PartNumber", "Unknown"),
            }

            cs_info = self._first_dict(self.get_hardware_info("computer_system"))
            serials_data["ComputerSystem"] = {
                "Name": cs_info.get("Name", "Unknown"),
                "Vendor": cs_info.get("Vendor", "Unknown"),
                "Version": cs_info.get("Version", "Unknown"),
                "UUID": cs_info.get("UUID", "Unknown"),
                "IdentifyingNumber": cs_info.get("IdentifyingNumber", "Unknown"),
            }

            enclosure_info = self._first_dict(self.get_hardware_info("system_enclosure"))
            serials_data["SystemEnclosure"] = {
                "Manufacturer": enclosure_info.get("Manufacturer", "Unknown"),
                "LockPresent": enclosure_info.get("LockPresent", False),
                "SerialNumber": enclosure_info.get("SerialNumber", "Unknown"),
                "SMBIOSAssetTag": enclosure_info.get("SMBIOSAssetTag", "Unknown"),
                "SecurityStatus": enclosure_info.get("SecurityStatus", "Unknown"),
            }

            disk_list = self._as_dict_list(self.get_hardware_info("disk_drive"))
            disks_dict: Dict[str, Any] = {}
            for i, disk in enumerate(disk_list):
                disks_dict[f"Disk_{i}"] = {
                    "DeviceID": disk.get("DeviceID", "Unknown"),
                    "SerialNumber": str(disk.get("SerialNumber") or "Unknown").strip(),
                    "Model": disk.get("Model", "Unknown"),
                    "Caption": disk.get("Caption", "Unknown"),
                }
            serials_data["DiskDrives"] = disks_dict

            mem_list = self._as_dict_list(self.get_hardware_info("physical_memory"))
            mem_dict: Dict[str, Any] = {}
            for i, mem in enumerate(mem_list):
                mem_dict[f"Memory_{i}"] = {
                    "Tag": mem.get("Tag", f"Physical Memory {i}"),
                    "SerialNumber": str(mem.get("SerialNumber") or "Unknown").strip(),
                }
            serials_data["Memory"] = mem_dict

            serials_data["Network"] = self.get_network_info()
            partitions: Dict[str, str] = {}
            for part in self.get_partition_serials():
                dev_id = part.get("DeviceID")
                vol_ser = part.get("VolumeSerialNumber")
                if dev_id and vol_ser:
                    partitions[str(dev_id)] = str(vol_ser)
            serials_data["Partitions"] = partitions
            serials_data["Hostname"] = self.get_hostname()

        except Exception as e:
            DEFAULT_LOGGER.log_operation(
                operation_name="GetAllSerials",
                target_item="SystemHardware",
                result=OperationState.FAILED.value,
                error_message=str(e),
                exception=e,
            )

        return serials_data

    def print_serials(self, serials_data: Optional[Dict[str, Any]] = None) -> None:
        if serials_data is None:
            serials_data = self.get_all_serials()
        for module, data in serials_data.items():
            Details.debug_print(f"\n{module}:")
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, dict):
                        Details.debug_print(f"  {key}:")
                        for sub_key, sub_value in value.items():
                            Details.debug_print(f"    {sub_key}: {sub_value}")
                    else:
                        Details.debug_print(f"  {key}: {value}")
            else:
                Details.debug_print(f"  {data}")
