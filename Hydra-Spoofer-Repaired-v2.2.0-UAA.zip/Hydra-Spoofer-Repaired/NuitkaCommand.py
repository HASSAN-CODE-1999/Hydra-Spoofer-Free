import os
import subprocess
import sys


def run_nuitka(disable_console: bool = False) -> int:
    """
    Build standalone executable using Nuitka without hardcoded local developer paths
    or missing entry points. Uses `MOFmenu.py` as the verified entry point.
    """
    entry_script = "MOFmenu.py"
    if not os.path.exists(entry_script):
        print(f"Error: Entry script '{entry_script}' not found in current working directory.")
        return 1

    cmd = [
        sys.executable,
        "-m",
        "nuitka",
        "--onefile",
        "--enable-plugin=tk-inter",
        "--windows-icon-from-ico=imgs/favicon.ico",
        "--include-data-file=Volumeid.exe=Volumeid.exe",
        "--include-data-dir=imgs=imgs",
        "--output-filename=HydraSystemIdentityManager",
        "--windows-uac-admin",
    ]
    if disable_console:
        cmd.append("--windows-console-mode=disable")
    cmd.append(entry_script)

    mode = "[PRODUCTION]" if disable_console else "[TEST]"
    print(f"Starting Nuitka build {mode}: {' '.join(cmd)}")

    process = subprocess.Popen(
        cmd,
        shell=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    assert process.stdout is not None
    for line in process.stdout:
        print(line, end="", flush=True)

    rc = process.wait()
    if rc == 0:
        print(f"\nBuild {mode} completed successfully!")
    else:
        print(f"\nBuild {mode} failed with exit code {rc}")
    return rc


if __name__ == "__main__":
    print("[1] Deploy (GUI only)")
    print("[2] Test (With console)")
    sw = input("\n> ").strip()
    if sw == "1":
        run_nuitka(disable_console=True)
    elif sw == "2":
        run_nuitka(disable_console=False)
