import ctypes
import hashlib
import json
import os
import random
import re
import string
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional, Tuple, Union

import DataStoring as DS
import Details
from BackupManager import BackupManager
from LoggerManager import DEFAULT_LOGGER, OperationState
from MOFManager import MOFManager
from UAAKernelPatcher import UAAKernelPatcher

try:
    import winreg
except ImportError:
    winreg = None


def is_admin() -> bool:
    """Safely check whether the current process has Windows Administrator privileges."""
    try:
        if hasattr(ctypes, "windll") and hasattr(ctypes.windll, "shell32"):
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return False
    except Exception:
        return False


def run_hidden(cmd: Union[str, List[str]], timeout: int = 15) -> subprocess.CompletedProcess:
    """Run a command in the background without opening a visible CMD window and with a strict timeout."""
    use_shell = isinstance(cmd, str)
    return subprocess.run(
        cmd,
        shell=use_shell,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        check=False,
        **Details.get_subprocess_kwargs(),
    )


class SpooferServiceManager:
    MAC_COLON_REGEX = re.compile(r"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$")
    MAC_RAW_REGEX = re.compile(r"^[0-9A-Fa-f]{12}$")

    def __init__(
        self,
        mof_manager: Optional[MOFManager] = None,
        backup_manager: Optional[BackupManager] = None,
    ):
        self.MOFM = mof_manager or MOFManager()
        self.BUM = backup_manager or BackupManager()
        self.original_file = os.path.join("backups", "Origin.json")
        self.UAA = UAAKernelPatcher(backup_dir=getattr(self.BUM, "backup_dir", "backups"))

    @classmethod
    def convert_to_locally_administered_mac(cls, raw_hex_12: str) -> str:
        """
        Convert any 12-hex MAC address into a valid Unicast Locally Administered Address (LAA)
        by clearing Bit 0 (Unicast) and setting Bit 1 (Locally Administered) of the first byte,
        ensuring the second hex digit is in (2, 6, A, E) as required by Windows Wi-Fi/NDIS drivers.
        """
        first_byte = int(raw_hex_12[:2], 16)
        laa_first_byte = (first_byte & 0xFE) | 0x02
        return f"{laa_first_byte:02X}{raw_hex_12[2:].upper()}"

    @classmethod
    def validate_mac_address(
        cls,
        mac_str: str,
        require_locally_administered: bool = False,
        auto_normalize_laa: bool = False,
    ) -> Tuple[bool, str, str]:
        """
        Validate a MAC address according to IEEE 802 and Windows NDIS requirements:
        - Must be 12 hexadecimal digits (`XX:XX:XX:XX:XX:XX`, `XX-XX-XX-XX-XX-XX`, or `XXXXXXXXXXXX`).
        - Cannot be all zeros (`000000000000`) or broadcast (`FFFFFFFFFFFF`).
        - Cannot be a multicast address (Least Significant Bit of first octet MUST be 0).
        - If `auto_normalize_laa=True` and the user supplies a Unicast Universal MAC (like `28:98:7B:4A:1F:9C`),
          automatically sets the Locally Administered bit (`2A:98:7B:4A:1F:9C`) so Windows Wi-Fi drivers accept it!
        """
        if not mac_str or not isinstance(mac_str, str):
            return False, "", "MAC address is empty."

        cleaned = mac_str.strip()
        if cls.MAC_COLON_REGEX.match(cleaned):
            raw_hex = cleaned.replace(":", "").replace("-", "").upper()
        elif cls.MAC_RAW_REGEX.match(cleaned):
            raw_hex = cleaned.upper()
        else:
            return (
                False,
                "",
                f"Invalid MAC format '{mac_str}'. Expected XX:XX:XX:XX:XX:XX (12 hex characters).",
            )

        if raw_hex == "000000000000":
            return False, "", "All-zero MAC address (00:00:00:00:00:00) is invalid."
        if raw_hex == "FFFFFFFFFFFF":
            return False, "", "Broadcast MAC address (FF:FF:FF:FF:FF:FF) is forbidden."

        first_octet = int(raw_hex[:2], 16)
        if (first_octet & 0x01) != 0:
            return (
                False,
                "",
                f"MAC address '{mac_str}' has the Multicast bit set (first byte 0x{raw_hex[:2]}). "
                "Network adapters require a Unicast MAC address.",
            )

        if require_locally_administered and (first_octet & 0x02) == 0:
            if auto_normalize_laa:
                adjusted_hex = cls.convert_to_locally_administered_mac(raw_hex)
                return (
                    True,
                    adjusted_hex,
                    f"Auto-adjusted first byte to Locally Administered Unicast ({adjusted_hex[:2]}:{adjusted_hex[2:4]}:...) for Windows Wi-Fi/NDIS compatibility.",
                )
            suggested = cls.convert_to_locally_administered_mac(raw_hex)
            suggested_fmt = ":".join(suggested[i : i + 2] for i in range(0, 12, 2))
            return (
                False,
                "",
                f"MAC address '{mac_str}' is not Locally Administered (second hex digit must be 2, 6, A, or E "
                f"for Windows Wi-Fi/NDIS adapter compatibility — e.g. {suggested_fmt}).",
            )

        return True, raw_hex, "Valid unicast locally-administered MAC address."

    @staticmethod
    def generate_valid_unicast_laa_mac(colon_separated: bool = True) -> str:
        """Generate a compliant Locally Administered Unicast MAC (second hex char in 2, 6, A, E)."""
        first_nibble = random.choice("0123456789ABCDEF")
        second_nibble = random.choice("26AE")
        octets = [f"{first_nibble}{second_nibble}"] + [
            f"{random.randint(0x00, 0xFF):02X}" for _ in range(5)
        ]
        return ":".join(octets) if colon_separated else "".join(octets)

    def restart_single_adapter(
        self, adapter_name: str, device_id: Optional[str] = None, timeout: int = 15
    ) -> Tuple[bool, str]:
        """
        Safely restart ONLY the specified network adapter (never disabling all adapters at once).
        Supports restarting by `InterfaceDescription` / `DeviceID` on localized Arabic Windows
        so encoding differences in `NetConnectionID` never break adapter restart!
        """
        if not adapter_name or re.search(r'[;&|`$"><]', adapter_name):
            return False, f"Invalid or unsafe adapter name: {adapter_name}"

        try:
            escaped_name = adapter_name.replace("'", "''")
            if device_id and str(device_id).isdigit():
                ps_cmd = (
                    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
                    f"$nic = Get-CimInstance Win32_NetworkAdapter -Filter 'DeviceID={int(device_id)}'; "
                    "if ($nic) { "
                    "  Disable-NetAdapter -InterfaceDescription $nic.Name -Confirm:$false -ErrorAction Stop; "
                    "  Start-Sleep -Seconds 1; "
                    "  Enable-NetAdapter -InterfaceDescription $nic.Name -Confirm:$false -ErrorAction Stop "
                    "} else { "
                    f"  Restart-NetAdapter -Name '{escaped_name}' -Confirm:$false -ErrorAction Stop "
                    "}"
                )
            else:
                ps_cmd = (
                    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
                    f"Restart-NetAdapter -Name '{escaped_name}' -Confirm:$false -ErrorAction Stop"
                )

            res = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                check=False,
                **Details.get_subprocess_kwargs(),
            )
            if res.returncode != 0:
                dis_res = run_hidden(
                    ["netsh", "interface", "set", "interface", f"name={adapter_name}", "admin=disabled"],
                    timeout=10,
                )
                time.sleep(1.0)
                en_res = run_hidden(
                    ["netsh", "interface", "set", "interface", f"name={adapter_name}", "admin=enabled"],
                    timeout=10,
                )
                if en_res.returncode != 0:
                    return (
                        False,
                        f"Failed to re-enable adapter '{adapter_name}': {en_res.stderr or dis_res.stderr or res.stderr}".strip(),
                    )

            return True, f"Adapter '{adapter_name}' restarted safely."
        except subprocess.TimeoutExpired:
            try:
                run_hidden(
                    ["netsh", "interface", "set", "interface", f"name={adapter_name}", "admin=enabled"],
                    timeout=10,
                )
            except Exception:
                pass
            return False, f"Timeout while restarting adapter '{adapter_name}'."
        except Exception as e:
            return False, f"Error restarting adapter '{adapter_name}': {e}"

    def verify_adapter_active_mac(
        self,
        device_id: str,
        adapter_name: str,
        expected_mac_12hex: str,
        retries: int = 3,
        delay: float = 1.0,
    ) -> Tuple[bool, str, str]:
        """
        Query the OS/Driver after adapter restart to verify whether the network card driver
        actually applied the new MAC address or silently ignored it.
        Returns: (applied_successfully, current_active_mac_formatted, diagnostic_message)
        """
        expected_clean = expected_mac_12hex.replace(":", "").replace("-", "").upper()
        expected_fmt = ":".join(expected_clean[i : i + 2] for i in range(0, 12, 2))
        last_seen_mac = "Unknown"

        for attempt in range(max(1, retries)):
            adapters = self.MOFM.get_detailed_network_adapters(include_virtual=True)
            for ad in adapters:
                ad_dev_id = str(ad.get("device_id") or "")
                ad_net_id = str(ad.get("net_connection_id") or ad.get("name") or "")
                if (device_id and ad_dev_id == str(device_id)) or (
                    adapter_name and ad_net_id.lower() == adapter_name.lower()
                ):
                    raw_curr = str(ad.get("mac_address") or "").replace(":", "").replace("-", "").upper()
                    if raw_curr and len(raw_curr) == 12:
                        last_seen_mac = ":".join(raw_curr[i : i + 2] for i in range(0, 12, 2))
                        if raw_curr == expected_clean:
                            return (
                                True,
                                last_seen_mac,
                                f"Verified: Driver applied active MAC {last_seen_mac}.",
                            )
            if attempt < retries - 1:
                time.sleep(delay)

        first_octet = int(expected_clean[:2], 16)
        if (first_octet & 0x02) == 0:
            suggested = self.convert_to_locally_administered_mac(expected_clean)
            suggested_fmt = ":".join(suggested[i : i + 2] for i in range(0, 12, 2))
            reason = (
                f"Driver Ignored MAC: Registry value '{expected_fmt}' was written, but adapter '{adapter_name}' "
                f"driver rejected it after restart and kept active MAC '{last_seen_mac}'. "
                f"This hardware driver strictly requires a Locally Administered MAC (second hex digit in 2, 6, A, E — e.g. {suggested_fmt})."
            )
        else:
            reason = (
                f"Driver Ignored MAC: Registry value '{expected_fmt}' was written, but adapter '{adapter_name}' "
                f"driver ignored the override after restart and kept active MAC '{last_seen_mac}'."
            )
        return False, last_seen_mac, reason

    def spoof_mac_address(
        self,
        mac_addresses: Optional[Dict[str, str]] = None,
        selected_adapters: Optional[List[str]] = None,
        allow_virtual: bool = False,
        verify_connectivity: bool = True,
        local_only_check: bool = True,
        auto_normalize_laa: bool = False,
        force_keep_uaa_registry: bool = False,
        transaction_id: Optional[str] = None,
    ) -> Tuple[bool, str]:
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("MAC")

        if not mac_addresses and not selected_adapters:
            msg = (
                "Explicit adapter selection is required. Refusing to modify all Wi-Fi, Ethernet, "
                "and Bluetooth adapters blindly."
            )
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofMAC",
                target_item="AllAdapters",
                result="Blocked",
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        discovered = self.MOFM.get_detailed_network_adapters(include_virtual=True)
        if not discovered:
            msg = "No physical network adapters detected."
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofMAC",
                target_item="NetworkAdapters",
                result=OperationState.FAILED.value,
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        targets: List[Tuple[Dict[str, Any], str]] = []
        rejected_reasons: List[str] = []

        mac_addresses = mac_addresses or {}
        selected_set = {s.lower() for s in (selected_adapters or [])}

        for adapter in discovered:
            ad_name = str(adapter.get("name") or "")
            net_id = str(adapter.get("net_connection_id") or ad_name)
            kind = str(adapter.get("adapter_kind") or "Ethernet").lower()
            dev_id = str(adapter.get("device_id") or "")

            requested_mac: Optional[str] = None
            explicitly_targeted = False

            for key_candidate in (net_id, ad_name, dev_id, kind):
                if key_candidate.lower() in {k.lower() for k in mac_addresses.keys()}:
                    for k, v in mac_addresses.items():
                        if k.lower() == key_candidate.lower() and v:
                            requested_mac = v
                            explicitly_targeted = True
                            break
                if key_candidate.lower() in selected_set:
                    explicitly_targeted = True

            if not explicitly_targeted:
                continue

            if adapter.get("is_virtual") and not allow_virtual:
                rejected_reasons.append(
                    f"Skipped virtual adapter '{net_id}' ({ad_name}) by safety policy."
                )
                continue

            if kind == "bluetooth":
                rejected_reasons.append(
                    f"Skipped Bluetooth adapter '{net_id}': modifying BTHPORT paired device keys "
                    "corrupts paired Bluetooth devices."
                )
                continue

            if not requested_mac:
                requested_mac = self.generate_valid_unicast_laa_mac(colon_separated=True)

            is_valid_mac, norm_mac, mac_reason = self.validate_mac_address(
                requested_mac,
                require_locally_administered=False,
                auto_normalize_laa=False,
            )
            if not is_valid_mac:
                rejected_reasons.append(f"Adapter '{net_id}': {mac_reason}")
                continue

            targets.append((adapter, norm_mac))

        if not targets:
            reason_str = "; ".join(rejected_reasons) if rejected_reasons else "No matching supported physical adapters selected."
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofMAC",
                target_item="SelectedAdapters",
                result=OperationState.FAILED.value,
                error_message=reason_str,
                transaction_id=tx_id,
            )
            return False, reason_str

        if winreg is None:
            msg = "Windows Registry (winreg) is unavailable in this environment."
            return False, msg

        modified_adapters: List[str] = []
        tx_changes: List[Dict[str, Any]] = []

        Details.hold_connection_flag = True
        try:
            for adapter, norm_mac in targets:
                net_id = str(adapter.get("net_connection_id") or adapter.get("name"))
                dev_id = str(adapter.get("device_id") or "")
                reg_support = self.MOFM.check_adapter_registry_support(dev_id, adapter.get("name", ""))
                if not reg_support.get("supported") or not reg_support.get("subkey_path"):
                    rejected_reasons.append(
                        f"Adapter '{net_id}' driver does not support Registry NetworkAddress override ({reg_support.get('reason')})."
                    )
                    continue

                bkp_file = self.BUM.backup_single_adapter(adapter, transaction_id=tx_id)
                if not bkp_file:
                    rejected_reasons.append(f"Adapter '{net_id}': Failed to create pre-modification backup.")
                    continue

                subkey_path = reg_support["subkey_path"]
                prev_override = reg_support.get("current_override")

                ok, write_err, prev_state = DS.write_to_registry(
                    subkey_path,
                    "NetworkAddress",
                    norm_mac,
                    root_key="HKLM",
                    value_type="REG_SZ",
                    transaction_id=tx_id,
                )
                if not ok:
                    rejected_reasons.append(f"Adapter '{net_id}': {write_err}")
                    continue

                rst_ok, rst_msg = self.restart_single_adapter(net_id, device_id=dev_id)
                if not rst_ok:
                    if prev_override:
                        DS.write_to_registry(subkey_path, "NetworkAddress", prev_override, root_key="HKLM", transaction_id=tx_id)
                    else:
                        DS.delete_registry_value(subkey_path, "NetworkAddress", root_key="HKLM", transaction_id=tx_id)
                    self.restart_single_adapter(net_id, device_id=dev_id)
                    rejected_reasons.append(f"Adapter '{net_id}' restart failed and was rolled back: {rst_msg}")
                    continue

                # Post-restart verification: check if the network driver actually applied norm_mac
                applied_ok, active_mac_fmt, verify_msg = self.verify_adapter_active_mac(
                    device_id=dev_id,
                    adapter_name=net_id,
                    expected_mac_12hex=norm_mac,
                )
                if not applied_ok:
                    if force_keep_uaa_registry:
                        fmt_norm = ":".join(norm_mac[i : i + 2] for i in range(0, 12, 2))
                        DEFAULT_LOGGER.log_operation(
                            operation_name="SpoofMACForceUAARegistryKept",
                            target_item=net_id,
                            previous_value=adapter.get("mac_address"),
                            new_value=norm_mac,
                            result=OperationState.COMPLETED.value,
                            error_message=(
                                f"Registry locked to UAA MAC {fmt_norm} (No Rollback). "
                                f"Hardware driver reported {active_mac_fmt}; use UAA Kernel Patcher or Hyper-V Bridge for Over-the-Air 802.11 frames."
                            ),
                            restore_status="ForcedRegistryPersistence",
                            transaction_id=tx_id,
                        )
                        modified_adapters.append(
                            f"{net_id} -> {fmt_norm} (Forced in Registry without rollback; Driver active: {active_mac_fmt})"
                        )
                        if prev_state:
                            tx_changes.append({"type": "registry", **prev_state})
                        continue

                    # Rollback Registry NetworkAddress so Registry matches actual driver state
                    if prev_override:
                        DS.write_to_registry(subkey_path, "NetworkAddress", prev_override, root_key="HKLM", transaction_id=tx_id)
                    else:
                        DS.delete_registry_value(subkey_path, "NetworkAddress", root_key="HKLM", transaction_id=tx_id)
                    self.restart_single_adapter(net_id, device_id=dev_id)
                    DEFAULT_LOGGER.log_operation(
                        operation_name="SpoofMACDriverIgnored",
                        target_item=net_id,
                        previous_value=adapter.get("mac_address"),
                        new_value=norm_mac,
                        result=OperationState.FAILED.value,
                        error_message=verify_msg,
                        restore_status="RolledBackToPrevious",
                        transaction_id=tx_id,
                    )
                    rejected_reasons.append(verify_msg)
                    continue

                modified_adapters.append(f"{net_id} -> {active_mac_fmt} (Verified Active)")
                if prev_state:
                    tx_changes.append({"type": "registry", **prev_state})

            if tx_changes:
                self.BUM.record_transaction(tx_id, "SpoofMAC", tx_changes)

            conn_note = ""
            if modified_adapters and verify_connectivity:
                conn_status = Details.check_network_connectivity(
                    local_only=local_only_check, timeout=3.0, max_retries=2
                )
                if conn_status.get("local_link_up"):
                    conn_note = " (Local network link verified active)"
                else:
                    conn_note = " (Note: Adapter restarted; waiting for DHCP/media link)"

            if modified_adapters and not rejected_reasons:
                summary = f"Successfully updated MAC on: {', '.join(modified_adapters)}{conn_note}"
                return True, summary
            elif modified_adapters and rejected_reasons:
                summary = (
                    f"Partially completed. Updated: {', '.join(modified_adapters)}{conn_note}. "
                    f"Warnings/Errors: {'; '.join(rejected_reasons)}"
                )
                return False, summary
            else:
                return False, "; ".join(rejected_reasons) or "MAC update failed."
        finally:
            Details.hold_connection_flag = False

    def restore_original_mac_addresses(
        self,
        selected_adapters: Optional[List[str]] = None,
        return_detailed: bool = False,
        transaction_id: Optional[str] = None,
    ) -> Union[bool, Tuple[bool, str]]:
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("MACRST")
        if winreg is None:
            msg = "winreg is unavailable on this OS."
            return (False, msg) if return_detailed else False

        Details.hold_connection_flag = True
        removed_adapters: List[str] = []
        errors: List[str] = []
        already_default_count = 0

        try:
            adapters = self.MOFM.get_detailed_network_adapters(include_virtual=False)
            selected_set = {s.lower() for s in (selected_adapters or [])}

            for ad in adapters:
                net_id = str(ad.get("net_connection_id") or ad.get("name") or "")
                dev_id = str(ad.get("device_id") or "")
                if selected_set and net_id.lower() not in selected_set and dev_id.lower() not in selected_set:
                    continue

                reg_info = self.MOFM.check_adapter_registry_support(dev_id, ad.get("name", ""))
                subkey_path = reg_info.get("subkey_path")
                if not subkey_path:
                    continue

                if not reg_info.get("current_override"):
                    already_default_count += 1
                    continue

                ok, del_err = DS.delete_registry_value(
                    subkey_path, "NetworkAddress", root_key="HKLM", transaction_id=tx_id
                )
                if ok:
                    rst_ok, rst_msg = self.restart_single_adapter(net_id)
                    if rst_ok:
                        removed_adapters.append(net_id)
                    else:
                        errors.append(f"Removed override on '{net_id}' but restart failed: {rst_msg}")
                else:
                    errors.append(f"Failed removing override on '{net_id}': {del_err}")

            if errors:
                msg = f"Errors restoring MAC addresses: {'; '.join(errors)}"
                return (False, msg) if return_detailed else False

            if removed_adapters:
                msg = f"Restored hardware MAC on: {', '.join(removed_adapters)}"
            else:
                msg = f"All inspected physical adapters ({already_default_count}) are already using original hardware MAC addresses."

            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreMAC",
                target_item=",".join(removed_adapters) if removed_adapters else "AllPhysicalAdapters",
                result=OperationState.COMPLETED.value,
                restore_status=msg,
                transaction_id=tx_id,
            )
            return (True, msg) if return_detailed else True
        except Exception as e:
            msg = f"Unexpected error restoring MAC addresses: {e}"
            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreMAC",
                target_item="NetworkAdapters",
                result=OperationState.FAILED.value,
                error_message=msg,
                exception=e,
                transaction_id=tx_id,
            )
            return (False, msg) if return_detailed else False
        finally:
            Details.hold_connection_flag = False

    def verify_volumeid_binary(self) -> Dict[str, Any]:
        vol_path = Details.resource_path("Volumeid.exe")
        result: Dict[str, Any] = {
            "path": vol_path,
            "exists": os.path.isfile(vol_path),
            "sha256": None,
            "hash_verified": False,
            "signature_verified": False,
            "safe_to_execute": False,
            "reason": "",
        }
        if not result["exists"]:
            result["reason"] = f"Volumeid.exe not found at {vol_path}"
            return result

        try:
            h = hashlib.sha256()
            with open(vol_path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            digest = h.hexdigest().lower()
            result["sha256"] = digest
            result["hash_verified"] = digest == Details.EXPECTED_VOLUMEID_SHA256.lower()
            if not result["hash_verified"]:
                result["reason"] = (
                    f"Volumeid.exe SHA-256 hash mismatch! Expected {Details.EXPECTED_VOLUMEID_SHA256[:16]}..., "
                    f"got {digest[:16]}... Execution blocked."
                )
                return result
        except Exception as e:
            result["reason"] = f"Failed hashing Volumeid.exe: {e}"
            return result

        if sys.platform.startswith("win"):
            try:
                ps_sig = (
                    f"Get-AuthenticodeSignature -FilePath '{vol_path.replace(chr(39), chr(39)*2)}' | "
                    "Select-Object Status, StatusMessage, @{N='Subject';E={$_.SignerCertificate.Subject}} | ConvertTo-Json"
                )
                sig_data = self.MOFM._first_dict(self.MOFM.run_powershell(ps_sig, timeout=10))
                status = sig_data.get("Status")
                subject = str(sig_data.get("Subject") or "")
                if status in (0, "0", "Valid") and "microsoft" in subject.lower():
                    result["signature_verified"] = True
                else:
                    result["signature_verified"] = result["hash_verified"]
            except Exception:
                result["signature_verified"] = result["hash_verified"]
        else:
            result["signature_verified"] = result["hash_verified"]

        result["safe_to_execute"] = bool(result["hash_verified"] and result["signature_verified"])
        result["reason"] = "Verified Sysinternals Volumeid.exe binary." if result["safe_to_execute"] else "Verification failed."
        return result

    def inspect_disks_and_bitlocker(self) -> List[Dict[str, Any]]:
        sys_drive = os.environ.get("SystemDrive", "C:").upper().rstrip("\\")
        partitions = self.MOFM.get_partition_serials()

        bitlocker_map: Dict[str, Dict[str, Any]] = {}
        if sys.platform.startswith("win"):
            bl_script = (
                "Get-BitLockerVolume -ErrorAction SilentlyContinue | "
                "Select-Object MountPoint, VolumeStatus, ProtectionStatus, EncryptionMethod | ConvertTo-Json"
            )
            bl_list = self.MOFM._as_dict_list(self.MOFM.run_powershell(bl_script, timeout=10))
            for item in bl_list:
                mp = str(item.get("MountPoint") or "").upper().rstrip("\\")
                if mp:
                    bitlocker_map[mp] = item

        enriched: List[Dict[str, Any]] = []
        for part in partitions:
            dev_id = str(part.get("DeviceID") or "").upper().rstrip("\\")
            if not dev_id:
                continue
            drive_type = part.get("DriveType", 3)
            is_system = dev_id == sys_drive
            bl_info = bitlocker_map.get(dev_id, {})
            vol_status = str(bl_info.get("VolumeStatus") or "FullyDecrypted")
            prot_status = bl_info.get("ProtectionStatus", 0)
            is_bitlocker = (
                prot_status in (1, "1", "On")
                or (vol_status not in ("FullyDecrypted", "0", ""))
            )

            modifiable = (drive_type == 3) and (not is_system) and (not is_bitlocker)
            block_reason = None
            if is_system:
                block_reason = f"System boot/OS drive ({dev_id}) is protected and cannot be modified."
            elif is_bitlocker:
                block_reason = (
                    f"Drive {dev_id} is protected by BitLocker (Status={vol_status}). "
                    "Modifying volume serials on BitLocker drives is blocked; always back up your BitLocker Recovery Key."
                )
            elif drive_type != 3:
                block_reason = f"Drive {dev_id} is not a fixed local disk (DriveType={drive_type})."

            enriched.append(
                {
                    "device_id": dev_id,
                    "volume_name": part.get("VolumeName", ""),
                    "file_system": part.get("FileSystem", "Unknown"),
                    "drive_type": drive_type,
                    "volume_serial": str(part.get("VolumeSerialNumber") or "Unknown"),
                    "is_system_drive": is_system,
                    "bitlocker_active": is_bitlocker,
                    "bitlocker_status": vol_status,
                    "modifiable": modifiable,
                    "block_reason": block_reason,
                }
            )
        return enriched

    def get_partition_serials(self) -> Dict[str, str]:
        serials: Dict[str, str] = {}
        for part in self.MOFM.get_partition_serials():
            dev_id = str(part.get("DeviceID") or "").strip()
            serial = str(part.get("VolumeSerialNumber") or "").strip()
            if dev_id and serial:
                serials[dev_id] = serial
        return serials

    def spoof_partition_serials(
        self,
        selected_drives: Optional[List[str]] = None,
        custom_serials: Optional[Dict[str, str]] = None,
        user_confirmed: bool = False,
        transaction_id: Optional[str] = None,
    ) -> Tuple[bool, str]:
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("VOL")

        if not selected_drives:
            msg = "No partition selected. Modifying all disk partitions automatically is prohibited."
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofPartitionSerials",
                target_item="AllPartitions",
                result="Blocked",
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        if not user_confirmed:
            msg = (
                "Explicit user confirmation is required before changing partition Volume Serial Numbers. "
                "Ensure BitLocker Recovery Keys are backed up before proceeding."
            )
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofPartitionSerials",
                target_item=",".join(selected_drives),
                result="Blocked",
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        bin_check = self.verify_volumeid_binary()
        if not bin_check.get("safe_to_execute"):
            msg = f"Volumeid.exe verification failed: {bin_check.get('reason')}"
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofPartitionSerials",
                target_item="Volumeid.exe",
                result=OperationState.FAILED.value,
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        discovered = {d["device_id"].upper(): d for d in self.inspect_disks_and_bitlocker()}
        if not discovered:
            msg = "Failed to read disk partitions from WMI."
            return False, msg

        custom_serials = custom_serials or {}
        vol_regex = re.compile(r"^[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}$")

        succeeded: List[str] = []
        failed: List[str] = []
        tx_changes: List[Dict[str, Any]] = []

        for raw_drv in selected_drives:
            drv = raw_drv.strip().upper().rstrip("\\")
            if not drv.endswith(":"):
                drv += ":"
            info = discovered.get(drv)
            if not info:
                failed.append(f"{drv}: Partition not found.")
                continue

            if not info.get("modifiable"):
                failed.append(f"{drv}: {info.get('block_reason')}")
                continue

            orig_serial = str(info.get("volume_serial") or "")
            target_serial = custom_serials.get(drv)
            if target_serial:
                target_serial = target_serial.strip().upper()
                if len(target_serial) == 8 and "-" not in target_serial:
                    target_serial = f"{target_serial[:4]}-{target_serial[4:]}"
                if not vol_regex.match(target_serial):
                    failed.append(f"{drv}: Invalid Volume Serial format '{target_serial}' (expected XXXX-XXXX hex).")
                    continue
            else:
                p1 = "".join(random.choices("0123456789ABCDEF", k=4))
                p2 = "".join(random.choices("0123456789ABCDEF", k=4))
                target_serial = f"{p1}-{p2}"

            cmd = [bin_check["path"], "/accepteula", drv, target_serial]
            res = run_hidden(cmd, timeout=15)
            if res.returncode != 0:
                err_txt = (res.stderr or res.stdout or f"ExitCode {res.returncode}").strip()
                failed.append(f"{drv}: Volumeid.exe failed ({err_txt})")
                DEFAULT_LOGGER.log_operation(
                    operation_name="VolumeIdModify",
                    target_item=drv,
                    previous_value=orig_serial,
                    new_value=target_serial,
                    result=OperationState.FAILED.value,
                    error_message=err_txt,
                    transaction_id=tx_id,
                )
                continue

            succeeded.append(f"{drv} ({orig_serial} -> {target_serial}, Requires Restart)")
            tx_changes.append(
                {
                    "type": "partition",
                    "drive": drv,
                    "previous_value": orig_serial,
                    "new_value": target_serial,
                }
            )
            DEFAULT_LOGGER.log_operation(
                operation_name="VolumeIdModify",
                target_item=drv,
                previous_value=orig_serial,
                new_value=target_serial,
                result=OperationState.REQUIRES_RESTART.value,
                restore_status="BackupCaptured",
                transaction_id=tx_id,
            )

        if tx_changes:
            self.BUM.record_transaction(tx_id, "SpoofPartitionSerials", tx_changes)

        if succeeded and not failed:
            return True, f"Updated Volume Serial (Requires Restart): {', '.join(succeeded)}"
        elif succeeded and failed:
            return (
                False,
                f"Partially completed. Updated: {', '.join(succeeded)} | Failed/Blocked: {'; '.join(failed)}",
            )
        else:
            return False, "; ".join(failed) or "No partitions were modified."

    def restore_partition_serials(
        self, partition_backup: Dict[str, str], transaction_id: Optional[str] = None
    ) -> Dict[str, List[Dict[str, Any]]]:
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("VOLRST")
        report: Dict[str, List[Dict[str, Any]]] = {"restored": [], "failed": [], "skipped": []}

        current_map = {d["device_id"].upper(): d for d in self.inspect_disks_and_bitlocker()}
        bin_check = self.verify_volumeid_binary()

        for drv_raw, saved_serial_raw in partition_backup.items():
            drv = str(drv_raw).strip().upper().rstrip("\\")
            saved_clean = str(saved_serial_raw).replace("-", "").strip().upper()
            info = current_map.get(drv)
            if not info:
                report["skipped"].append({"item": f"Partition:{drv}", "reason": "Drive not currently mounted"})
                continue

            curr_clean = str(info.get("volume_serial") or "").replace("-", "").strip().upper()
            if curr_clean == saved_clean:
                report["restored"].append({"item": f"Partition:{drv}", "status": "Already matches original Volume Serial"})
                continue

            if not info.get("modifiable"):
                report["skipped"].append({"item": f"Partition:{drv}", "reason": info.get("block_reason")})
                continue

            if not bin_check.get("safe_to_execute"):
                report["failed"].append({"item": f"Partition:{drv}", "reason": bin_check.get("reason")})
                continue

            formatted_serial = f"{saved_clean[:4]}-{saved_clean[4:8]}"
            res = run_hidden([bin_check["path"], "/accepteula", drv, formatted_serial], timeout=15)
            if res.returncode == 0:
                report["restored"].append(
                    {"item": f"Partition:{drv}", "status": f"Restored to {formatted_serial} (Requires Restart)"}
                )
            else:
                report["failed"].append(
                    {"item": f"Partition:{drv}", "reason": (res.stderr or res.stdout or "Volumeid failed").strip()}
                )

        return report

    def generate_realistic_device_name(self) -> str:
        prefixes = ["DESKTOP-", "WIN-", "PC-", "WORK-"]
        return random.choice(prefixes) + "".join(
            random.choices(string.ascii_uppercase + string.digits, k=7)
        )

    def set_reg_value(
        self,
        root_key: Any,
        sub_key: str,
        value_name: str,
        value_type: str,
        value: Any,
        transaction_id: Optional[str] = None,
    ) -> bool:
        ok, _, _ = DS.write_to_registry(
            key_path=sub_key,
            name=value_name,
            value=value,
            root_key=root_key,
            value_type=value_type,
            transaction_id=transaction_id,
        )
        return ok

    def spoof_windows_identifiers(
        self,
        allow_hostname_change: bool = False,
        new_hostname: Optional[str] = None,
        transaction_id: Optional[str] = None,
    ) -> Tuple[bool, str]:
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("WIN")

        if not allow_hostname_change:
            msg = (
                "Protected Mode: Modifying Windows Activation/Licensing keys (ProductId, DigitalProductId, "
                "MachineGuid, BuildGUID, InstallDate, ProfileGuid) is blocked to prevent breaking Windows Activation, "
                "Office, Adobe, and DPAPI. Computer Name change was also skipped because explicit consent was not enabled."
            )
            DEFAULT_LOGGER.log_operation(
                operation_name="SpoofWindowsIdentifiersBlocked",
                target_item="WindowsLicensingAndHostname",
                result="Blocked",
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        target_name = (new_hostname or "").strip() or self.generate_realistic_device_name()
        if not re.match(r"^[A-Za-z0-9-]{3,15}$", target_name):
            return False, f"Invalid Windows ComputerName '{target_name}' (must be 3-15 alphanumeric/hyphen characters)."

        hostname_targets = [
            ("HKLM", r"SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName", "ComputerName"),
            ("HKLM", r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", "NV Hostname"),
            ("HKLM", r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", "Hostname"),
        ]

        tx_changes: List[Dict[str, Any]] = []
        errors: List[str] = []

        for root_lbl, kpath, vname in hostname_targets:
            ok, err, prev_state = DS.write_to_registry(
                key_path=kpath,
                name=vname,
                value=target_name,
                root_key=root_lbl,
                value_type="REG_SZ",
                transaction_id=tx_id,
            )
            if ok and prev_state:
                tx_changes.append({"type": "registry", **prev_state})
            elif not ok:
                errors.append(err or f"Failed writing {kpath}\\{vname}")

        if tx_changes:
            self.BUM.record_transaction(tx_id, "ChangeComputerName", tx_changes)

        if errors:
            return False, "; ".join(errors)

        return (
            True,
            f"ComputerName updated to '{target_name}' (Requires Restart). "
            "Windows Activation, MachineGuid, and Licensing keys were preserved untouched.",
        )

    def get_bluetooth_state(self) -> Dict[str, Any]:
        state: Dict[str, Any] = {
            "service_name": "bthserv",
            "display_name": "Bluetooth Support Service",
            "status": "Unknown",
            "start_type": "Unknown",
            "adapters": [],
            "paired_devices_protected": True,
        }
        if not sys.platform.startswith("win"):
            return state

        svc_script = (
            "Get-Service -Name bthserv -ErrorAction SilentlyContinue | "
            "Select-Object Name, DisplayName, Status, StartType | ConvertTo-Json"
        )
        svc_data = self.MOFM._first_dict(self.MOFM.run_powershell(svc_script, timeout=10))
        if svc_data:
            st = svc_data.get("Status")
            state["status"] = "Running" if st in (4, "4", "Running") else ("Stopped" if st in (1, "1", "Stopped") else str(st))
            state["start_type"] = str(svc_data.get("StartType", "Unknown"))

        bt_script = (
            "Get-CimInstance Win32_PnPEntity -Filter \"PNPClass='Bluetooth'\" -ErrorAction SilentlyContinue | "
            "Select-Object Name, DeviceID, Status | ConvertTo-Json"
        )
        state["adapters"] = self.MOFM._as_dict_list(self.MOFM.run_powershell(bt_script, timeout=10))
        return state

    def restore_bluetooth_state(
        self, saved_state: Dict[str, Any], transaction_id: Optional[str] = None
    ) -> Tuple[bool, str]:
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("BTRST")
        current = self.get_bluetooth_state()
        desired_status = saved_state.get("status", "Running")

        if current.get("status") == desired_status or desired_status == "Unknown":
            return True, f"Bluetooth service is in expected state ({current.get('status')})."

        if desired_status == "Running" and sys.platform.startswith("win"):
            res = run_hidden(["net", "start", "bthserv"], timeout=15)
            after = self.get_bluetooth_state()
            if after.get("status") == "Running" or res.returncode == 0:
                DEFAULT_LOGGER.log_operation(
                    operation_name="RestoreBluetoothService",
                    target_item="bthserv",
                    previous_value=current.get("status"),
                    new_value="Running",
                    result=OperationState.COMPLETED.value,
                    transaction_id=tx_id,
                )
                return True, "Bluetooth Support Service restarted and verified Running."
            msg = f"Failed to restart Bluetooth Support Service (bthserv): {res.stderr or res.stdout}".strip()
            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreBluetoothService",
                target_item="bthserv",
                result=OperationState.FAILED.value,
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, msg

        return True, f"Bluetooth service state preserved ({current.get('status')})."

    def restart_system(self, force: bool = False, ask_callback: Optional[Any] = None) -> bool:
        if force:
            run_hidden(["shutdown", "/r", "/t", "5"])
            return True
        if ask_callback and callable(ask_callback):
            if ask_callback("Restart Required", "System needs to restart to complete changes. Restart now?"):
                run_hidden(["shutdown", "/r", "/t", "5"])
                return True
        return False

    def check_spoofer_installed(self) -> bool:
        exists, val, _, _ = DS.read_from_registry_ex(r"SOFTWARE\HydraSpoofer", "SpoofStatus", root_key="HKLM")
        return bool(exists and val == 1)

    def set_spoof_status(self, active: bool = True, transaction_id: Optional[str] = None) -> bool:
        if active:
            ok, _, _ = DS.write_to_registry(
                r"SOFTWARE\HydraSpoofer",
                "SpoofStatus",
                1,
                root_key="HKLM",
                value_type="REG_DWORD",
                transaction_id=transaction_id,
            )
            return ok
        ok, _ = DS.delete_registry_value(
            r"SOFTWARE\HydraSpoofer", "SpoofStatus", root_key="HKLM", transaction_id=transaction_id
        )
        return ok

    def install_service(self, config: Optional[Dict[str, Any]] = None) -> Tuple[bool, List[str]]:
        tx_id = DEFAULT_LOGGER.new_transaction_id("APPLY")

        if not is_admin():
            msg = "Administrator privileges required."
            DEFAULT_LOGGER.log_operation(
                operation_name="InstallService",
                target_item="System",
                result=OperationState.FAILED.value,
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, [f"• {msg}"]

        if not config:
            msg = (
                "Explicit configuration is required. Blindly modifying all adapters, disks, "
                "registry keys, and WMI classes at once is disabled for system safety."
            )
            DEFAULT_LOGGER.log_operation(
                operation_name="InstallService",
                target_item="Configuration",
                result="Blocked",
                error_message=msg,
                transaction_id=tx_id,
            )
            return False, [f"• {msg}"]

        bt_state = self.get_bluetooth_state()
        if not os.path.exists(self.original_file):
            origin_path = self.BUM.backup_hardware_info(
                "Origin", transaction_id=tx_id, bluetooth_state=bt_state
            )
            if not origin_path:
                return False, ["• Aborted: Could not create and verify initial Origin backup before starting."]
        else:
            ok_orig, orig_msg, _ = self.BUM.read_backup_with_status(self.original_file)
            if not ok_orig:
                return False, [f"• Aborted: Existing Origin.json backup is corrupted ({orig_msg})."]

        tx_bkp_path = self.BUM.backup_hardware_info(
            filename=f"tx_{tx_id}.json", transaction_id=tx_id, bluetooth_state=bt_state
        )
        if not tx_bkp_path:
            return False, ["• Aborted: Could not verify pre-operation transaction backup."]

        error_messages: List[str] = []
        success_messages: List[str] = []

        if config.get("spoof_mac"):
            mac_addresses: Dict[str, str] = {}
            for k in ("ethernet", "wifi", "bluetooth"):
                val = config.get(f"mac_{k}")
                if val:
                    mac_addresses[k] = val
            if isinstance(config.get("adapter_macs"), dict):
                mac_addresses.update(config["adapter_macs"])

            selected_adapters = config.get("selected_adapters")
            ok_mac, mac_msg = self.spoof_mac_address(
                mac_addresses=mac_addresses if mac_addresses else None,
                selected_adapters=selected_adapters,
                allow_virtual=bool(config.get("allow_virtual_adapters", False)),
                verify_connectivity=bool(config.get("verify_connectivity", True)),
                local_only_check=bool(config.get("local_only_connectivity", True)),
                auto_normalize_laa=bool(config.get("auto_normalize_laa", False)),
                force_keep_uaa_registry=bool(config.get("force_keep_uaa_registry", False)),
                transaction_id=tx_id,
            )
            if ok_mac:
                success_messages.append(f"• Network MAC: {mac_msg}")
            else:
                error_messages.append(f"• Network MAC Failed/Blocked: {mac_msg}")

        if config.get("spoof_win"):
            ok_win, win_msg = self.spoof_windows_identifiers(
                allow_hostname_change=bool(config.get("allow_hostname_change", False)),
                new_hostname=config.get("new_hostname"),
                transaction_id=tx_id,
            )
            if ok_win:
                success_messages.append(f"• Windows Hostname: {win_msg}")
            else:
                error_messages.append(f"• Windows Registry Protected/Skipped: {win_msg}")

        if config.get("spoof_parts"):
            ok_parts, parts_msg = self.spoof_partition_serials(
                selected_drives=config.get("selected_drives"),
                custom_serials=config.get("custom_volume_serials"),
                user_confirmed=bool(config.get("confirm_disk_changes", False)),
                transaction_id=tx_id,
            )
            if ok_parts:
                success_messages.append(f"• Partition Volume Serial: {parts_msg}")
            else:
                error_messages.append(f"• Partition Volume Serial Failed/Blocked: {parts_msg}")

        if config.get("spoof_smbios"):
            self.MOFM.spoof_smbios_serials()
            error_messages.append(f"• SMBIOS/BIOS Protected: {self.MOFM.last_error}")

        if config.get("spoof_disk"):
            self.MOFM.spoof_hard_disks()
            error_messages.append(f"• Physical Disk WMI Protected: {self.MOFM.last_error}")

        if config.get("spoof_mem"):
            self.MOFM.spoof_memory()
            error_messages.append(f"• Physical Memory WMI Protected: {self.MOFM.last_error}")

        if success_messages:
            self.set_spoof_status(True, transaction_id=tx_id)

        if error_messages and not success_messages:
            return False, error_messages
        if error_messages and success_messages:
            return False, success_messages + error_messages
        if not success_messages:
            return False, ["• No components were selected for modification."]

        return True, success_messages

    def uninstall_service(self, service: bool = False) -> Tuple[bool, Dict[str, Any]]:
        if not is_admin():
            report = {
                "overall_status": OperationState.FAILED.value,
                "can_claim_full_success": False,
                "summary_message": "Administrator privileges required.",
                "restored_items": [],
                "failed_items": [{"item": "PrivilegeCheck", "reason": "Administrator privileges required"}],
                "non_restorable_items": [],
            }
            return False, report

        if os.path.exists(self.original_file):
            report = self.BUM.restore_full_backup(self.original_file, spoofer_service=self)
        else:
            mac_ok, mac_msg = self.restore_original_mac_addresses(return_detailed=True)
            overall = OperationState.COMPLETED.value if mac_ok else OperationState.FAILED.value
            report = {
                "overall_status": overall,
                "can_claim_full_success": mac_ok,
                "summary_message": mac_msg,
                "restored_items": [{"item": "NetworkAdaptersMAC", "status": mac_msg}] if mac_ok else [],
                "failed_items": [] if mac_ok else [{"item": "NetworkAdaptersMAC", "reason": mac_msg}],
                "non_restorable_items": [],
            }

        if len(report.get("failed_items", [])) == 0:
            self.set_spoof_status(False)
            if service:
                self.restart_system(force=True)
            return True, report

        return False, report
