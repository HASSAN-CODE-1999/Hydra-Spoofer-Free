import datetime
import json
import os
import subprocess
import sys
import threading
import time
from tkinter import filedialog, messagebox
from typing import Any, Callable, Dict, List, Optional

import customtkinter as ctk
import psutil
from PIL import Image

import DataStoring as DS
import Details
from BackupManager import BackupManager
from DiagnosticsManager import DiagnosticsManager
from LoggerManager import DEFAULT_LOGGER, OperationState
from MOFSpoofer import SpooferServiceManager, is_admin


def run_powershell(cmd: str, timeout: int = 10) -> str:
    """Run a PowerShell command safely with a timeout and return its trimmed stdout."""
    if not sys.platform.startswith("win"):
        return "Unknown"
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", cmd],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=True,
            **Details.get_subprocess_kwargs(),
        )
        output = (result.stdout or "").strip()
        return output if output else "Unknown"
    except Exception:
        return "Unknown"


class HydraSpoofer(ctk.CTk):
    NORMAL_STATUS = "NO CHANGES"
    MANIPULATED_STATUS = "MODIFIED"

    def __init__(self):
        super().__init__()

        self.spoofer = SpooferServiceManager()
        self.bum = self.spoofer.BUM
        self.diagnostics = DiagnosticsManager(spoofer=self.spoofer, mof=self.spoofer.MOFM, backup_mgr=self.bum)

        # Window configuration
        self.title(f"{Details.applicationName} v{Details.__version__}")
        self.geometry("920x680")
        self.minsize(820, 600)
        try:
            ico_path = os.path.join(Details.imgsPath, "favicon.ico")
            if os.path.exists(ico_path):
                self.iconbitmap(ico_path)
        except Exception:
            pass

        try:
            self.attributes("-alpha", 0.97)
        except Exception:
            pass

        self.center_window(920, 680)

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.colors = {
            "primary": "#00e5ff",
            "secondary": "#3ab7ff",
            "accent": "#1fa2ff",
            "warning": "#ff4c4c",
            "success": "#00e676",
            "bg_dark": "#030812",
            "bg_card": "#071426",
            "bg_input": "#020a16",
            "text_primary": "#eaf6ff",
            "text_secondary": "#7fa6c7",
            "border": "#0c2a44",
            "gold": "#ffc861",
            "green": "#00ff9c",
        }

        # Load images safely with fallbacks for missing icons (regenerate.png / pid.png)
        self.images = {
            "system": self.load_icon("computer.png"),
            "network": self.load_icon("network.png"),
            "mobo": self.load_icon("motherboard.png"),
            "id": self.load_icon("id.png"),
            "ssd": self.load_icon("ssd.png"),
            "clean": self.load_icon("clean.png"),
            "save": self.load_icon("save.png"),
            "start": self.load_icon("start.png"),
            "regenerate": self.load_icon("regenerate.png") or self.load_icon("maintainance.png"),
            "restore": self.load_icon("restore.png"),
            "logout": self.load_icon("logout.png"),
            "ram": self.load_icon("ram.png"),
            "bios": self.load_icon("chip.png"),
            "pid": self.load_icon("pid.png") or self.load_icon("id.png"),
            "github": self.load_icon("github.png"),
            "discord": self.load_icon("discord.png"),
            "instagram": self.load_icon("instagram.png"),
        }

        self.cards: Dict[str, Any] = {}
        self.card_labels: Dict[str, Any] = {}
        self.spoofing_in_progress = False
        self.current_op_state = OperationState.READY
        self.status_text = ctk.StringVar(value="READY — System & Network Identity Manager Initialized")
        self.op_state_var = ctk.StringVar(value=f"STATE: {OperationState.READY.value.upper()}")
        self.custom_config: Dict[str, Any] = {}

        # Initialize fast non-blocking placeholders first, then refresh in a background thread
        self.pc_info: Dict[str, str] = {
            "MAC": "Loading...",
            "MOTHERBOARD": "Loading...",
            "UUID": "Loading...",
            "DISKS": "Loading...",
            "BIOS": "Loading...",
            "SMBIOS": "Loading...",
            "MEMORY": "Loading...",
            "CPU_ID": "Loading...",
            "ENCLOSURE": "Loading...",
        }

        self.create_widgets()
        self.refresh_pc_info_async()

    def ui_dispatch(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> None:
        """Marshal any GUI update safely onto the main Tkinter thread."""
        try:
            self.after(0, lambda: func(*args, **kwargs))
        except Exception:
            pass

    def load_icon(self, filename: str, size: tuple = (20, 20)) -> Optional[ctk.CTkImage]:
        try:
            full_path = os.path.join(Details.imgsPath, filename)
            if not os.path.exists(full_path):
                return None
            img = Image.open(full_path)
            return ctk.CTkImage(light_image=img, dark_image=img, size=size)
        except Exception:
            return None

    def center_window(self, width: int = 920, height: int = 680) -> None:
        self.update_idletasks()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")

    def get_pc_info(self) -> Dict[str, str]:
        """Collect system information safely without blocking the main thread when called from worker."""
        info = {
            "MAC": "Unknown",
            "MOTHERBOARD": "Unknown",
            "UUID": "Unknown",
            "DISKS": "Unknown",
            "BIOS": "Unknown",
            "SMBIOS": "Unknown",
            "MEMORY": "Unknown",
            "CPU_ID": "Unknown",
            "ENCLOSURE": "Unknown",
        }
        try:
            net_macs = self.spoofer.MOFM.get_network_info()
            if net_macs:
                info["MAC"] = "\n".join(f"{k}: {v}" for k, v in net_macs.items())

            serials = self.spoofer.MOFM.get_all_serials()
            info["MOTHERBOARD"] = str(serials.get("BaseBoard", {}).get("SerialNumber", "Unknown"))
            info["UUID"] = str(serials.get("ComputerSystem", {}).get("UUID", "Unknown"))
            info["BIOS"] = str(serials.get("BIOS", {}).get("SerialNumber", "Unknown"))
            info["SMBIOS"] = str(serials.get("BIOS", {}).get("SMBIOSBIOSVersion", "Unknown"))
            info["CPU_ID"] = str(serials.get("Processor", {}).get("ProcessorId", "Unknown"))
            info["ENCLOSURE"] = str(serials.get("SystemEnclosure", {}).get("SerialNumber", "Unknown"))

            disks = serials.get("DiskDrives", {})
            if isinstance(disks, dict) and disks:
                info["DISKS"] = ",\n".join(
                    str(d.get("SerialNumber", "Unknown")) for d in disks.values() if isinstance(d, dict)
                )

            mems = serials.get("Memory", {})
            if isinstance(mems, dict) and mems:
                info["MEMORY"] = ",\n".join(
                    str(m.get("SerialNumber", "Unknown")) for m in mems.values() if isinstance(m, dict)
                )
        except Exception as e:
            Details.debug_print(f"Error getting system info: {e}")

        return info

    def refresh_pc_info_async(self) -> None:
        def _worker():
            new_info = self.get_pc_info()
            self.pc_info = new_info
            self.ui_dispatch(self._apply_pc_info_to_ui, new_info)

        threading.Thread(target=_worker, daemon=True).start()

    def _apply_pc_info_to_ui(self, new_info: Dict[str, str]) -> None:
        for key, value in new_info.items():
            lbl = self.card_labels.get(key)
            if lbl and lbl.cget("text") != value:
                lbl.configure(text=value)

        is_spoofed = self.spoofer.check_spoofer_installed()
        new_status_text = self.MANIPULATED_STATUS if is_spoofed else self.NORMAL_STATUS
        new_color = self.colors["gold"] if is_spoofed else self.colors["success"]
        if hasattr(self, "system_status"):
            self.system_status.configure(text=f"● {new_status_text}", text_color=new_color)

    def update_system_changes(self) -> None:
        self.refresh_pc_info_async()

    def create_widgets(self) -> None:
        self.configure(fg_color=self.colors["bg_dark"])
        self.create_header()

        self.main_frame = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        self.main_frame.pack(fill="both", expand=True, padx=10, pady=4)

        self.tabview = ctk.CTkTabview(
            self.main_frame,
            fg_color=self.colors["bg_card"],
            segmented_button_fg_color=self.colors["bg_input"],
            segmented_button_selected_color=self.colors["accent"],
            segmented_button_unselected_color=self.colors["bg_card"],
            border_width=1,
            border_color=self.colors["border"],
        )
        self.tabview.pack(fill="both", expand=True, pady=4)

        self.tab_dashboard = self.tabview.add("Dashboard")
        self.tab_network = self.tabview.add("Network Adapters")
        self.tab_hardware = self.tabview.add("Hardware vs WMI")
        self.tab_backup = self.tabview.add("Backup & Restore")
        self.tab_diagnostics = self.tabview.add("Diagnostics")
        self.tab_logs = self.tabview.add("Logs & History")

        self.build_dashboard_tab()
        self.build_network_tab()
        self.build_hardware_tab()
        self.build_backup_tab()
        self.build_diagnostics_tab()
        self.build_logs_tab()

        self.create_status_bar()

    def create_header(self) -> None:
        header_frame = ctk.CTkFrame(
            self, height=54, corner_radius=0, fg_color=self.colors["bg_dark"], border_width=0
        )
        header_frame.pack(fill="x", padx=0, pady=0)
        header_frame.pack_propagate(False)

        self.title_label = ctk.CTkLabel(
            header_frame,
            text=f"{Details.applicationName}",
            font=("Orbitron", 20, "bold"),
            text_color=self.colors["primary"],
            anchor="w",
        )
        self.title_label.pack(side="left", padx=16)

        right_controls = ctk.CTkFrame(header_frame, fg_color="transparent")
        right_controls.pack(side="right", padx=16)

        admin_txt = "ADMIN: YES" if is_admin() else "ADMIN: NO (Read-Only)"
        admin_clr = self.colors["success"] if is_admin() else self.colors["warning"]
        self.admin_badge = ctk.CTkLabel(
            right_controls,
            text=admin_txt,
            font=("Consolas", 11, "bold"),
            text_color=admin_clr,
        )
        self.admin_badge.pack(side="left", padx=10)

        self.op_state_badge = ctk.CTkLabel(
            right_controls,
            textvariable=self.op_state_var,
            font=("Consolas", 11, "bold"),
            text_color=self.colors["primary"],
        )
        self.op_state_badge.pack(side="left", padx=10)

    # =========================================================================
    # TAB 1: DASHBOARD
    # =========================================================================
    def build_dashboard_tab(self) -> None:
        self.info_frame = ctk.CTkFrame(
            self.tab_dashboard,
            corner_radius=12,
            fg_color=self.colors["bg_card"],
            border_width=1,
            border_color=self.colors["border"],
        )
        self.info_frame.pack(fill="both", expand=True, pady=4)

        self.actions_frame = ctk.CTkFrame(
            self.tab_dashboard,
            corner_radius=12,
            fg_color=self.colors["bg_card"],
            border_width=1,
            border_color=self.colors["accent"],
        )
        self.actions_frame.pack(fill="x", pady=4)

        self.create_info_section()
        self.create_actions_section()

    def create_info_section(self) -> None:
        header_frame = ctk.CTkFrame(self.info_frame, fg_color="transparent")
        header_frame.pack(fill="x", padx=16, pady=5)

        ctk.CTkLabel(
            header_frame,
            text="SYSTEM FINGERPRINT & STATUS OVERVIEW",
            compound="left",
            image=self.images.get("system"),
            font=("Orbitron", 14, "bold"),
            text_color=self.colors["primary"],
            anchor="w",
        ).pack(side="left")

        is_mod = self.spoofer.check_spoofer_installed()
        status = self.MANIPULATED_STATUS if is_mod else self.NORMAL_STATUS
        color = self.colors["gold"] if is_mod else self.colors["success"]

        self.system_status = ctk.CTkLabel(
            header_frame,
            text=f"● {status}",
            font=("Consolas", 11, "bold"),
            text_color=color,
            anchor="e",
        )
        self.system_status.pack(side="right", padx=5)

        self.info_scrollable_frame = ctk.CTkScrollableFrame(
            self.info_frame,
            fg_color=self.colors["bg_card"],
            scrollbar_button_color=self.colors["accent"],
            scrollbar_button_hover_color=self.colors["accent"],
        )
        self.info_scrollable_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        self.add_info_cards()

    def add_info_cards(self) -> None:
        self.info_items = [
            ("MAC ADDRESS", self.images.get("network"), "MAC", self.colors["gold"]),
            ("MOTHERBOARD (WMI)", self.images.get("mobo"), "MOTHERBOARD", self.colors["gold"]),
            ("SYSTEM UUID (WMI)", self.images.get("id"), "UUID", self.colors["gold"]),
            ("SSD/HDD SERIALS", self.images.get("ssd"), "DISKS", self.colors["gold"]),
            ("BIOS SERIAL", self.images.get("bios"), "BIOS", self.colors["gold"]),
            ("MEMORY SERIALS", self.images.get("ram"), "MEMORY", self.colors["gold"]),
            ("CPU ID", self.images.get("bios"), "CPU_ID", self.colors["gold"]),
            ("ENCLOSURE", self.images.get("system"), "ENCLOSURE", self.colors["gold"]),
        ]

        columns = []
        for _ in range(2):
            col = ctk.CTkFrame(self.info_scrollable_frame, fg_color="transparent")
            col.pack(side="left", fill="both", expand=True, padx=5)
            columns.append(col)

        for i, (label, icon, key, color) in enumerate(self.info_items):
            target_col = columns[i % 2]
            card, lbl_widget = self.create_modern_info_card(
                target_col, label, icon, self.pc_info.get(key, "Unknown"), color
            )
            self.cards[key] = card
            self.card_labels[key] = lbl_widget

    def create_modern_info_card(self, parent: Any, label: str, icon: Any, value: str, accent_color: str):
        card_frame = ctk.CTkFrame(
            parent,
            corner_radius=10,
            fg_color=self.colors["bg_input"],
            border_width=1,
            border_color=accent_color,
        )
        card_frame.pack(fill="both", expand=True, padx=5, pady=4)

        label_frame = ctk.CTkFrame(card_frame, fg_color="transparent")
        label_frame.pack(fill="x", padx=10, pady=(6, 2))

        ctk.CTkLabel(
            label_frame,
            text=" " + label,
            compound="left",
            image=icon,
            font=("Consolas", 12, "bold"),
            text_color=accent_color,
            anchor="w",
        ).pack(side="left")

        val_label = ctk.CTkLabel(
            card_frame,
            text=value or "Unknown",
            font=("Consolas", 11),
            text_color=self.colors["text_primary"],
            anchor="w",
            width=320,
            wraplength=320,
            justify="left",
        )
        val_label.pack(fill="x", padx=10, pady=(0, 8))
        return card_frame, val_label

    def create_actions_section(self) -> None:
        main_container = ctk.CTkFrame(self.actions_frame, fg_color="transparent")
        main_container.pack(fill="x", expand=True, padx=10, pady=8)

        self.buttons_container = ctk.CTkFrame(main_container, fg_color="transparent")
        self.buttons_container.pack(pady=4, fill="x")
        for c in range(5):
            self.buttons_container.grid_columnconfigure(c, weight=1)

        self.spoof_btn = ctk.CTkButton(
            self.buttons_container,
            text="APPLY CONFIG",
            compound="left",
            image=self.images.get("start"),
            command=self.start_spoofing,
            width=145,
            height=34,
            font=("Orbitron", 12, "bold"),
            fg_color=self.colors["bg_card"],
            hover_color=self.colors["secondary"],
            border_width=1,
            border_color=self.colors["accent"],
            corner_radius=16,
        )
        self.spoof_btn.grid(row=0, column=0, padx=4)

        self.regen_btn = ctk.CTkButton(
            self.buttons_container,
            text="RESTORE ALL",
            image=self.images.get("restore"),
            compound="left",
            command=self.remove_spoof,
            width=145,
            height=34,
            font=("Orbitron", 12, "bold"),
            fg_color=self.colors["bg_card"],
            hover_color="#ca1a1a",
            border_width=1,
            border_color=self.colors["warning"],
            corner_radius=16,
        )
        self.regen_btn.grid(row=0, column=1, padx=4)

        self.adv_btn = ctk.CTkButton(
            self.buttons_container,
            text="CONFIGURE",
            image=self.images.get("system"),
            compound="left",
            command=self.open_custom_spoof_window,
            width=145,
            height=34,
            font=("Orbitron", 12, "bold"),
            fg_color=self.colors["bg_card"],
            hover_color=self.colors["secondary"],
            border_width=1,
            border_color=self.colors["accent"],
            corner_radius=16,
        )
        self.adv_btn.grid(row=0, column=2, padx=4)

        self.save_btn = ctk.CTkButton(
            self.buttons_container,
            text="SERIALS",
            image=self.images.get("save"),
            compound="left",
            command=self.save_or_compare,
            width=145,
            height=34,
            font=("Orbitron", 12, "bold"),
            fg_color=self.colors["bg_card"],
            hover_color=self.colors["secondary"],
            border_width=1,
            border_color=self.colors["accent"],
            corner_radius=16,
        )
        self.save_btn.grid(row=0, column=3, padx=4)

        self.export_diag_btn = ctk.CTkButton(
            self.buttons_container,
            text="EXPORT REPORT",
            image=self.images.get("clean"),
            compound="left",
            command=self.export_diagnostic_report_ui,
            width=155,
            height=34,
            font=("Orbitron", 12, "bold"),
            fg_color=self.colors["bg_card"],
            hover_color=self.colors["secondary"],
            border_width=1,
            border_color=self.colors["gold"],
            corner_radius=16,
        )
        self.export_diag_btn.grid(row=0, column=4, padx=4)

    # =========================================================================
    # TAB 2: NETWORK ADAPTER MANAGER
    # =========================================================================
    def build_network_tab(self) -> None:
        top_bar = ctk.CTkFrame(self.tab_network, fg_color="transparent")
        top_bar.pack(fill="x", padx=10, pady=6)

        ctk.CTkLabel(
            top_bar,
            text="NETWORK & MAC MANAGER",
            font=("Orbitron", 12, "bold"),
            text_color=self.colors["primary"],
        ).pack(side="left")

        self.show_virtual_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            top_bar,
            text="Show Virtual",
            variable=self.show_virtual_var,
            command=self.refresh_network_tab,
            font=("Consolas", 10),
        ).pack(side="right", padx=4)

        self.force_uaa_var = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(
            top_bar,
            text="Force UAA (No Rollback)",
            variable=self.force_uaa_var,
            font=("Consolas", 10, "bold"),
            text_color=self.colors["gold"],
        ).pack(side="right", padx=4)

        ctk.CTkButton(
            top_bar,
            text="⚡ UAA KERNEL PATCHER",
            width=165,
            height=28,
            command=self.open_uaa_bypass_window,
            fg_color=self.colors["gold"],
            text_color="#000000",
            font=("Consolas", 10, "bold"),
        ).pack(side="right", padx=4)

        ctk.CTkButton(
            top_bar,
            text="Refresh",
            width=80,
            height=28,
            command=self.refresh_network_tab,
            fg_color=self.colors["accent"],
        ).pack(side="right", padx=4)

        self.net_list_frame = ctk.CTkScrollableFrame(
            self.tab_network, fg_color=self.colors["bg_input"], corner_radius=10
        )
        self.net_list_frame.pack(fill="both", expand=True, padx=10, pady=6)

        self.adapter_ui_rows: List[Dict[str, Any]] = []
        self.refresh_network_tab()

    def refresh_network_tab(self) -> None:
        for child in self.net_list_frame.winfo_children():
            child.destroy()
        self.adapter_ui_rows.clear()

        include_virt = bool(self.show_virtual_var.get())
        adapters = self.spoofer.MOFM.get_detailed_network_adapters(include_virtual=include_virt)
        if not adapters:
            ctk.CTkLabel(
                self.net_list_frame,
                text="No matching network adapters found.",
                text_color=self.colors["warning"],
            ).pack(pady=15)
            return

        for ad in adapters:
            row = ctk.CTkFrame(
                self.net_list_frame,
                fg_color=self.colors["bg_card"],
                corner_radius=8,
                border_width=1,
                border_color=self.colors["border"],
            )
            row.pack(fill="x", padx=6, pady=4)

            net_id = str(ad.get("net_connection_id") or ad.get("name"))
            kind = str(ad.get("adapter_kind", "Ethernet"))
            mac = str(ad.get("mac_address", "Unknown"))
            is_virt = bool(ad.get("is_virtual"))
            supported = bool(ad.get("supports_mac_override"))

            sel_var = ctk.BooleanVar(value=False)
            mac_var = ctk.StringVar(value="")

            badge = "[VIRTUAL - EXCLUDED]" if is_virt else f"[{kind}]"
            cb = ctk.CTkCheckBox(
                row,
                text=f"{net_id} {badge} | Current MAC: {mac}",
                variable=sel_var,
                state="disabled" if (kind == "Bluetooth" or (is_virt and not self.show_virtual_var.get())) else "normal",
                font=("Consolas", 11, "bold"),
            )
            cb.pack(side="left", padx=8, pady=8)

            ent = ctk.CTkEntry(
                row,
                textvariable=mac_var,
                width=165,
                placeholder_text="XX:XX:XX:XX:XX:XX",
                fg_color=self.colors["bg_input"],
            )
            ent.pack(side="left", padx=6)

            def _gen_mac(v=mac_var):
                v.set(self.spoofer.generate_valid_unicast_laa_mac(colon_separated=True))

            ctk.CTkButton(
                row,
                text="Random LAA",
                width=85,
                height=26,
                command=_gen_mac,
                fg_color=self.colors["accent"],
            ).pack(side="left", padx=4)

            def _apply_single(adapter_dict=ad, m_var=mac_var):
                target_id = str(adapter_dict.get("net_connection_id") or adapter_dict.get("name"))
                target_mac = m_var.get().strip() or self.spoofer.generate_valid_unicast_laa_mac(True)
                force_uaa = bool(self.force_uaa_var.get())
                allow_virt = bool(self.show_virtual_var.get()) or bool(adapter_dict.get("is_virtual"))
                self.set_operation_state(OperationState.RUNNING, f"Updating MAC for {target_id}...")

                def _wrk():
                    ok, msg = self.spoofer.spoof_mac_address(
                        mac_addresses={target_id: target_mac},
                        selected_adapters=[target_id],
                        allow_virtual=allow_virt,
                        auto_normalize_laa=False,
                        force_keep_uaa_registry=force_uaa,
                    )
                    st = OperationState.COMPLETED if ok else OperationState.FAILED
                    self.ui_dispatch(self.set_operation_state, st, msg)
                    self.ui_dispatch(
                        messagebox.showinfo if ok else messagebox.showerror,
                        "Network Adapter Update",
                        msg,
                    )
                    self.ui_dispatch(self.refresh_network_tab)
                    self.refresh_pc_info_async()

                threading.Thread(target=_wrk, daemon=True).start()

            ctk.CTkButton(
                row,
                text="Apply",
                width=65,
                height=26,
                state="disabled" if (kind == "Bluetooth" or (is_virt and not self.show_virtual_var.get())) else "normal",
                command=_apply_single,
                fg_color=self.colors["success"],
                text_color="#000000",
            ).pack(side="left", padx=4)

            self.adapter_ui_rows.append({"adapter": ad, "selected": sel_var, "mac": mac_var})

    def open_uaa_bypass_window(self) -> None:
        """Open the dedicated UAA MAC Bypass & Kernel Driver Patcher center (for 28:98:7B:4A:1F:9C)."""
        w = ctk.CTkToplevel(self)
        w.title("UAA MAC Bypass & Kernel Driver Patcher (28:98:7B:4A:1F:9C)")
        w.geometry("760x640")
        w.configure(fg_color=self.colors["bg_dark"])
        w.grab_set()

        ctk.CTkLabel(
            w,
            text="UAA MAC BYPASS ENGINE (INTEL WI-FI Netwtw10.sys / wdiwifi.sys)",
            font=("Orbitron", 14, "bold"),
            text_color=self.colors["gold"],
        ).pack(pady=(10, 4))

        target_frame = ctk.CTkFrame(w, fg_color=self.colors["bg_card"])
        target_frame.pack(fill="x", padx=12, pady=6)

        ctk.CTkLabel(target_frame, text="Target UAA MAC:", font=("Consolas", 12, "bold")).pack(side="left", padx=8, pady=8)
        uaa_mac_var = ctk.StringVar(value="28:98:7B:4A:1F:9C")
        ctk.CTkEntry(target_frame, textvariable=uaa_mac_var, width=190, font=("Consolas", 12, "bold")).pack(side="left", padx=6)

        out_box = ctk.CTkTextbox(w, fg_color=self.colors["bg_input"], text_color=self.colors["text_primary"], font=("Consolas", 11), height=320)
        out_box.pack(fill="both", expand=True, padx=12, pady=6)

        def _log_uaa(text: str) -> None:
            self.ui_dispatch(self._set_textbox, out_box, text)

        def _scan_drivers() -> None:
            _log_uaa("Scanning Windows System32\\drivers\\wdiwifi.sys and Netwtw*.sys for UAA Bit-1 locks...")
            def _wrk():
                res = self.spoofer.UAA.scan_system_wifi_drivers()
                _log_uaa(json.dumps(res, indent=2, ensure_ascii=False))
            threading.Thread(target=_wrk, daemon=True).start()

        def _patch_drivers() -> None:
            if not messagebox.askyesno(
                "Confirm Kernel Driver UAA Patch",
                "This will create a SHA-256 verified backup of wdiwifi.sys & Netwtw*.sys in backups/drivers/, "
                "patch the LAA Bit-1 check so 28:98:7B:4A:1F:9C is accepted, recalculate the PE Checksum, "
                "and enable Windows Test Signing (requires Secure Boot OFF + Reboot).\n\nProceed?",
            ):
                return
            _log_uaa("Backing up and patching Wi-Fi kernel drivers...")
            def _wrk():
                drv_files = self.spoofer.UAA.locate_wifi_driver_files()
                reports = []
                for fpath in drv_files:
                    reports.append(self.spoofer.UAA.backup_and_patch_driver_file(fpath, apply_in_place=True))
                _log_uaa(json.dumps(reports, indent=2, ensure_ascii=False))
            threading.Thread(target=_wrk, daemon=True).start()

        def _hyperv_bridge() -> None:
            target_mac = uaa_mac_var.get().strip()
            _log_uaa(f"Configuring Hyper-V External Virtual Switch Bridge with UAA MAC {target_mac}...")
            def _wrk():
                adapters = self.spoofer.MOFM.get_detailed_network_adapters(include_virtual=False)
                wifi_ad = next((a for a in adapters if a.get("adapter_kind") == "Wi-Fi"), adapters[0] if adapters else {})
                desc = str(wifi_ad.get("name") or "Intel(R) Wi-Fi 6 AX201 160MHz")
                ok, msg = self.spoofer.UAA.configure_hyperv_uaa_bridge(desc, target_mac)
                _log_uaa(f"Status: {'SUCCESS' if ok else 'INFO/ERROR'}\n\n{msg}")
                self.ui_dispatch(self.refresh_network_tab)
            threading.Thread(target=_wrk, daemon=True).start()

        def _restore_drivers() -> None:
            def _wrk():
                rep = self.spoofer.UAA.restore_original_drivers()
                _log_uaa(json.dumps(rep, indent=2, ensure_ascii=False))
            threading.Thread(target=_wrk, daemon=True).start()

        btn_grid = ctk.CTkFrame(w, fg_color="transparent")
        btn_grid.pack(fill="x", padx=12, pady=8)
        for col in range(4):
            btn_grid.grid_columnconfigure(col, weight=1)

        ctk.CTkButton(btn_grid, text="1. Scan Drivers", command=_scan_drivers, fg_color=self.colors["accent"]).grid(row=0, column=0, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(btn_grid, text="2. Patch wdiwifi/Netwtw", command=_patch_drivers, fg_color=self.colors["gold"], text_color="#000000").grid(row=0, column=1, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(btn_grid, text="3. Hyper-V UAA Bridge", command=_hyperv_bridge, fg_color=self.colors["success"], text_color="#000000").grid(row=0, column=2, padx=4, pady=4, sticky="ew")
        ctk.CTkButton(btn_grid, text="4. Restore Orig Drivers", command=_restore_drivers, fg_color=self.colors["warning"]).grid(row=0, column=3, padx=4, pady=4, sticky="ew")

        _scan_drivers()

    # =========================================================================
    # TAB 3: HARDWARE INFORMATION (REAL HARDWARE VS WMI + BITLOCKER)
    # =========================================================================
    def build_hardware_tab(self) -> None:
        top = ctk.CTkFrame(self.tab_hardware, fg_color="transparent")
        top.pack(fill="x", padx=10, pady=6)
        ctk.CTkLabel(
            top,
            text="REAL HARDWARE / FIRMWARE vs. WMI LAYER & DISK BITLOCKER STATUS",
            font=("Orbitron", 13, "bold"),
            text_color=self.colors["primary"],
        ).pack(side="left")

        ctk.CTkButton(
            top,
            text="Refresh Comparison",
            width=140,
            height=28,
            command=self.refresh_hardware_comparison_async,
            fg_color=self.colors["accent"],
        ).pack(side="right")

        self.hw_textbox = ctk.CTkTextbox(
            self.tab_hardware,
            fg_color=self.colors["bg_input"],
            text_color=self.colors["text_primary"],
            font=("Consolas", 11),
        )
        self.hw_textbox.pack(fill="both", expand=True, padx=10, pady=6)
        self.refresh_hardware_comparison_async()

    def refresh_hardware_comparison_async(self) -> None:
        def _wrk():
            comp = self.spoofer.MOFM.get_hardware_vs_wmi_comparison()
            disks = self.spoofer.inspect_disks_and_bitlocker()
            text = json.dumps(
                {"Hardware_vs_WMI": comp, "Disks_and_BitLocker": disks},
                indent=2,
                ensure_ascii=False,
            )
            self.ui_dispatch(self._set_textbox, self.hw_textbox, text)

        threading.Thread(target=_wrk, daemon=True).start()

    # =========================================================================
    # TAB 4: BACKUP MANAGER & RESTORE CENTER
    # =========================================================================
    def build_backup_tab(self) -> None:
        ctrl = ctk.CTkFrame(self.tab_backup, fg_color="transparent")
        ctrl.pack(fill="x", padx=10, pady=6)

        ctk.CTkButton(
            ctrl,
            text="Create Full Verified Backup",
            command=self.create_verified_backup_ui,
            fg_color=self.colors["success"],
            text_color="#000000",
            font=("Consolas", 12, "bold"),
        ).pack(side="left", padx=5)

        ctk.CTkButton(
            ctrl,
            text="Undo Last Transaction (Rollback)",
            command=self.undo_last_tx_ui,
            fg_color=self.colors["gold"],
            text_color="#000000",
            font=("Consolas", 12, "bold"),
        ).pack(side="left", padx=5)

        ctk.CTkButton(
            ctrl,
            text="Restore Selected Backup...",
            command=self.import_serials,
            fg_color=self.colors["accent"],
            font=("Consolas", 12, "bold"),
        ).pack(side="left", padx=5)

        ctk.CTkButton(
            ctrl,
            text="Refresh List",
            command=self.refresh_backup_tab,
            fg_color=self.colors["bg_input"],
        ).pack(side="right", padx=5)

        self.backup_textbox = ctk.CTkTextbox(
            self.tab_backup,
            fg_color=self.colors["bg_input"],
            text_color=self.colors["text_primary"],
            font=("Consolas", 11),
        )
        self.backup_textbox.pack(fill="both", expand=True, padx=10, pady=6)
        self.refresh_backup_tab()

    def refresh_backup_tab(self) -> None:
        bkp_diag = self.diagnostics.diagnose_backups()
        self._set_textbox(self.backup_textbox, json.dumps(bkp_diag, indent=2, ensure_ascii=False))

    def create_verified_backup_ui(self) -> None:
        self.set_operation_state(OperationState.RUNNING, "Creating SHA-256 verified system backup...")

        def _wrk():
            bt = self.spoofer.get_bluetooth_state()
            path = self.bum.backup_hardware_info(bluetooth_state=bt)
            if path:
                self.ui_dispatch(self.set_operation_state, OperationState.COMPLETED, f"Backup saved: {path}")
                self.ui_dispatch(messagebox.showinfo, "Backup Created", f"Verified backup created at:\n{path}")
            else:
                self.ui_dispatch(self.set_operation_state, OperationState.FAILED, "Failed to create backup")
                self.ui_dispatch(messagebox.showerror, "Backup Failed", "Could not create or verify backup file.")
            self.ui_dispatch(self.refresh_backup_tab)

        threading.Thread(target=_wrk, daemon=True).start()

    def undo_last_tx_ui(self) -> None:
        self.set_operation_state(OperationState.RUNNING, "Rolling back last transaction...")

        def _wrk():
            rep = self.bum.undo_last_transaction(spoofer_service=self.spoofer)
            overall = rep.get("overall_status", OperationState.FAILED.value)
            st = (
                OperationState.COMPLETED
                if overall == OperationState.COMPLETED.value
                else (
                    OperationState.PARTIALLY_COMPLETED
                    if overall == OperationState.PARTIALLY_COMPLETED.value
                    else OperationState.FAILED
                )
            )
            self.ui_dispatch(self.set_operation_state, st, rep.get("summary_message", ""))
            self.ui_dispatch(
                messagebox.showinfo if st != OperationState.FAILED else messagebox.showerror,
                f"Rollback Result: {overall}",
                json.dumps(rep, indent=2, ensure_ascii=False),
            )
            self.ui_dispatch(self.refresh_backup_tab)
            self.refresh_pc_info_async()

        threading.Thread(target=_wrk, daemon=True).start()

    # =========================================================================
    # TAB 5: SYSTEM DIAGNOSTICS
    # =========================================================================
    def build_diagnostics_tab(self) -> None:
        ctrl = ctk.CTkFrame(self.tab_diagnostics, fg_color="transparent")
        ctrl.pack(fill="x", padx=10, pady=6)

        self.diag_local_only_var = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(
            ctrl,
            text="Local-Only Network Check (Do not send Public IP to external service)",
            variable=self.diag_local_only_var,
            font=("Consolas", 11),
        ).pack(side="left", padx=6)

        ctk.CTkButton(
            ctrl,
            text="Run Full System Diagnostics",
            command=self.run_diagnostics_ui,
            fg_color=self.colors["primary"],
            text_color="#000000",
            font=("Consolas", 12, "bold"),
        ).pack(side="right", padx=6)

        self.diag_textbox = ctk.CTkTextbox(
            self.tab_diagnostics,
            fg_color=self.colors["bg_input"],
            text_color=self.colors["text_primary"],
            font=("Consolas", 11),
        )
        self.diag_textbox.pack(fill="both", expand=True, padx=10, pady=6)

    def run_diagnostics_ui(self) -> None:
        self.set_operation_state(OperationState.RUNNING, "Running comprehensive system diagnostics...")
        local_only = bool(self.diag_local_only_var.get())

        def _wrk():
            rep = self.diagnostics.run_all_diagnostics(local_only_network=local_only)
            txt = json.dumps(rep, indent=2, ensure_ascii=False)
            self.ui_dispatch(self._set_textbox, self.diag_textbox, txt)
            self.ui_dispatch(self.set_operation_state, OperationState.COMPLETED, "System diagnostics completed.")

        threading.Thread(target=_wrk, daemon=True).start()

    # =========================================================================
    # TAB 6: ERROR LOGS & OPERATION HISTORY
    # =========================================================================
    def build_logs_tab(self) -> None:
        ctrl = ctk.CTkFrame(self.tab_logs, fg_color="transparent")
        ctrl.pack(fill="x", padx=10, pady=6)

        self.errors_only_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            ctrl,
            text="Show Errors/Blocked Only",
            variable=self.errors_only_var,
            command=self.refresh_logs_tab,
            font=("Consolas", 11),
        ).pack(side="left", padx=6)

        ctk.CTkButton(
            ctrl,
            text="Export Diagnostic Report",
            command=self.export_diagnostic_report_ui,
            fg_color=self.colors["gold"],
            text_color="#000000",
            font=("Consolas", 12, "bold"),
        ).pack(side="right", padx=6)

        ctk.CTkButton(
            ctrl,
            text="Refresh Logs",
            command=self.refresh_logs_tab,
            fg_color=self.colors["accent"],
        ).pack(side="right", padx=6)

        self.logs_textbox = ctk.CTkTextbox(
            self.tab_logs,
            fg_color=self.colors["bg_input"],
            text_color=self.colors["text_primary"],
            font=("Consolas", 11),
        )
        self.logs_textbox.pack(fill="both", expand=True, padx=10, pady=6)
        self.refresh_logs_tab()

    def refresh_logs_tab(self) -> None:
        entries = DEFAULT_LOGGER.get_history(limit=150, errors_only=bool(self.errors_only_var.get()))
        self._set_textbox(self.logs_textbox, json.dumps(entries, indent=2, ensure_ascii=False))

    def export_diagnostic_report_ui(self) -> None:
        filepath = filedialog.asksaveasfilename(
            title="Export Sanitized Diagnostic Report",
            defaultextension=".json",
            initialfile=f"diagnostic_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
            filetypes=[("JSON Report", "*.json")],
        )
        if not filepath:
            return
        self.set_operation_state(OperationState.RUNNING, "Exporting sanitized diagnostic report...")

        def _wrk():
            diag_data = self.diagnostics.run_all_diagnostics(local_only_network=True)
            bkp_data = self.diagnostics.diagnose_backups()
            out = DEFAULT_LOGGER.export_diagnostic_report(
                output_path=filepath,
                diagnostics_data=diag_data,
                backup_summary=bkp_data,
            )
            self.ui_dispatch(self.set_operation_state, OperationState.COMPLETED, f"Diagnostic report exported: {out}")
            self.ui_dispatch(
                messagebox.showinfo,
                "Diagnostic Report Exported",
                f"Sanitized diagnostic report saved to:\n{out}\n\n"
                "(Sensitive license keys, tokens, and public IPs were automatically redacted.)",
            )
            self.ui_dispatch(self.refresh_logs_tab)

        threading.Thread(target=_wrk, daemon=True).start()

    @staticmethod
    def _set_textbox(textbox: ctk.CTkTextbox, content: str) -> None:
        textbox.configure(state="normal")
        textbox.delete("1.0", "end")
        textbox.insert("1.0", content)
        textbox.configure(state="normal")

    # =========================================================================
    # STATUS BAR & STATE MANAGEMENT
    # =========================================================================
    def create_status_bar(self) -> None:
        status_frame = ctk.CTkFrame(
            self,
            height=36,
            corner_radius=0,
            fg_color=self.colors["bg_card"],
            border_width=1,
            border_color=self.colors["border"],
        )
        status_frame.pack(fill="x", padx=0, pady=0, side="bottom")
        status_frame.pack_propagate(False)

        self.status_indicator = ctk.CTkLabel(
            status_frame, text="●", font=("Arial", 14), text_color=self.colors["success"]
        )
        self.status_indicator.pack(side="left", padx=(12, 6), pady=6)

        self.status_label = ctk.CTkLabel(
            status_frame,
            textvariable=self.status_text,
            font=("Consolas", 10, "bold"),
            text_color=self.colors["text_primary"],
            anchor="w",
        )
        self.status_label.pack(side="left", fill="x", expand=True, pady=6)

    def set_operation_state(self, state: OperationState, message: Optional[str] = None) -> None:
        self.current_op_state = state
        self.op_state_var.set(f"STATE: {state.value.upper()}")
        state_to_type = {
            OperationState.READY: "info",
            OperationState.RUNNING: "info",
            OperationState.COMPLETED: "success",
            OperationState.PARTIALLY_COMPLETED: "warning",
            OperationState.FAILED: "error",
            OperationState.REQUIRES_RESTART: "warning",
        }
        if message:
            self.update_status(message, status_type=state_to_type.get(state, "info"))

    def update_status(self, message: str, status_type: str = "info") -> None:
        """Thread-safe status bar updater (never calls self.update() from a worker thread)."""
        def _apply():
            colors = {
                "info": self.colors["text_primary"],
                "success": self.colors["success"],
                "warning": self.colors["gold"],
                "error": self.colors["warning"],
            }
            self.status_text.set(message)
            self.status_label.configure(text_color=colors.get(status_type, colors["info"]))
            self.status_indicator.configure(text_color=colors.get(status_type, colors["info"]))

        self.ui_dispatch(_apply)

    # =========================================================================
    # CORE ACTIONS (THREAD-SAFE)
    # =========================================================================
    def start_spoofing(self) -> None:
        if self.spoofing_in_progress:
            return
        if not self.custom_config:
            messagebox.showwarning(
                "Configuration Required",
                "For system safety, blind modification of all components is disabled.\n"
                "Please click CONFIGURE (or use the Network Adapters tab) to select specific components first.",
            )
            self.open_custom_spoof_window()
            return

        self.spoofing_in_progress = True
        self.spoof_btn.configure(state="disabled", text="RUNNING..")
        self.set_operation_state(OperationState.RUNNING, "Applying selected configuration safely...")
        threading.Thread(target=self.simulate_spoofing, daemon=True).start()

    def simulate_spoofing(self) -> None:
        try:
            sw, messages = self.spoofer.install_service(config=self.custom_config)
            summary_text = "\n".join(messages)
            requires_restart = any("Requires Restart" in m for m in messages)

            if sw:
                final_state = OperationState.REQUIRES_RESTART if requires_restart else OperationState.COMPLETED
                self.ui_dispatch(self.set_operation_state, final_state, "Operation completed.")
                self.ui_dispatch(
                    messagebox.showinfo,
                    final_state.value,
                    f"Operation finished ({final_state.value}):\n\n{summary_text}",
                )
            else:
                has_partial = any(m.startswith("• Network MAC:") or m.startswith("• Windows Hostname:") or m.startswith("• Partition Volume Serial: Updated") for m in messages)
                final_state = OperationState.PARTIALLY_COMPLETED if has_partial else OperationState.FAILED
                self.ui_dispatch(self.set_operation_state, final_state, f"Operation {final_state.value}")
                self.ui_dispatch(
                    messagebox.showwarning if has_partial else messagebox.showerror,
                    final_state.value,
                    f"Operation status: {final_state.value}\n\n{summary_text}",
                )
            self.refresh_pc_info_async()
            self.ui_dispatch(self.refresh_logs_tab)
        except Exception as e:
            self.ui_dispatch(self.set_operation_state, OperationState.FAILED, f"Error: {e}")
        finally:
            self.spoofing_in_progress = False
            self.ui_dispatch(lambda: self.spoof_btn.configure(state="normal", text="APPLY CONFIG"))

    def remove_spoof(self) -> None:
        if self.spoofing_in_progress:
            return
        if messagebox.askyesno(
            "Confirm Restoration",
            "This will restore all tool-managed changes from the verified backup and report each item's status.\n\nContinue?",
        ):
            self.spoofing_in_progress = True
            self.regen_btn.configure(state="disabled", text="RESTORING..")
            self.set_operation_state(OperationState.RUNNING, "Restoring original identifiers...")
            threading.Thread(target=self.simulate_restore, daemon=True).start()

    def simulate_restore(self) -> None:
        try:
            ok, report = self.spoofer.uninstall_service(service=False)
            overall_str = report.get("overall_status", OperationState.FAILED.value)
            state_map = {
                OperationState.COMPLETED.value: OperationState.COMPLETED,
                OperationState.PARTIALLY_COMPLETED.value: OperationState.PARTIALLY_COMPLETED,
                OperationState.FAILED.value: OperationState.FAILED,
            }
            st = state_map.get(overall_str, OperationState.PARTIALLY_COMPLETED if ok else OperationState.FAILED)
            self.ui_dispatch(self.set_operation_state, st, report.get("summary_message", ""))

            lines = [
                f"Overall Status: {overall_str}",
                f"Restored Items: {len(report.get('restored_items', []))}",
                f"Failed Items: {len(report.get('failed_items', []))}",
                f"Read-Only Hardware Items (Unchanged): {len(report.get('non_restorable_items', []))}",
                "",
            ]
            for r in report.get("restored_items", []):
                lines.append(f"[RESTORED] {r.get('item')}: {r.get('status')}")
            for f in report.get("failed_items", []):
                lines.append(f"[FAILED] {f.get('item')}: {f.get('reason')}")
            for nr in report.get("non_restorable_items", [])[:5]:
                lines.append(f"[READ-ONLY] {nr.get('item')}: {nr.get('reason')}")

            self.ui_dispatch(
                messagebox.showinfo if ok else messagebox.showwarning,
                f"Restoration Report — {overall_str}",
                "\n".join(lines),
            )
            self.refresh_pc_info_async()
            self.ui_dispatch(self.refresh_logs_tab)
        except Exception as e:
            self.ui_dispatch(self.set_operation_state, OperationState.FAILED, f"Restore failed: {e}")
            self.ui_dispatch(messagebox.showerror, "Restore Error", str(e))
        finally:
            self.spoofing_in_progress = False
            self.ui_dispatch(lambda: self.regen_btn.configure(state="normal", text="RESTORE ALL"))

    def save_or_compare(self) -> None:
        switcher = ctk.CTkFrame(
            self.buttons_container, fg_color=self.buttons_container.cget("fg_color"), corner_radius=15
        )
        switcher.place(relx=0.5, rely=0.5, anchor="center", relwidth=1)
        for i in range(5):
            switcher.grid_columnconfigure(i, weight=1)

        ctk.CTkButton(
            switcher, text="Save INI", command=self.save_serials, width=100, height=32, fg_color=self.colors["accent"]
        ).grid(row=0, column=0)
        ctk.CTkButton(
            switcher, text="Compare", command=self.compare_serials, width=100, height=32, fg_color=self.colors["accent"]
        ).grid(row=0, column=1)
        ctk.CTkButton(
            switcher, text="Export JSON", command=self.export_serials, width=100, height=32, fg_color=self.colors["accent"]
        ).grid(row=0, column=2)
        ctk.CTkButton(
            switcher, text="Import JSON", command=self.import_serials, width=100, height=32, fg_color=self.colors["accent"]
        ).grid(row=0, column=3)
        ctk.CTkButton(
            switcher, text="Close", command=switcher.destroy, width=100, height=32, fg_color=self.colors["warning"]
        ).grid(row=0, column=4)

    def compare_serials(self) -> None:
        try:
            filepath = filedialog.askopenfilename(
                title="Select saved serials file",
                filetypes=[("INI files", "*.ini"), ("All files", "*.*")],
            )
            if not filepath:
                return
            saved_data: Dict[str, str] = {}
            with open(filepath, "r", encoding="utf-8") as f:
                for line in f:
                    if "=" in line:
                        key, value = line.strip().split("=", 1)
                        saved_data[key] = value

            mismatches = 0
            for _, _, key, default_color in self.info_items:
                current_value = str(self.pc_info.get(key, "Unknown")).split(",")[0].strip()
                saved_value = str(saved_data.get(key, "N/A")).replace(",", "").strip()
                card = self.cards.get(key)
                if not card:
                    continue
                if current_value != saved_value:
                    mismatches += 1
                    card.configure(border_color=self.colors["accent"])
                else:
                    card.configure(border_color=default_color)

            messagebox.showinfo("Comparison Result", f"Differences detected: {mismatches} / {len(self.info_items)}")
            self.set_operation_state(OperationState.COMPLETED, "Comparison finished.")
        except Exception as e:
            self.set_operation_state(OperationState.FAILED, f"Compare failed: {e}")

    def save_serials(self) -> None:
        try:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"serials_backup_{timestamp}.ini"
            lines = [f"{k}={self.pc_info.get(k, 'Unknown')}" for k in ("MAC", "MOTHERBOARD", "UUID", "DISKS", "BIOS", "MEMORY", "CPU_ID", "ENCLOSURE")]
            with open(filename, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
            self.set_operation_state(OperationState.COMPLETED, f"Serials saved to {filename}")
            messagebox.showinfo("Serials Saved", f"Saved to:\n{os.path.abspath(filename)}")
        except Exception as e:
            self.set_operation_state(OperationState.FAILED, f"Save failed: {e}")

    def export_serials(self) -> None:
        file = filedialog.asksaveasfilename(
            initialdir="backups", defaultextension=".json", filetypes=[("Saved configs", "*.json")]
        )
        if not file:
            return
        exported_file = self.bum.backup_hardware_info(filename=file)
        if exported_file:
            messagebox.showinfo("Export Complete", f"Verified backup exported to:\n{exported_file}")
        else:
            messagebox.showerror("Export Failed", "Failed to write verified backup file.")

    def import_serials(self) -> None:
        if self.spoofing_in_progress:
            return
        file = filedialog.askopenfilename(initialdir="backups", filetypes=[("Saved configs", "*.json")])
        if not file:
            return

        self.spoofing_in_progress = True
        self.set_operation_state(OperationState.RUNNING, "Validating and restoring backup...")

        def _wrk():
            try:
                is_restored, message = self.bum.restore_hardware_info(file, spoofer_service=self.spoofer)
                st = OperationState.COMPLETED if is_restored else OperationState.PARTIALLY_COMPLETED
                if "corrupted" in message.lower() or "aborted" in message.lower():
                    st = OperationState.FAILED
                self.ui_dispatch(self.set_operation_state, st, f"Backup restore status: {st.value}")
                self.ui_dispatch(
                    messagebox.showinfo if is_restored else messagebox.showwarning,
                    f"Backup Restore Report ({st.value})",
                    message,
                )
                self.refresh_pc_info_async()
                self.ui_dispatch(self.refresh_backup_tab)
            finally:
                self.spoofing_in_progress = False

        threading.Thread(target=_wrk, daemon=True).start()

    def open_custom_spoof_window(self) -> None:
        if self.spoofing_in_progress:
            return

        w = ctk.CTkToplevel(self)
        w.title("Safe Configuration & Target Selection")
        w.geometry("680x620")
        w.configure(fg_color=self.colors["bg_dark"])
        w.grab_set()

        scroll = ctk.CTkScrollableFrame(w, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=12, pady=12)

        ctk.CTkLabel(
            scroll,
            text="EXPLICIT TARGET CONFIGURATION (PROTECTED MODE)",
            font=("Orbitron", 15, "bold"),
            text_color=self.colors["primary"],
        ).pack(pady=8)

        self.toggle_vars: Dict[str, ctk.BooleanVar] = {}
        self.entry_vars: Dict[str, ctk.StringVar] = {}

        # 1. Network MAC Section
        net_frame = ctk.CTkFrame(scroll, fg_color=self.colors["bg_card"])
        net_frame.pack(fill="x", pady=6)
        self.toggle_vars["spoof_mac"] = ctk.BooleanVar(value=bool(self.custom_config.get("spoof_mac", False)))
        ctk.CTkCheckBox(
            net_frame,
            text="Modify Explicitly Selected Network Adapter MACs",
            variable=self.toggle_vars["spoof_mac"],
            font=("Consolas", 12, "bold"),
        ).pack(anchor="w", padx=10, pady=8)

        for f_key, f_label in [("mac_ethernet", "Ethernet MAC (LAA)"), ("mac_wifi", "Wi-Fi MAC (LAA)")]:
            row = ctk.CTkFrame(net_frame, fg_color="transparent")
            row.pack(fill="x", padx=25, pady=3)
            ctk.CTkLabel(row, text=f_label + ":", width=160, anchor="w").pack(side="left")
            e_var = ctk.StringVar(value=str(self.custom_config.get(f_key, "")))
            self.entry_vars[f_key] = e_var
            ent = ctk.CTkEntry(row, textvariable=e_var, placeholder_text="X2:XX:XX:XX:XX:XX")
            ent.pack(side="left", fill="x", expand=True, padx=5)
            ctk.CTkButton(
                row,
                text="🎲",
                width=32,
                command=lambda v=e_var: v.set(self.spoofer.generate_valid_unicast_laa_mac(True)),
            ).pack(side="right")

        # 2. Hostname Section (with explicit consent)
        win_frame = ctk.CTkFrame(scroll, fg_color=self.colors["bg_card"])
        win_frame.pack(fill="x", pady=6)
        self.toggle_vars["spoof_win"] = ctk.BooleanVar(value=bool(self.custom_config.get("spoof_win", False)))
        self.toggle_vars["allow_hostname_change"] = ctk.BooleanVar(
            value=bool(self.custom_config.get("allow_hostname_change", False))
        )
        ctk.CTkCheckBox(
            win_frame,
            text="Update Computer Hostname (Licensing/Activation Keys Strictly Protected)",
            variable=self.toggle_vars["spoof_win"],
            font=("Consolas", 12, "bold"),
        ).pack(anchor="w", padx=10, pady=(8, 4))
        ctk.CTkCheckBox(
            win_frame,
            text="I explicitly consent to changing the Windows ComputerName (Requires Restart)",
            variable=self.toggle_vars["allow_hostname_change"],
            font=("Consolas", 11),
            text_color=self.colors["gold"],
        ).pack(anchor="w", padx=28, pady=4)

        # 3. Partition Volume Serial Section
        part_frame = ctk.CTkFrame(scroll, fg_color=self.colors["bg_card"])
        part_frame.pack(fill="x", pady=6)
        self.toggle_vars["spoof_parts"] = ctk.BooleanVar(value=bool(self.custom_config.get("spoof_parts", False)))
        self.toggle_vars["confirm_disk_changes"] = ctk.BooleanVar(
            value=bool(self.custom_config.get("confirm_disk_changes", False))
        )
        ctk.CTkCheckBox(
            part_frame,
            text="Modify Non-System, Non-BitLocker Partition Volume Serial",
            variable=self.toggle_vars["spoof_parts"],
            font=("Consolas", 12, "bold"),
        ).pack(anchor="w", padx=10, pady=(8, 4))
        ctk.CTkCheckBox(
            part_frame,
            text="I have backed up BitLocker Recovery Keys and confirm partition modification",
            variable=self.toggle_vars["confirm_disk_changes"],
            font=("Consolas", 11),
            text_color=self.colors["gold"],
        ).pack(anchor="w", padx=28, pady=4)

        drv_row = ctk.CTkFrame(part_frame, fg_color="transparent")
        drv_row.pack(fill="x", padx=28, pady=4)
        ctk.CTkLabel(drv_row, text="Target Drive (e.g. D:):", width=170, anchor="w").pack(side="left")
        drv_var = ctk.StringVar(value=",".join(self.custom_config.get("selected_drives", [])))
        self.entry_vars["selected_drives_str"] = drv_var
        ctk.CTkEntry(drv_row, textvariable=drv_var, placeholder_text="D: (System C: is blocked)").pack(
            side="left", fill="x", expand=True, padx=5
        )

        ctk.CTkButton(
            w,
            text="SAVE SAFE CONFIGURATION",
            font=("Orbitron", 13, "bold"),
            height=38,
            fg_color=self.colors["success"],
            text_color="#000000",
            command=lambda: self.save_custom_config(w),
        ).pack(fill="x", padx=20, pady=12)

    def save_custom_config(self, window: Any) -> None:
        new_conf: Dict[str, Any] = {}
        for k, var in self.toggle_vars.items():
            new_conf[k] = bool(var.get())
        for k, var in self.entry_vars.items():
            new_conf[k] = var.get().strip()

        drives_str = new_conf.pop("selected_drives_str", "")
        if drives_str:
            new_conf["selected_drives"] = [d.strip() for d in drives_str.split(",") if d.strip()]
        else:
            new_conf["selected_drives"] = []

        selected_ad: List[str] = []
        if new_conf.get("mac_ethernet"):
            selected_ad.append("ethernet")
        if new_conf.get("mac_wifi"):
            selected_ad.append("wifi")
        new_conf["selected_adapters"] = selected_ad

        self.custom_config = new_conf
        window.destroy()
        self.set_operation_state(OperationState.READY, "Configuration saved and validated.")


if __name__ == "__main__":
    app = HydraSpoofer()
    app.mainloop()
