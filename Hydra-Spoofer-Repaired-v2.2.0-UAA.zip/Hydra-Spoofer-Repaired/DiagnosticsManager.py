import hashlib
import os
import sys
from typing import Any, Dict, List, Optional

import DataStoring as DS
import Details
from BackupManager import BackupManager
from LoggerManager import DEFAULT_LOGGER, OperationState
from MOFManager import MOFManager
from MOFSpoofer import SpooferServiceManager, is_admin


class DiagnosticsManager:
    """
    Unified System Diagnostics Engine (Stage 4 Requirement):
    Inspects and validates:
    1. Privilege & OS Environment (`check_environment`)
    2. Network Adapters & Connectivity (Local-only vs Internet mode) (`diagnose_network`)
    3. Windows Registry Protection & Integrity (`diagnose_registry`)
    4. WMI Service & Repository Consistency + Hardware vs WMI Comparison (`diagnose_wmi`)
    5. Bluetooth Service & Adapter Protection (`diagnose_bluetooth`)
    6. Disks, BitLocker Encryption Status, and Volumeid.exe Binary Integrity (`diagnose_disks`)
    7. Backup & Recovery Health (`diagnose_backups`)
    """

    def __init__(
        self,
        spoofer: Optional[SpooferServiceManager] = None,
        mof: Optional[MOFManager] = None,
        backup_mgr: Optional[BackupManager] = None,
    ):
        self.mof = mof or MOFManager()
        self.backup_mgr = backup_mgr or BackupManager()
        self.spoofer = spoofer or SpooferServiceManager(mof_manager=self.mof, backup_manager=self.backup_mgr)

    def check_environment(self) -> Dict[str, Any]:
        return {
            "platform": sys.platform,
            "python_version": sys.version.split()[0],
            "is_admin": bool(is_admin()),
            "app_version": Details.__version__,
        }

    def diagnose_network(self, local_only: bool = True) -> Dict[str, Any]:
        connectivity = Details.check_network_connectivity(
            local_only=local_only,
            timeout=3.0,
            max_retries=2,
            include_public_ip=not local_only,
        )
        all_adapters = self.mof.get_detailed_network_adapters(include_virtual=True)
        physical_adapters = [a for a in all_adapters if not a.get("is_virtual")]
        virtual_adapters = [a for a in all_adapters if a.get("is_virtual")]

        return {
            "connectivity": connectivity,
            "physical_adapter_count": len(physical_adapters),
            "virtual_adapter_count": len(virtual_adapters),
            "physical_adapters": physical_adapters,
            "excluded_virtual_adapters": [a.get("name") for a in virtual_adapters],
        }

    def diagnose_registry(self) -> Dict[str, Any]:
        protected_checks: List[Dict[str, Any]] = []
        for (kpath, vname), description in DS.PROTECTED_REGISTRY_VALUES.items():
            is_prot, reason = DS.is_registry_target_protected(kpath, vname)
            exists, _, _, read_err = DS.read_from_registry_ex(kpath, vname, root_key="HKLM")
            protected_checks.append(
                {
                    "key": f"HKLM\\{kpath}\\{vname}",
                    "protected_by_policy": is_prot,
                    "readable": exists or (read_err is None),
                    "description": reason or description,
                }
            )
        return {
            "protection_policy_active": True,
            "protected_keys_count": len(protected_checks),
            "protected_keys": protected_checks,
        }

    def diagnose_wmi(self) -> Dict[str, Any]:
        wmi_health = self.mof.diagnose_wmi_service()
        hw_comparison = self.mof.get_hardware_vs_wmi_comparison()
        return {
            "wmi_service_health": wmi_health,
            "hardware_vs_wmi": hw_comparison,
            "unsafe_mof_blocked": True,
        }

    def diagnose_bluetooth(self) -> Dict[str, Any]:
        return self.spoofer.get_bluetooth_state()

    def diagnose_disks(self) -> Dict[str, Any]:
        vol_Verify = self.spoofer.verify_volumeid_binary()
        disks_status = self.spoofer.inspect_disks_and_bitlocker()
        return {
            "volumeid_binary": vol_Verify,
            "partitions": disks_status,
        }

    def diagnose_backups(self) -> Dict[str, Any]:
        files = self.backup_mgr.list_backups()
        verified_files: List[Dict[str, Any]] = []
        for f in files[:20]:
            ok, msg, _ = self.backup_mgr.read_backup_with_status(f)
            verified_files.append({"filename": f, "valid": ok, "message": msg})
        txs = self.backup_mgr.get_transactions()
        return {
            "total_backups": len(files),
            "backups_integrity": verified_files,
            "total_transactions": len(txs),
        }

    def run_all_diagnostics(self, local_only_network: bool = True) -> Dict[str, Any]:
        report = {
            "environment": self.check_environment(),
            "network": self.diagnose_network(local_only=local_only_network),
            "registry": self.diagnose_registry(),
            "wmi": self.diagnose_wmi(),
            "bluetooth": self.diagnose_bluetooth(),
            "disks": self.diagnose_disks(),
            "backups": self.diagnose_backups(),
        }
        DEFAULT_LOGGER.log_operation(
            operation_name="RunSystemDiagnostics",
            target_item="AllSubsystems",
            result=OperationState.COMPLETED.value,
        )
        return report
