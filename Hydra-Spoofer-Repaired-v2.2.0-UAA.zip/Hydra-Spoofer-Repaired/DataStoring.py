import sys
from typing import Any, Dict, Optional, Tuple
from LoggerManager import DEFAULT_LOGGER, OperationState

try:
    import winreg
except ImportError:
    winreg = None  # Cross-platform fallback for non-Windows test environments


# Explicitly protected registry values that MUST NOT be modified to preserve
# Windows Activation, Microsoft Office, Microsoft Store, Adobe, VPN, and system stability.
PROTECTED_REGISTRY_VALUES = {
    ("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CURRENTVERSION", "PRODUCTID"): (
        "Windows Activation & Licensing ProductId (Protected)"
    ),
    ("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CURRENTVERSION", "DIGITALPRODUCTID"): (
        "Windows Activation DigitalProductId binary license (Protected)"
    ),
    ("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CURRENTVERSION", "DIGITALPRODUCTID4"): (
        "Windows Activation DigitalProductId4 binary license (Protected)"
    ),
    ("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CURRENTVERSION", "BUILDGUID"): (
        "Windows BuildGUID servicing identifier (Protected)"
    ),
    ("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CURRENTVERSION", "INSTALLDATE"): (
        "Windows OS InstallDate timestamp (Protected)"
    ),
    ("SOFTWARE\\MICROSOFT\\CRYPTOGRAPHY", "MACHINEGUID"): (
        "Windows Cryptographic MachineGuid - modifying breaks DPAPI, Office, Adobe, and VPN certificates (Protected)"
    ),
    ("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CURRENTVERSION", "PROFILEGUID"): (
        "Windows User ProfileGuid (Protected)"
    ),
}

PROTECTED_PATH_PREFIXES = (
    "SOFTWARE\\MICROSOFT\\WINDOWS DEFENDER",
    "SOFTWARE\\POLICIES\\MICROSOFT\\WINDOWS DEFENDER",
    "SOFTWARE\\MICROSOFT\\OFFICE\\CLICKTORUN",
    "SOFTWARE\\MICROSOFT\\LICENSING",
    "SOFTWARE\\ADOBE\\ADOBE PCD",
    "SYSTEM\\CURRENTCONTROLSET\\SERVICES\\WINDEFEND",
    "SYSTEM\\CURRENTCONTROLSET\\SERVICES\\BTHPORT\\PARAMETERS\\DEVICES",
)


def normalize_reg_path(key_path: str) -> str:
    return key_path.strip("\\").upper()


def is_registry_target_protected(key_path: str, value_name: str) -> Tuple[bool, Optional[str]]:
    """Check if a registry path/value is protected by safety policy."""
    norm_path = normalize_reg_path(key_path)
    norm_val = (value_name or "").strip().upper()

    if (norm_path, norm_val) in PROTECTED_REGISTRY_VALUES:
        return True, PROTECTED_REGISTRY_VALUES[(norm_path, norm_val)]

    for prefix in PROTECTED_PATH_PREFIXES:
        if norm_path.startswith(prefix):
            return True, f"Protected security/licensing/device path prefix: {prefix}"

    return False, None


def _resolve_root_key(root_key: Any = None) -> Any:
    if winreg is None:
        return root_key
    if root_key is None or root_key == "HKCU":
        return winreg.HKEY_CURRENT_USER
    if root_key == "HKLM":
        return winreg.HKEY_LOCAL_MACHINE
    return root_key


def read_from_registry_ex(
    key_path: str,
    name: str,
    root_key: Any = None,
) -> Tuple[bool, Any, Optional[int], Optional[str]]:
    """
    Read a registry value and its type safely.
    Returns: (exists, value, reg_type, error_message)
    """
    if winreg is None:
        return False, None, None, "winreg module is not available on this OS"

    resolved_root = _resolve_root_key(root_key)
    try:
        key = winreg.OpenKey(resolved_root, key_path, 0, winreg.KEY_READ)
        try:
            value, reg_type = winreg.QueryValueEx(key, name)
            return True, value, reg_type, None
        finally:
            winreg.CloseKey(key)
    except FileNotFoundError:
        return False, None, None, None
    except PermissionError as e:
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryRead",
            target_item=f"{key_path}\\{name}",
            result=OperationState.FAILED.value,
            error_message="Permission denied reading registry key",
            exception=e,
        )
        return False, None, None, f"Permission denied: {e}"
    except Exception as e:
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryRead",
            target_item=f"{key_path}\\{name}",
            result=OperationState.FAILED.value,
            error_message=f"Registry read error: {e}",
            exception=e,
        )
        return False, None, None, str(e)


def read_from_registry(key_path: str, name: str, root_key: Any = None) -> Any:
    """Backward-compatible wrapper returning the value or None."""
    exists, value, _, _ = read_from_registry_ex(key_path, name, root_key=root_key)
    return value if exists else None


def write_to_registry(
    key_path: str,
    name: str,
    value: Any,
    root_key: Any = None,
    value_type: str = "REG_SZ",
    transaction_id: Optional[str] = None,
    bypass_protection: bool = False,
) -> Tuple[bool, Optional[str], Optional[Dict[str, Any]]]:
    """
    Safely write a value to the Windows Registry:
    1. Enforces protection blocklist (never modifies Windows activation/licensing keys).
    2. Reads previous value first so it can be backed up and restored.
    3. Writes the value and immediately reads it back to verify the modification succeeded.
    Returns (success, error_message, previous_state_dict).
    """
    protected, reason = is_registry_target_protected(key_path, name)
    if protected and not bypass_protection:
        msg = f"Blocked modification of protected registry key {key_path}\\{name}: {reason}"
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryWriteBlocked",
            target_item=f"{key_path}\\{name}",
            result="Blocked",
            error_message=msg,
            transaction_id=transaction_id,
        )
        return False, msg, None

    if winreg is None:
        return False, "winreg module is not available on this OS", None

    resolved_root = _resolve_root_key(root_key)
    existed_before, prev_val, prev_type, read_err = read_from_registry_ex(key_path, name, root_key=resolved_root)
    if read_err and "Permission denied" in read_err:
        return False, read_err, None

    previous_state = {
        "key_path": key_path,
        "name": name,
        "existed": existed_before,
        "value": prev_val,
        "reg_type": prev_type,
        "root": "HKLM" if resolved_root == getattr(winreg, "HKEY_LOCAL_MACHINE", None) else "HKCU",
    }

    type_map = {
        "REG_SZ": getattr(winreg, "REG_SZ", 1),
        "REG_DWORD": getattr(winreg, "REG_DWORD", 4),
        "REG_BINARY": getattr(winreg, "REG_BINARY", 3),
    }
    reg_type_const = type_map.get(value_type, getattr(winreg, "REG_SZ", 1))

    try:
        key = winreg.CreateKeyEx(resolved_root, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_READ)
        try:
            winreg.SetValueEx(key, name, 0, reg_type_const, value)
        finally:
            winreg.CloseKey(key)

        # Post-write verification
        exists_after, verify_val, _, verify_err = read_from_registry_ex(key_path, name, root_key=resolved_root)
        if not exists_after or verify_val != value:
            err_msg = f"Verification failed after writing {key_path}\\{name}: {verify_err or 'value mismatch'}"
            DEFAULT_LOGGER.log_operation(
                operation_name="RegistryWriteVerifyFailed",
                target_item=f"{key_path}\\{name}",
                previous_value=prev_val,
                new_value=value,
                result=OperationState.FAILED.value,
                error_message=err_msg,
                transaction_id=transaction_id,
            )
            return False, err_msg, previous_state

        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryWrite",
            target_item=f"{key_path}\\{name}",
            previous_value=prev_val,
            new_value=value,
            result=OperationState.COMPLETED.value,
            restore_status="BackupCaptured",
            transaction_id=transaction_id,
        )
        return True, None, previous_state

    except PermissionError as e:
        msg = f"Permission denied writing to {key_path}\\{name}: {e}"
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryWrite",
            target_item=f"{key_path}\\{name}",
            previous_value=prev_val,
            new_value=value,
            result=OperationState.FAILED.value,
            error_message=msg,
            exception=e,
            transaction_id=transaction_id,
        )
        return False, msg, previous_state
    except Exception as e:
        msg = f"Error writing to registry {key_path}\\{name}: {e}"
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryWrite",
            target_item=f"{key_path}\\{name}",
            previous_value=prev_val,
            new_value=value,
            result=OperationState.FAILED.value,
            error_message=msg,
            exception=e,
            transaction_id=transaction_id,
        )
        return False, msg, previous_state


def delete_registry_value(
    key_path: str,
    value_name: str,
    root_key: Any = None,
    transaction_id: Optional[str] = None,
) -> Tuple[bool, Optional[str]]:
    """Safely delete a registry value after checking protection policy and verifying deletion."""
    protected, reason = is_registry_target_protected(key_path, value_name)
    if protected:
        msg = f"Blocked deletion of protected registry value {key_path}\\{value_name}: {reason}"
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryDeleteBlocked",
            target_item=f"{key_path}\\{value_name}",
            result="Blocked",
            error_message=msg,
            transaction_id=transaction_id,
        )
        return False, msg

    if winreg is None:
        return False, "winreg module is not available on this OS"

    resolved_root = _resolve_root_key(root_key)
    exists_before, prev_val, _, _ = read_from_registry_ex(key_path, value_name, root_key=resolved_root)
    if not exists_before:
        return True, None

    try:
        key = winreg.OpenKey(resolved_root, key_path, 0, winreg.KEY_SET_VALUE | winreg.KEY_READ)
        try:
            winreg.DeleteValue(key, value_name)
        finally:
            winreg.CloseKey(key)

        exists_after, _, _, _ = read_from_registry_ex(key_path, value_name, root_key=resolved_root)
        if exists_after:
            return False, f"Value {key_path}\\{value_name} still exists after DeleteValue"

        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryDelete",
            target_item=f"{key_path}\\{value_name}",
            previous_value=prev_val,
            result=OperationState.COMPLETED.value,
            transaction_id=transaction_id,
        )
        return True, None
    except FileNotFoundError:
        return True, None
    except Exception as e:
        DEFAULT_LOGGER.log_operation(
            operation_name="RegistryDelete",
            target_item=f"{key_path}\\{value_name}",
            previous_value=prev_val,
            result=OperationState.FAILED.value,
            error_message=str(e),
            exception=e,
            transaction_id=transaction_id,
        )
        return False, str(e)


def check_registry_value(key_path: str, value_name: str, root_key: Any = None) -> bool:
    exists, val, _, _ = read_from_registry_ex(key_path, value_name, root_key=root_key)
    return bool(exists and val is not None)
