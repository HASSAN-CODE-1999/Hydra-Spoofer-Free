import hashlib
import json
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import DataStoring as DS
import Details
from LoggerManager import DEFAULT_LOGGER, OperationState
from MOFManager import MOFManager


class BackupManager:
    """
    Transactional, Integrity-Verified Backup & Recovery Manager.
    - Uses SHA-256 checksums to verify backup integrity.
    - Allows standard Windows hardware identifiers containing `&` (such as `PCI\\VEN_8086&DEV_06F0...`)
      while blocking shell command chaining/redirection patterns (`&&`, `||`, `;`, `` ` ``, `$()`, `|`, `>`, `<`).
    """

    SCHEMA_VERSION = "2.0"

    def __init__(self, backup_dir: str = "backups"):
        self.mof = MOFManager()
        self.backup_dir = backup_dir
        self.adapters_backup_dir = os.path.join(self.backup_dir, "adapters")
        self.transactions_file = os.path.join(self.backup_dir, "transactions_journal.jsonl")
        # Allow single '&' used in Windows PCI\VEN_xxxx&DEV_xxxx PNPDeviceIDs,
        # while blocking command injection patterns (;, `, |, $, >, <, &&)
        self.injection_pattern = re.compile(r"(?:&&|\|\||[;|`$><])")

    def _ensure_dirs(self, base_dir: Optional[str] = None) -> str:
        target = base_dir or self.backup_dir
        os.makedirs(target, exist_ok=True)
        os.makedirs(os.path.join(target, "adapters"), exist_ok=True)
        return target

    def _sanitize_data(self, data: Any) -> Any:
        """Sanitize loaded backup strings against command injection characters while preserving PCI IDs."""
        if isinstance(data, dict):
            return {str(k): self._sanitize_data(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self._sanitize_data(i) for i in data]
        elif isinstance(data, str):
            if self.injection_pattern.search(data):
                Details.debug_print(f"[!] Security Alert: Blocked potential injection in backup data: {data}")
                return "INVALID_DATA_SECURED"
            return data
        return data

    @staticmethod
    def compute_payload_checksum(payload: Dict[str, Any]) -> str:
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def validate_backup_envelope(self, raw_doc: Any) -> Tuple[bool, str, Dict[str, Any]]:
        if not isinstance(raw_doc, dict) or not raw_doc:
            return False, "Backup file is empty or not a valid JSON object.", {}

        if "payload" in raw_doc and "checksum" in raw_doc:
            payload = raw_doc.get("payload")
            expected_hash = raw_doc.get("checksum")
            if not isinstance(payload, dict) or not payload:
                return False, "Backup payload is missing or empty.", {}

            computed_hash = self.compute_payload_checksum(payload)
            if computed_hash != expected_hash:
                return (
                    False,
                    f"Backup checksum mismatch (expected {expected_hash[:12]}..., got {computed_hash[:12]}...). "
                    "File is corrupted or tampered with.",
                    {},
                )

            sanitized_payload = self._sanitize_data(payload)
            if self._contains_secured_marker(sanitized_payload):
                return False, "Backup contains unsafe/injected strings and was rejected.", {}
            return True, "Integrity verified (v2.0 SHA-256).", sanitized_payload

        known_keys = {
            "BIOS",
            "BaseBoard",
            "Processor",
            "ComputerSystem",
            "DiskDrives",
            "Memory",
            "Network",
            "Partitions",
            "Registry",
            "adapter",
        }
        if not (set(raw_doc.keys()) & known_keys):
            return False, "Backup file is incomplete: missing required hardware/system sections.", {}

        sanitized_legacy = self._sanitize_data(raw_doc)
        if self._contains_secured_marker(sanitized_legacy):
            return False, "Legacy backup contains unsafe/injected strings and was rejected.", {}
        return True, "Legacy backup structure validated.", sanitized_legacy

    def _contains_secured_marker(self, obj: Any) -> bool:
        if obj == "INVALID_DATA_SECURED":
            return True
        if isinstance(obj, dict):
            return any(self._contains_secured_marker(v) for v in obj.values())
        if isinstance(obj, list):
            return any(self._contains_secured_marker(i) for i in obj)
        return False

    def write_backup(
        self,
        data: Dict[str, Any],
        filename: Optional[str] = None,
        backup_dir: Optional[str] = None,
        transaction_id: Optional[str] = None,
    ) -> Optional[str]:
        target_dir = self._ensure_dirs(backup_dir)
        tx_id = transaction_id or DEFAULT_LOGGER.new_transaction_id("BKP")

        if not isinstance(data, dict) or not data:
            DEFAULT_LOGGER.log_operation(
                operation_name="WriteBackup",
                target_item=str(filename or "auto"),
                result=OperationState.FAILED.value,
                error_message="Refused to write empty or invalid backup payload.",
                transaction_id=tx_id,
            )
            return None

        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"backup_{timestamp}.json"
        elif not filename.endswith(".json"):
            filename = f"{filename}.json"

        if os.path.dirname(filename):
            backup_path = filename
            os.makedirs(os.path.dirname(os.path.abspath(backup_path)), exist_ok=True)
        else:
            backup_path = os.path.join(target_dir, filename)

        envelope = {
            "schema_version": self.SCHEMA_VERSION,
            "transaction_id": tx_id,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "checksum": self.compute_payload_checksum(data),
            "payload": data,
        }

        try:
            with open(backup_path, "w", encoding="utf-8") as f:
                json.dump(envelope, f, indent=2, ensure_ascii=False)

            verified_ok, verify_msg, _ = self.read_backup_with_status(
                os.path.basename(backup_path), os.path.dirname(backup_path) or target_dir
            )
            if not verified_ok:
                DEFAULT_LOGGER.log_operation(
                    operation_name="WriteBackupVerifyFailed",
                    target_item=backup_path,
                    result=OperationState.FAILED.value,
                    error_message=verify_msg,
                    transaction_id=tx_id,
                )
                return None

            DEFAULT_LOGGER.log_operation(
                operation_name="WriteBackup",
                target_item=backup_path,
                result=OperationState.COMPLETED.value,
                restore_status="VerifiedRestorable",
                transaction_id=tx_id,
            )
            return backup_path
        except Exception as e:
            DEFAULT_LOGGER.log_operation(
                operation_name="WriteBackup",
                target_item=backup_path,
                result=OperationState.FAILED.value,
                error_message=str(e),
                exception=e,
                transaction_id=tx_id,
            )
            return None

    def read_backup_with_status(
        self, filename: str, backup_dir: Optional[str] = None
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        target_dir = backup_dir or self.backup_dir
        backup_path = filename if os.path.exists(filename) else os.path.join(target_dir, filename)
        if not backup_path.endswith(".json") and not os.path.exists(backup_path):
            if os.path.exists(backup_path + ".json"):
                backup_path = backup_path + ".json"

        if not os.path.exists(backup_path):
            return False, f"Backup file does not exist: {backup_path}", None

        try:
            with open(backup_path, "r", encoding="utf-8") as f:
                raw_doc = json.load(f)
            is_valid, msg, payload = self.validate_backup_envelope(raw_doc)
            if not is_valid:
                DEFAULT_LOGGER.log_operation(
                    operation_name="ReadBackupRejected",
                    target_item=backup_path,
                    result=OperationState.FAILED.value,
                    error_message=msg,
                )
                return False, msg, None
            return True, msg, payload
        except json.JSONDecodeError as e:
            msg = f"Corrupted JSON in backup file {backup_path}: {e}"
            DEFAULT_LOGGER.log_operation(
                operation_name="ReadBackupCorrupted",
                target_item=backup_path,
                result=OperationState.FAILED.value,
                error_message=msg,
                exception=e,
            )
            return False, msg, None
        except Exception as e:
            msg = f"Failed reading backup file {backup_path}: {e}"
            DEFAULT_LOGGER.log_operation(
                operation_name="ReadBackupError",
                target_item=backup_path,
                result=OperationState.FAILED.value,
                error_message=msg,
                exception=e,
            )
            return False, msg, None

    def read_backup(self, filename: str, backup_dir: Optional[str] = None) -> Optional[Dict[str, Any]]:
        ok, _, payload = self.read_backup_with_status(filename, backup_dir=backup_dir)
        return payload if ok else None

    def backup_single_adapter(
        self,
        adapter_info: Dict[str, Any],
        backup_dir: Optional[str] = None,
        transaction_id: Optional[str] = None,
    ) -> Optional[str]:
        target_dir = self._ensure_dirs(backup_dir)
        adapters_dir = os.path.join(target_dir, "adapters")
        dev_id = str(adapter_info.get("device_id", "unknown"))
        safe_name = re.sub(
            r"[^A-Za-z0-9_-]",
            "_",
            str(adapter_info.get("net_connection_id") or adapter_info.get("name") or dev_id),
        )
        fname = f"adapter_{dev_id}_{safe_name}.json"
        return self.write_backup(
            data={"adapter": adapter_info},
            filename=os.path.join(adapters_dir, fname),
            backup_dir=adapters_dir,
            transaction_id=transaction_id,
        )

    def record_transaction(
        self,
        transaction_id: str,
        operation_type: str,
        changes: List[Dict[str, Any]],
        backup_path: Optional[str] = None,
    ) -> str:
        self._ensure_dirs()
        tx_entry = {
            "transaction_id": transaction_id,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "operation_type": operation_type,
            "backup_path": backup_path,
            "changes": changes,
            "rolled_back": False,
        }
        with open(self.transactions_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(tx_entry, ensure_ascii=False) + "\n")
        return transaction_id

    def get_transactions(self) -> List[Dict[str, Any]]:
        if not os.path.exists(self.transactions_file):
            return []
        txs: List[Dict[str, Any]] = []
        try:
            with open(self.transactions_file, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        txs.append(json.loads(line))
        except Exception:
            pass
        return txs

    def list_backups(self, backup_dir: Optional[str] = None) -> List[str]:
        target_dir = backup_dir or self.backup_dir
        if not os.path.exists(target_dir):
            return []
        backups = [
            f
            for f in os.listdir(target_dir)
            if f.endswith(".json") and os.path.isfile(os.path.join(target_dir, f))
        ]
        backups.sort(key=lambda x: os.path.getmtime(os.path.join(target_dir, x)), reverse=True)
        return backups

    def capture_full_system_state(
        self,
        bluetooth_state: Optional[Dict[str, Any]] = None,
        registry_state: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        state = self.mof.get_all_serials()
        adapters = self.mof.get_detailed_network_adapters(include_virtual=True)
        state["NetworkAdaptersDetailed"] = adapters
        for ad in adapters:
            if not ad.get("is_virtual"):
                self.backup_single_adapter(ad)

        if bluetooth_state is not None:
            state["BluetoothState"] = bluetooth_state

        if registry_state is not None:
            state["RegistryState"] = registry_state
        else:
            reg_snapshot: Dict[str, Any] = {}
            allowed_keys = [
                ("HKLM", r"SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName", "ComputerName"),
                ("HKLM", r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", "Hostname"),
                ("HKLM", r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", "NV Hostname"),
            ]
            for root_label, kpath, vname in allowed_keys:
                exists, val, vtype, _ = DS.read_from_registry_ex(kpath, vname, root_key=root_label)
                reg_snapshot[f"{root_label}\\{kpath}\\{vname}"] = {
                    "root": root_label,
                    "key_path": kpath,
                    "name": vname,
                    "existed": exists,
                    "value": val,
                    "reg_type": vtype,
                }
            state["RegistryState"] = reg_snapshot

        return state

    def backup_hardware_info(
        self,
        filename: Optional[str] = None,
        backup_dir: Optional[str] = None,
        transaction_id: Optional[str] = None,
        bluetooth_state: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        state = self.capture_full_system_state(bluetooth_state=bluetooth_state)
        return self.write_backup(state, filename=filename, backup_dir=backup_dir, transaction_id=transaction_id)

    def restore_full_backup(
        self,
        filename: str,
        backup_dir: Optional[str] = None,
        spoofer_service: Optional[Any] = None,
    ) -> Dict[str, Any]:
        tx_id = DEFAULT_LOGGER.new_transaction_id("RST")
        is_valid, msg, payload = self.read_backup_with_status(filename, backup_dir=backup_dir)
        if not is_valid or not payload:
            report = {
                "transaction_id": tx_id,
                "overall_status": OperationState.FAILED.value,
                "can_claim_full_success": False,
                "summary_message": f"Restore aborted: {msg}",
                "restored_items": [],
                "failed_items": [{"item": filename, "reason": msg}],
                "non_restorable_items": [],
            }
            DEFAULT_LOGGER.log_operation(
                operation_name="RestoreFullBackup",
                target_item=filename,
                result=OperationState.FAILED.value,
                error_message=msg,
                transaction_id=tx_id,
            )
            return report

        restored_items: List[Dict[str, Any]] = []
        failed_items: List[Dict[str, Any]] = []
        non_restorable_items: List[Dict[str, Any]] = []

        reg_state = payload.get("RegistryState", {})
        if isinstance(reg_state, dict):
            for reg_id, meta in reg_state.items():
                if not isinstance(meta, dict):
                    continue
                if not meta.get("existed"):
                    continue
                kpath = meta.get("key_path", "")
                vname = meta.get("name", "")
                val = meta.get("value")
                root_lbl = meta.get("root", "HKLM")
                protected, _ = DS.is_registry_target_protected(kpath, vname)
                if protected:
                    non_restorable_items.append(
                        {
                            "item": reg_id,
                            "reason": "Protected Windows licensing/activation key (never modified by safe tool)",
                        }
                    )
                    continue
                curr_exists, curr_val, _, _ = DS.read_from_registry_ex(kpath, vname, root_key=root_lbl)
                if curr_exists and curr_val == val:
                    restored_items.append({"item": reg_id, "status": "Already matches backup value"})
                    continue
                ok, err, _ = DS.write_to_registry(
                    kpath, vname, val, root_key=root_lbl, value_type="REG_SZ", transaction_id=tx_id
                )
                if ok:
                    restored_items.append({"item": reg_id, "status": "Restored and verified"})
                else:
                    failed_items.append({"item": reg_id, "reason": err or "Write failed"})

        if spoofer_service is not None and hasattr(spoofer_service, "restore_original_mac_addresses"):
            mac_ok, mac_details = spoofer_service.restore_original_mac_addresses(
                return_detailed=True, transaction_id=tx_id
            )
            if mac_ok:
                restored_items.append({"item": "NetworkAdaptersMAC", "status": mac_details})
            else:
                failed_items.append({"item": "NetworkAdaptersMAC", "reason": mac_details})

        partitions_bkp = payload.get("Partitions", {})
        if isinstance(partitions_bkp, dict) and partitions_bkp and spoofer_service is not None:
            if hasattr(spoofer_service, "restore_partition_serials"):
                part_report = spoofer_service.restore_partition_serials(
                    partitions_bkp, transaction_id=tx_id
                )
                restored_items.extend(part_report.get("restored", []))
                failed_items.extend(part_report.get("failed", []))
                non_restorable_items.extend(part_report.get("skipped", []))

        bt_bkp = payload.get("BluetoothState")
        if isinstance(bt_bkp, dict) and spoofer_service is not None and hasattr(spoofer_service, "restore_bluetooth_state"):
            bt_ok, bt_msg = spoofer_service.restore_bluetooth_state(bt_bkp, transaction_id=tx_id)
            if bt_ok:
                restored_items.append({"item": "BluetoothService", "status": bt_msg})
            else:
                failed_items.append({"item": "BluetoothService", "reason": bt_msg})

        for hw_section in ("BIOS", "BaseBoard", "Processor", "ComputerSystem", "SystemEnclosure", "DiskDrives", "Memory"):
            if hw_section in payload:
                non_restorable_items.append(
                    {
                        "item": f"Hardware:{hw_section}",
                        "reason": (
                            "Physical firmware/hardware identifier (read-only in hardware; "
                            "MOF class redefinition is disabled to protect WMI repository integrity)."
                        ),
                    }
                )

        if failed_items and not restored_items:
            overall = OperationState.FAILED.value
            can_claim_full = False
        elif failed_items or non_restorable_items:
            overall = OperationState.PARTIALLY_COMPLETED.value if restored_items else OperationState.FAILED.value
            can_claim_full = False
        else:
            overall = OperationState.COMPLETED.value
            can_claim_full = True

        summary_msg = (
            f"Status: {overall} | Restored: {len(restored_items)} | "
            f"Failed: {len(failed_items)} | Non-Restorable (Read-Only Hardware): {len(non_restorable_items)}"
        )

        DEFAULT_LOGGER.log_operation(
            operation_name="RestoreFullBackup",
            target_item=filename,
            result=overall,
            restore_status=summary_msg,
            transaction_id=tx_id,
        )

        return {
            "transaction_id": tx_id,
            "overall_status": overall,
            "can_claim_full_success": can_claim_full,
            "summary_message": summary_msg,
            "restored_items": restored_items,
            "failed_items": failed_items,
            "non_restorable_items": non_restorable_items,
        }

    def restore_hardware_info(
        self, filename: str, backup_dir: Optional[str] = None, spoofer_service: Optional[Any] = None
    ) -> Tuple[bool, str]:
        report = self.restore_full_backup(filename, backup_dir=backup_dir, spoofer_service=spoofer_service)
        overall = report["overall_status"]
        lines = [
            f"Overall Status: {overall}",
            f"- Restored items: {len(report['restored_items'])}",
            f"- Failed items: {len(report['failed_items'])}",
            f"- Non-restorable (read-only hardware) items: {len(report['non_restorable_items'])}",
        ]
        for f_item in report["failed_items"]:
            lines.append(f"  [FAILED] {f_item.get('item')}: {f_item.get('reason')}")
        for nr_item in report["non_restorable_items"]:
            lines.append(f"  [NON-RESTORABLE] {nr_item.get('item')}: {nr_item.get('reason')}")

        detailed_text = "\n".join(lines)
        is_success = len(report["failed_items"]) == 0 and len(report["restored_items"]) > 0
        return is_success, detailed_text

    def undo_last_transaction(self, spoofer_service: Optional[Any] = None) -> Dict[str, Any]:
        txs = self.get_transactions()
        target_tx = None
        for tx in reversed(txs):
            if not tx.get("rolled_back"):
                target_tx = tx
                break

        if not target_tx:
            return {
                "overall_status": OperationState.FAILED.value,
                "summary_message": "No active transaction found to undo.",
                "restored_items": [],
                "failed_items": [{"item": "TransactionJournal", "reason": "No reversible transaction found"}],
                "non_restorable_items": [],
            }

        bkp_path = target_tx.get("backup_path")
        if bkp_path and os.path.exists(bkp_path):
            report = self.restore_full_backup(bkp_path, spoofer_service=spoofer_service)
        else:
            restored: List[Dict[str, Any]] = []
            failed: List[Dict[str, Any]] = []
            for chg in reversed(target_tx.get("changes", [])):
                kind = chg.get("type")
                if kind == "registry":
                    kpath = chg.get("key_path", "")
                    vname = chg.get("name", "")
                    prev_val = chg.get("previous_value")
                    root_lbl = chg.get("root", "HKLM")
                    if chg.get("existed"):
                        ok, err, _ = DS.write_to_registry(kpath, vname, prev_val, root_key=root_lbl)
                    else:
                        ok, err = DS.delete_registry_value(kpath, vname, root_key=root_lbl)
                    if ok:
                        restored.append({"item": f"{kpath}\\{vname}", "status": "Rolled back"})
                    else:
                        failed.append({"item": f"{kpath}\\{vname}", "reason": err})
            overall = (
                OperationState.COMPLETED.value
                if (restored and not failed)
                else (OperationState.PARTIALLY_COMPLETED.value if restored else OperationState.FAILED.value)
            )
            report = {
                "transaction_id": target_tx.get("transaction_id"),
                "overall_status": overall,
                "can_claim_full_success": bool(restored and not failed),
                "summary_message": f"Rollback {overall}: {len(restored)} restored, {len(failed)} failed.",
                "restored_items": restored,
                "failed_items": failed,
                "non_restorable_items": [],
            }

        if not report.get("failed_items"):
            target_tx["rolled_back"] = True
            try:
                with open(self.transactions_file, "w", encoding="utf-8") as f:
                    for tx in txs:
                        f.write(json.dumps(tx, ensure_ascii=False) + "\n")
            except Exception:
                pass

        return report
