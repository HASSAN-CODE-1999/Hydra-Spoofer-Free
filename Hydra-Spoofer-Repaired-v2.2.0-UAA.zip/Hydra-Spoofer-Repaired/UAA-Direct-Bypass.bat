@echo off
chcp 65001 >nul
title Hydra UAA MAC Bypass Toolkit (28:98:7B:4A:1F:9C) - Intel AX201
color 0B

echo ===============================================================================
echo   HYDRA UAA MAC BYPASS TOOLKIT - TARGET MAC: 28:98:7B:4A:1F:9C (28987B4A1F9C)
echo   Target Hardware: Intel Wi-Fi 6 AX201 (PCI\VEN_8086^&DEV_06F0)
echo ===============================================================================
echo.
echo  [1] Method 1: Force Write 28987B4A1F9C in Registry (No Rollback / Keep Value)
echo  [2] Method 2: Patch wdiwifi.sys ^& Netwtw10.sys UAA Lock + Enable Test Signing
echo  [3] Method 3: Create Hyper-V External Virtual Bridge with MAC 28:98:7B:4A:1F:9C
echo  [4] Method 4: Restore Original Signed Drivers ^& Disable Test Signing
echo.
set /p choice="Select Method (1-4): "

if "%choice%"=="1" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command ^
      "$keys = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4D36E972-E325-11CE-BFC1-08002bE10318}' -ErrorAction SilentlyContinue; " ^
      "foreach ($k in $keys) { " ^
      "  $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue; " ^
      "  if ($p.DriverDesc -like '*Wi-Fi*' -or $p.DriverDesc -like '*Wireless*' -or $p.MatchingDeviceId -like '*DEV_06F0*') { " ^
      "    Set-ItemProperty -Path $k.PSPath -Name 'NetworkAddress' -Value '28987B4A1F9C' -Type String; " ^
      "    Write-Host ('[+] Forced NetworkAddress = 28987B4A1F9C on ' + $p.DriverDesc + ' (' + $k.PSChildName + ')') -ForegroundColor Green " ^
      "  } " ^
      "}"
    pause
    exit /b
)

if "%choice%"=="2" (
    python -c "from UAAKernelPatcher import UAAKernelPatcher; import json; p = UAAKernelPatcher(); print(json.dumps([p.backup_and_patch_driver_file(f, apply_in_place=True) for f in p.locate_wifi_driver_files()], indent=2))"
    echo.
    echo [!] IMPORTANT: Make sure Secure Boot is DISABLED in BIOS, then restart Windows!
    pause
    exit /b
)

if "%choice%"=="3" (
    python -c "from UAAKernelPatcher import UAAKernelPatcher; p = UAAKernelPatcher(); print(p.configure_hyperv_uaa_bridge('Intel(R) Wi-Fi 6 AX201 160MHz', '28:98:7B:4A:1F:9C'))"
    pause
    exit /b
)

if "%choice%"=="4" (
    python -c "from UAAKernelPatcher import UAAKernelPatcher; import json; p = UAAKernelPatcher(); print(json.dumps(p.restore_original_drivers(), indent=2))"
    bcdedit /set testsigning off
    pause
    exit /b
)
