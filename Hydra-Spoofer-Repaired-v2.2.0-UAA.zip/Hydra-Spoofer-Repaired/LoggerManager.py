import json
import logging
import os
import re
import traceback
import uuid
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class OperationState(str, Enum):
    READY = "Ready"
    RUNNING = "Running"
    COMPLETED = "Completed"
    PARTIALLY_COMPLETED = "Partially Completed"
    FAILED = "Failed"
    REQUIRES_RESTART = "Requires Restart"


class OperationLogger:
    """
    Professional structured logging and diagnostic reporting manager.
    Records every operation with timestamp, transaction_id, affected item,
    previous value, result, error message, exception details, and restore status.
    """

    SENSITIVE_KEY_PATTERNS = re.compile(
        r"(password|secret|token|productid|digitalproductid|recoverykey|bitlocker_key|public_ip|api_key)",
        re.IGNORECASE,
    )
    IPV4_PATTERN = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")

    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        self.text_log_path = os.path.join(self.log_dir, "system_identity.log")
        self.jsonl_log_path = os.path.join(self.log_dir, "operations_history.jsonl")

        self.logger = logging.getLogger("SystemIdentityTool")
        self.logger.setLevel(logging.DEBUG)
        if not self.logger.handlers:
            fh = logging.FileHandler(self.text_log_path, encoding="utf-8")
            fh.setLevel(logging.DEBUG)
            formatter = logging.Formatter(
                "%(asctime)s | %(levelname)-8s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
            fh.setFormatter(formatter)
            self.logger.addHandler(fh)

    @staticmethod
    def new_transaction_id(prefix: str = "TX") -> str:
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        short_uuid = uuid.uuid4().hex[:8].upper()
        return f"{prefix}-{ts}-{short_uuid}"

    def sanitize_value(self, key_name: str, value: Any, redact_ips: bool = False) -> Any:
        """Sanitize sensitive values so secrets/keys are never exposed in diagnostic exports."""
        if value is None:
            return None
        if self.SENSITIVE_KEY_PATTERNS.search(str(key_name)):
            return "[REDACTED_SENSITIVE_VALUE]"
        if isinstance(value, dict):
            return {k: self.sanitize_value(k, v, redact_ips=redact_ips) for k, v in value.items()}
        if isinstance(value, list):
            return [self.sanitize_value(key_name, v, redact_ips=redact_ips) for v in value]
        if isinstance(value, (bytes, bytearray)):
            return f"[BINARY_DATA:{len(value)}_BYTES]"
        if isinstance(value, str):
            if redact_ips:
                value = self.IPV4_PATTERN.sub("[REDACTED_IP]", value)
            return value
        return value

    def log_operation(
        self,
        operation_name: str,
        target_item: str,
        result: str,
        previous_value: Any = None,
        new_value: Any = None,
        error_message: Optional[str] = None,
        exception: Optional[BaseException] = None,
        restore_status: str = "N/A",
        transaction_id: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Record an operation entry in both the JSONL history and the text log."""
        timestamp = datetime.now().isoformat(timespec="seconds")
        exc_details = None
        if exception is not None:
            exc_details = "".join(
                traceback.format_exception(type(exception), exception, exception.__traceback__)
            ).strip()

        entry: Dict[str, Any] = {
            "timestamp": timestamp,
            "transaction_id": transaction_id or "NO_TX",
            "operation_name": operation_name,
            "target_item": target_item,
            "previous_value": self.sanitize_value(target_item, previous_value),
            "new_value": self.sanitize_value(target_item, new_value),
            "result": result,
            "error_message": error_message or (str(exception) if exception else ""),
            "exception_details": exc_details or "",
            "restore_status": restore_status,
        }
        if extra:
            entry["extra"] = self.sanitize_value("extra", extra)

        try:
            with open(self.jsonl_log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as log_exc:
            self.logger.error(f"Failed writing to JSONL log: {log_exc}")

        log_line = (
            f"TX={entry['transaction_id']} | OP={operation_name} | TARGET={target_item} | "
            f"RESULT={result} | RESTORE={restore_status}"
        )
        if entry["error_message"]:
            log_line += f" | ERROR={entry['error_message']}"
            self.logger.error(log_line)
        else:
            self.logger.info(log_line)

        return entry

    def get_history(self, limit: int = 200, errors_only: bool = False) -> List[Dict[str, Any]]:
        """Retrieve recent operation logs."""
        if not os.path.exists(self.jsonl_log_path):
            return []
        entries: List[Dict[str, Any]] = []
        try:
            with open(self.jsonl_log_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        record = json.loads(line)
                        if errors_only and record.get("result") not in ("Failed", "Error", "Blocked", OperationState.FAILED.value):
                            if not record.get("error_message"):
                                continue
                        entries.append(record)
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            self.logger.error(f"Failed reading operation history: {e}")
        return entries[-limit:][::-1]

    def export_diagnostic_report(
        self,
        output_path: Optional[str] = None,
        diagnostics_data: Optional[Dict[str, Any]] = None,
        backup_summary: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Export a sanitized technical diagnostic report without passwords,
        secret keys, license tokens, or unmasked public IP addresses.
        """
        if output_path is None:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(self.log_dir, f"diagnostic_report_{ts}.json")

        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        history = self.get_history(limit=500, errors_only=False)
        sanitized_history = [
            self.sanitize_value("history_entry", item, redact_ips=True) for item in history
        ]

        report = {
            "report_generated_at": datetime.now().isoformat(timespec="seconds"),
            "privacy_notice": (
                "Sanitized diagnostic report. Passwords, license keys (ProductId/DigitalProductId), "
                "BitLocker recovery keys, and public IP addresses have been automatically redacted."
            ),
            "diagnostics_summary": self.sanitize_value(
                "diagnostics", diagnostics_data or {}, redact_ips=True
            ),
            "backup_summary": self.sanitize_value(
                "backups", backup_summary or {}, redact_ips=True
            ),
            "total_logged_operations": len(sanitized_history),
            "error_count": sum(
                1
                for item in sanitized_history
                if item.get("result") in ("Failed", "Error", "Blocked") or item.get("error_message")
            ),
            "recent_operations": sanitized_history[:100],
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        self.log_operation(
            operation_name="ExportDiagnosticReport",
            target_item=output_path,
            result=OperationState.COMPLETED.value,
            restore_status="N/A",
        )
        return output_path


DEFAULT_LOGGER = OperationLogger()
