# Hydra System & Network Identity Manager (v2.0.0-SAFE)

نسخة مُرمَّمة ومُؤمَّنة بالكامل لأداة فحص وإدارة هوية الشبكة والنظام على نظام Windows، مع نظام نسخ احتياطي واستعادة قائم على المعاملات (`Transaction ID` + `SHA-256`)، وحماية صارمة لمفاتيح تفعيل Windows ومستودع WMI وأقراص النظام وBitLocker.

## التحسينات الجوهرية في الإصدار 2.0.0-SAFE

1. **حماية الشبكة وعناوين MAC (`MOFSpoofer.py` & `MOFManager.py`)**:
   - منع التعديل العشوائي لجميع المحولات، واشتراط التحديد الصريح للمحول المستهدف.
   - استثناء المحولات الافتراضية تلقائيًا (`VMware`, `VirtualBox`, `Hyper-V`, `Docker`, `VPN/TAP/TUN`).
   - التحقق من توافق عنوان MAC مع معيار IEEE 802 (أحادي البث `Unicast` ومُدار محليًا `Locally Administered` بالبت الثاني `2, 6, A, E`).
   - إعادة تشغيل المحول المستهدف فقط بدلًا من إيقاف جميع محولات الشبكة دفعة واحدة.
   - فحص اتصال ذكي بمهلة زمنية محددة يدعم الوضع المحلي (`Local-Only Diagnostic Mode`) دون إرسال عنوان IP العام لخوادم خارجية.

2. **حماية سجل النظام (Windows Registry) والتراخيص (`DataStoring.py`)**:
   - حظر تعديل مفاتيح التفعيل والترخيص والتشفير الحرجة (`ProductId`, `DigitalProductId`, `BuildGUID`, `InstallDate`, `MachineGuid`, `ProfileGuid`).
   - منع تغيير اسم الجهاز (`ComputerName`/`Hostname`) دون موافقة صريحة من المستخدم.
   - أخذ نسخة احتياطية قبل أي كتابة والتحقق من القيمة بعد كتابتها (`Read-back Verification`).

3. **حماية مستودع WMI وبيانات SMBIOS (`MOFManager.py`)**:
   - إيقاف إعادة تعريف أصناف النظام الأساسية (`[DYNPROPS] class Win32_BIOS / Win32_Processor / Win32_DiskDrive`) عبر `mofcomp` التي كانت تتلف مستودع `root\CIMv2`.
   - الفصل الواضح بين بيانات العتاد الحقيقية (`Firmware / Registry HardwareConfig`) وبيانات طبقة `WMI`.

4. **حماية الأقراص وBitLocker وملف `Volumeid.exe` (`MOFSpoofer.py`)**:
   - حظر تعديل قرص النظام (`C:`) والأقراص المحمية بـ `BitLocker`.
   - التحقق من البصمة الرقمية (`SHA-256`) والتوقيع الرقمي لملف `Volumeid.exe` قبل التنفيذ.

5. **نظام النسخ الاحتياطي والاستعادة والسجلات (`BackupManager.py` & `LoggerManager.py`)**:
   - التحقق من سلامة النسخ الاحتياطية عبر بصمة `SHA-256` ورفض النسخ التالفة.
   - دعم التراجع عن آخر عملية (`Undo Last Transaction`) والاستعادة الكاملة مع تقرير مفصل يوضح العناصر المستعادة والفاشلة وغير القابلة للاستعادة.
   - تصدير تقرير تشخيصي آمن (`Export Diagnostic Report`) مع حجب البيانات الحساسة تلقائيًا.

## طريقة التشغيل

```bash
pip install -r requirements.txt
python MOFmenu.py
```

## تشغيل الاختبارات الآلية (18 سيناريو اختبار)

```bash
python -m unittest discover -s tests -v
```
