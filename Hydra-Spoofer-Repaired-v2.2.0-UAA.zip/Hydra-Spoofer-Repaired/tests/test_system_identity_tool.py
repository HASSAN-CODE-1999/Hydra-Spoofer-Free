import json
import os
import shutil
import sys
import tempfile
import unittest
from typing import Any, Dict, Tuple
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import DataStoring as DS
import Details
from BackupManager import BackupManager
from DiagnosticsManager import DiagnosticsManager
from LoggerManager import DEFAULT_LOGGER, OperationLogger, OperationState
from MOFManager import MOFManager
import hashlib
from MOFSpoofer import SpooferServiceManager


class FakeWinReg:
    """In-memory mock of Windows `winreg` module for safe, isolated unit testing."""

    HKEY_CURRENT_USER = "HKCU"
    HKEY_LOCAL_MACHINE = "HKLM"
    KEY_READ = 1
    KEY_SET_VALUE = 2
    KEY_ALL_ACCESS = 3
    REG_SZ = 1
    REG_BINARY = 3
    REG_DWORD = 4

    def __init__(self) -> None:
        self.store: Dict[Tuple[str, str], Dict[str, Tuple[Any, int]]] = {}
        self.fail_reads = False
        self.fail_writes = False

    def _norm(self, path: str) -> str:
        return path.strip("\\")

    def OpenKey(self, root: str, subkey: str, reserved: int = 0, access: int = 1) -> Tuple[str, str]:
        if self.fail_reads:
            raise PermissionError("Simulated Registry Access Denied")
        k = (root, self._norm(subkey))
        if k not in self.store:
            raise FileNotFoundError(f"Registry key not found: {k}")
        return k

    def CreateKey(self, root: str, subkey: str) -> Tuple[str, str]:
        return self.CreateKeyEx(root, subkey, 0, self.KEY_ALL_ACCESS)

    def CreateKeyEx(self, root: str, subkey: str, reserved: int = 0, access: int = 3) -> Tuple[str, str]:
        if self.fail_writes:
            raise PermissionError("Simulated Registry Write Access Denied")
        k = (root, self._norm(subkey))
        if k not in self.store:
            self.store[k] = {}
        return k

    def SetValueEx(self, key: Tuple[str, str], name: str, reserved: int, reg_type: int, value: Any) -> None:
        if self.fail_writes:
            raise PermissionError("Simulated Registry SetValueEx Access Denied")
        self.store.setdefault(key, {})[name] = (value, reg_type)

    def QueryValueEx(self, key: Tuple[str, str], name: str) -> Tuple[Any, int]:
        if self.fail_reads:
            raise PermissionError("Simulated Registry QueryValueEx Access Denied")
        if key not in self.store or name not in self.store[key]:
            raise FileNotFoundError(f"Value {name} not found in {key}")
        return self.store[key][name]

    def DeleteValue(self, key: Tuple[str, str], name: str) -> None:
        if self.fail_writes:
            raise PermissionError("Simulated Registry DeleteValue Access Denied")
        if key not in self.store or name not in self.store[key]:
            raise FileNotFoundError(f"Value {name} not found in {key}")
        del self.store[key][name]

    def CloseKey(self, key: Any) -> None:
        pass


class TestSystemIdentityTool18Scenarios(unittest.TestCase):
    """
    Comprehensive 18-scenario test suite verifying all safety, backup/restore,
    network, registry, WMI, Bluetooth, and disk/BitLocker requirements in an isolated mock environment.
    """

    def setUp(self) -> None:
        self.temp_dir = tempfile.mkdtemp(prefix="hydra_test_")
        self.backup_dir = os.path.join(self.temp_dir, "backups")
        self.log_dir = os.path.join(self.temp_dir, "logs")
        self.fake_reg = FakeWinReg()

        # Pre-populate simulated adapter registry keys
        net_cls = MOFManager.NETWORK_CLASS_KEY
        self.fake_reg.store[("HKLM", f"{net_cls}\\0001")] = {
            "DriverDesc": ("Intel(R) Ethernet Connection I219-V", FakeWinReg.REG_SZ),
        }
        self.fake_reg.store[("HKLM", f"{net_cls}\\0002")] = {
            "DriverDesc": ("Intel(R) Wi-Fi 6 AX200 160MHz", FakeWinReg.REG_SZ),
        }

        self.reg_patcher_ds = patch.object(DS, "winreg", self.fake_reg)
        self.reg_patcher_mof = patch("MOFManager.winreg", self.fake_reg)
        self.reg_patcher_spoofer = patch("MOFSpoofer.winreg", self.fake_reg)
        self.reg_patcher_ds.start()
        self.reg_patcher_mof.start()
        self.reg_patcher_spoofer.start()

        self.mof = MOFManager()
        self.bum = BackupManager(backup_dir=self.backup_dir)
        self.bum.mof = self.mof
        self.spoofer = SpooferServiceManager(mof_manager=self.mof, backup_manager=self.bum)
        self.spoofer.original_file = os.path.join(self.backup_dir, "Origin.json")

    def tearDown(self) -> None:
        self.reg_patcher_ds.stop()
        self.reg_patcher_mof.stop()
        self.reg_patcher_spoofer.stop()
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    # 1. عدم وجود إنترنت (No Internet Connection)
    def test_01_no_internet_connection(self) -> None:
        with patch("socket.create_connection", side_effect=OSError("Network is unreachable")), patch(
            "socket.getaddrinfo", side_effect=OSError("DNS unreachable")
        ):
            report = Details.check_network_connectivity(
                local_only=False, timeout=0.5, max_retries=1, include_public_ip=False
            )
            self.assertFalse(report["internet_reachable"])
            self.assertFalse(report["dns_working"])
            self.assertGreaterEqual(len(report["errors"]), 1)

    # 2. انقطاع الإنترنت أثناء العملية (Internet Disconnected During Operation)
    def test_02_internet_disconnect_during_operation(self) -> None:
        sample_adapters = [
            {
                "device_id": "1",
                "name": "Intel(R) Ethernet Connection I219-V",
                "net_connection_id": "Ethernet",
                "mac_address": "AA:BB:CC:DD:EE:01",
                "pnp_device_id": "PCI\\VEN_8086",
                "adapter_kind": "Ethernet",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            }
        ]
        with patch.object(self.mof, "get_detailed_network_adapters", return_value=sample_adapters), patch.object(
            self.spoofer, "restart_single_adapter", return_value=(True, "Restarted")
        ), patch.object(
            self.spoofer, "verify_adapter_active_mac", return_value=(True, "02:11:22:33:44:55", "Verified")
        ), patch("Details.check_network_connectivity", return_value={"local_link_up": False, "internet_reachable": False}):
            ok, msg = self.spoofer.spoof_mac_address(
                mac_addresses={"Ethernet": "02:11:22:33:44:55"},
                selected_adapters=["Ethernet"],
            )
            self.assertTrue(ok)
            self.assertIn("02:11:22:33:44:55", msg)

    # 3. وجود عدة محولات شبكة (Multiple Network Adapters - Only Explicitly Selected Modified)
    def test_03_multiple_network_adapters_explicit_selection(self) -> None:
        sample_adapters = [
            {
                "device_id": "1",
                "name": "Intel(R) Ethernet Connection I219-V",
                "net_connection_id": "Ethernet",
                "mac_address": "AA:BB:CC:DD:EE:01",
                "pnp_device_id": "PCI\\VEN_8086",
                "adapter_kind": "Ethernet",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            },
            {
                "device_id": "2",
                "name": "Intel(R) Wi-Fi 6 AX200 160MHz",
                "net_connection_id": "Wi-Fi",
                "mac_address": "AA:BB:CC:DD:EE:02",
                "pnp_device_id": "PCI\\VEN_8086",
                "adapter_kind": "Wi-Fi",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            },
        ]
        with patch.object(self.mof, "get_detailed_network_adapters", return_value=sample_adapters), patch.object(
            self.spoofer, "restart_single_adapter", return_value=(True, "Restarted")
        ) as mock_restart, patch.object(
            self.spoofer, "verify_adapter_active_mac", return_value=(True, "06:AA:BB:CC:DD:EE", "Verified")
        ):
            ok, _ = self.spoofer.spoof_mac_address(
                mac_addresses={"Ethernet": "06:AA:BB:CC:DD:EE"},
                selected_adapters=["Ethernet"],
            )
            self.assertTrue(ok)
            mock_restart.assert_called_once_with("Ethernet", device_id="1")
            net_cls = MOFManager.NETWORK_CLASS_KEY
            self.assertIn("NetworkAddress", self.fake_reg.store[("HKLM", f"{net_cls}\\0001")])
            self.assertNotIn("NetworkAddress", self.fake_reg.store[("HKLM", f"{net_cls}\\0002")])

    # 4. وجود VMware وVirtualBox وHyper-V وDocker (Exclude Virtual Adapters by Default)
    def test_04_exclude_vmware_virtualbox_hyperv_docker(self) -> None:
        self.assertTrue(MOFManager.is_virtual_adapter("VMware Network Adapter VMnet8", "VMware Virtual Ethernet"))
        self.assertTrue(MOFManager.is_virtual_adapter("VirtualBox Host-Only Network", "VirtualBox NDIS"))
        self.assertTrue(MOFManager.is_virtual_adapter("vEthernet (Default Switch)", "Hyper-V Virtual Ethernet Adapter"))
        self.assertTrue(MOFManager.is_virtual_adapter("DockerNAT", "Hyper-V Virtual Adapter"))
        self.assertFalse(MOFManager.is_virtual_adapter("Ethernet", "Intel(R) Ethernet I219-V", "PCI\\VEN_8086"))

    # 5. فشل تغيير MAC (MAC Change Failure & Automatic Rollback + Invalid Multicast Rejection)
    def test_05_mac_change_failure_and_rollback(self) -> None:
        valid_mc, _, reason_mc = SpooferServiceManager.validate_mac_address("01:23:45:67:89:AB")
        self.assertFalse(valid_mc)
        self.assertIn("Multicast", reason_mc)

        sample_adapters = [
            {
                "device_id": "1",
                "name": "Intel(R) Ethernet Connection I219-V",
                "net_connection_id": "Ethernet",
                "mac_address": "AA:BB:CC:DD:EE:01",
                "pnp_device_id": "PCI\\VEN_8086",
                "adapter_kind": "Ethernet",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            }
        ]
        with patch.object(self.mof, "get_detailed_network_adapters", return_value=sample_adapters), patch.object(
            self.spoofer, "restart_single_adapter", return_value=(False, "Driver rejected restart")
        ):
            ok, msg = self.spoofer.spoof_mac_address(
                mac_addresses={"Ethernet": "02:AA:BB:CC:DD:EE"},
                selected_adapters=["Ethernet"],
            )
            self.assertFalse(ok)
            self.assertIn("rolled back", msg)
            net_cls = MOFManager.NETWORK_CLASS_KEY
            self.assertNotIn("NetworkAddress", self.fake_reg.store[("HKLM", f"{net_cls}\\0001")])

    # 6. فشل قراءة Registry + حماية مفاتيح الترخيص (Registry Read Failure & Licensing Protection)
    def test_06_registry_read_permission_failure_and_licensing_protection(self) -> None:
        for path, name in [
            (r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "ProductId"),
            (r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "DigitalProductId"),
            (r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "BuildGUID"),
            (r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "InstallDate"),
            (r"SOFTWARE\Microsoft\Cryptography", "MachineGuid"),
            (r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", "ProfileGuid"),
        ]:
            ok, err, _ = DS.write_to_registry(path, name, "FAKE", root_key="HKLM")
            self.assertFalse(ok, f"Protected key {path}\\{name} should be blocked!")
            self.assertIn("Blocked", err or "")

        self.fake_reg.fail_reads = True
        exists, val, _, err = DS.read_from_registry_ex(r"SOFTWARE\Test", "Key", root_key="HKCU")
        self.assertFalse(exists)
        self.assertIsNone(val)
        self.assertIn("Permission denied", err or "")

    # 7. عدم توفر صلاحيات Administrator (Missing Administrator Privileges)
    def test_07_missing_admin_privileges(self) -> None:
        with patch("MOFSpoofer.is_admin", return_value=False):
            ok, msgs = self.spoofer.install_service(config={"spoof_mac": True})
            self.assertFalse(ok)
            self.assertTrue(any("Administrator privileges required" in m for m in msgs))

    # 8. تعطل WMI وحماية المستودع من ملفات MOF المدمرة (WMI Failure & Unsafe MOF Blocking)
    def test_08_wmi_service_failure_and_unsafe_mof_block(self) -> None:
        destructive_mof = """#pragma namespace("\\\\\\\\.\\\\root\\\\CIMv2")
        [DYNPROPS]
        class Win32_BIOS { [key] string Name; string SerialNumber; };
        """
        is_valid, reason = MOFManager.validate_mof_content(destructive_mof)
        self.assertFalse(is_valid)
        self.assertIn("Win32_BIOS", reason)
        self.assertFalse(self.mof.create_mof_file(destructive_mof))
        self.assertFalse(self.mof.spoof_smbios_serials())

    # 9. فشل تشغيل Bluetooth وحماية الأجهزة المقترنة (Bluetooth Protection & Restart Failure)
    def test_09_bluetooth_service_restart_failure_and_protection(self) -> None:
        ok, err, _ = DS.write_to_registry(
            r"SYSTEM\CurrentControlSet\Services\BTHPORT\Parameters\Devices\001122334455",
            "LocalAddress",
            "021122334455",
            root_key="HKLM",
        )
        self.assertFalse(ok)
        self.assertIn("Protected", err or "")

        with patch("sys.platform", "win32"), patch.object(
            self.spoofer,
            "get_bluetooth_state",
            return_value={"service_name": "bthserv", "status": "Stopped", "adapters": []},
        ), patch("MOFSpoofer.run_hidden", return_value=MagicMock(returncode=1, stderr="Service start failed", stdout="")):
            bt_ok, bt_msg = self.spoofer.restore_bluetooth_state({"status": "Running"})
            self.assertFalse(bt_ok)
            self.assertIn("Failed to restart Bluetooth Support Service", bt_msg)

    # 10. وجود BitLocker وحماية قرص النظام C: (BitLocker & System Drive Protection)
    def test_10_bitlocker_and_system_drive_protection(self) -> None:
        mock_partitions = [
            {"DeviceID": "C:", "VolumeName": "OS", "FileSystem": "NTFS", "DriveType": 3, "VolumeSerialNumber": "11112222"},
            {"DeviceID": "D:", "VolumeName": "SecureData", "FileSystem": "NTFS", "DriveType": 3, "VolumeSerialNumber": "33334444"},
            {"DeviceID": "E:", "VolumeName": "Scratch", "FileSystem": "NTFS", "DriveType": 3, "VolumeSerialNumber": "55556666"},
        ]
        mock_bitlocker = [
            {"MountPoint": "D:", "VolumeStatus": "FullyEncrypted", "ProtectionStatus": 1, "EncryptionMethod": "XtsAes256"}
        ]
        with patch("sys.platform", "win32"), patch.object(
            self.mof, "get_partition_serials", return_value=mock_partitions
        ), patch.object(self.mof, "run_powershell", return_value=mock_bitlocker):
            inspected = {d["device_id"]: d for d in self.spoofer.inspect_disks_and_bitlocker()}
            self.assertFalse(inspected["C:"]["modifiable"])
            self.assertIn("System boot/OS drive", inspected["C:"]["block_reason"])
            self.assertFalse(inspected["D:"]["modifiable"])
            self.assertTrue(inspected["D:"]["bitlocker_active"])
            self.assertIn("BitLocker", inspected["D:"]["block_reason"])
            self.assertTrue(inspected["E:"]["modifiable"])

    # 11. فشل قراءة الأقراص (Disk Read Failure)
    def test_11_disk_read_failure_handling(self) -> None:
        with patch.object(self.spoofer, "verify_volumeid_binary", return_value={"safe_to_execute": True, "path": "Volumeid.exe"}), patch.object(
            self.spoofer, "inspect_disks_and_bitlocker", return_value=[]
        ):
            ok, msg = self.spoofer.spoof_partition_serials(selected_drives=["D:"], user_confirmed=True)
            self.assertFalse(ok)
            self.assertIn("Failed to read disk partitions", msg)

    # 12. تلف النسخة الاحتياطية (Corrupted Backup Detection via SHA-256 Checksum)
    def test_12_corrupted_backup_detection(self) -> None:
        bkp_path = self.bum.write_backup({"Hostname": "ORIGINAL-PC", "Network": {"Ethernet": "AA:BB:CC:DD:EE:01"}}, "test_bkp.json")
        self.assertIsNotNone(bkp_path)

        with open(bkp_path, "r", encoding="utf-8") as f:
            doc = json.load(f)
        doc["payload"]["Hostname"] = "TAMPERED-PC; calc.exe"
        with open(bkp_path, "w", encoding="utf-8") as f:
            json.dump(doc, f)

        is_valid, msg, payload = self.bum.read_backup_with_status(bkp_path)
        self.assertFalse(is_valid)
        self.assertIsNone(payload)
        self.assertIn("checksum mismatch", msg.lower())

        restore_report = self.bum.restore_full_backup(bkp_path)
        self.assertEqual(restore_report["overall_status"], OperationState.FAILED.value)
        self.assertFalse(restore_report["can_claim_full_success"])

    # 13. فشل الاستعادة أو الاستعادة الجزئية (Failed / Partial Restore Honest Reporting)
    def test_13_partial_or_failed_restore_honest_reporting(self) -> None:
        bkp_data = {
            "BIOS": {"SerialNumber": "BIOS-123"},
            "RegistryState": {
                "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Hostname": {
                    "root": "HKLM",
                    "key_path": r"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
                    "name": "Hostname",
                    "existed": True,
                    "value": "ORIG-HOST",
                    "reg_type": 1,
                }
            },
        }
        bkp_path = self.bum.write_backup(bkp_data, "partial_test.json")
        report = self.bum.restore_full_backup(bkp_path)
        self.assertEqual(report["overall_status"], OperationState.PARTIALLY_COMPLETED.value)
        self.assertFalse(report["can_claim_full_success"])
        self.assertEqual(len(report["restored_items"]), 1)
        self.assertEqual(len(report["non_restorable_items"]), 1)

    # 14. إعادة تشغيل الجهاز أثناء العملية / بقاء النسخة الاحتياطية وسجل المعاملات (Pre-Op Backup Survives Interruption)
    def test_14_pre_operation_backup_survives_interruption(self) -> None:
        with patch("MOFSpoofer.is_admin", return_value=True), patch.object(
            self.spoofer, "spoof_mac_address", side_effect=RuntimeError("Simulated sudden reboot/interruption")
        ):
            with self.assertRaises(RuntimeError):
                self.spoofer.install_service(config={"spoof_mac": True, "selected_adapters": ["Ethernet"]})
            self.assertTrue(os.path.exists(self.spoofer.original_file))
            ok_orig, _, _ = self.bum.read_backup_with_status(self.spoofer.original_file)
            self.assertTrue(ok_orig)
            self.assertFalse(self.spoofer.check_spoofer_installed())

    # 15. تحديث تعريف الشبكة / غياب مفتاح المحول في الريجستري (Network Driver Update / Missing Registry Key)
    def test_15_network_driver_update_missing_registry_support(self) -> None:
        support = self.mof.check_adapter_registry_support("99", "Updated Network Driver NIC")
        self.assertFalse(support["supported"])

    # 16. عدم توافق إصدار Windows / غياب winreg أو فشل أوامر WMI (Windows Version Compatibility & Fallbacks)
    def test_16_windows_version_compatibility_and_safe_fallbacks(self) -> None:
        with patch.object(self.mof, "run_powershell", return_value={}):
            serials = self.mof.get_all_serials()
            self.assertEqual(serials["BIOS"]["SerialNumber"], "Unknown")
            self.assertEqual(serials["Processor"]["ProcessorId"], "Unknown")

    # 17. عدم وجود Volumeid.exe أو تغير بصمته (Missing or Tampered Volumeid.exe)
    def test_17_missing_or_tampered_volumeid_exe(self) -> None:
        with patch("Details.resource_path", return_value=os.path.join(self.temp_dir, "NonExistent_Volumeid.exe")):
            check = self.spoofer.verify_volumeid_binary()
            self.assertFalse(check["exists"])
            self.assertFalse(check["safe_to_execute"])

        tampered_exe = os.path.join(self.temp_dir, "Tampered_Volumeid.exe")
        with open(tampered_exe, "wb") as f:
            f.write(b"MZ_FAKE_BINARY_CONTENT")
        with patch("Details.resource_path", return_value=tampered_exe):
            tampered_check = self.spoofer.verify_volumeid_binary()
            self.assertTrue(tampered_check["exists"])
            self.assertFalse(tampered_check["hash_verified"])
            self.assertFalse(tampered_check["safe_to_execute"])

        real_check = self.spoofer.verify_volumeid_binary()
        self.assertTrue(real_check["exists"])
        self.assertTrue(real_check["hash_verified"])
        self.assertTrue(real_check["safe_to_execute"])

    # 18. فشل الاتصال بخدمة فحص الإنترنت (api.ipify.org SSL / Timeout / ConnectionError + Sanitized Diagnostic Report)
    def test_18_external_ip_service_ssl_timeout_failure_and_sanitized_export(self) -> None:
        from requests.exceptions import SSLError

        with patch("requests.get", side_effect=SSLError("Simulated SSL Certificate Verification Failed")):
            conn = Details.check_network_connectivity(
                local_only=False, timeout=0.5, max_retries=2, include_public_ip=True
            )
            self.assertIsNone(conn["public_ip"])
            self.assertTrue(any("SSL error" in e for e in conn["errors"]))

        logger = OperationLogger(log_dir=self.log_dir)
        logger.log_operation(
            operation_name="TestSensitive",
            target_item="DigitalProductId",
            previous_value="SECRET-LICENSE-KEY-12345",
            result=OperationState.FAILED.value,
            error_message="Failed connecting to 203.0.113.55",
        )
        rep_path = logger.export_diagnostic_report(
            output_path=os.path.join(self.log_dir, "diag_export.json"),
            diagnostics_data={"public_ip": "198.51.100.42", "ProductId": "AAAAA-BBBBB-CCCCC"},
        )
        with open(rep_path, "r", encoding="utf-8") as f:
            rep_txt = f.read()
        self.assertNotIn("SECRET-LICENSE-KEY-12345", rep_txt)
        self.assertNotIn("198.51.100.42", rep_txt)
        self.assertNotIn("203.0.113.55", rep_txt)
        self.assertIn("[REDACTED_SENSITIVE_VALUE]", rep_txt)



    # 19. التحقق بعد إعادة تشغيل المحول من تطبيق التعريف لعنوان MAC أو تجاهله (Post-Restart Driver MAC Verification)
    def test_19_post_restart_driver_mac_verification_and_ignored_mac_detection(self) -> None:
        # Scenario A: User enters 28:98:7B:4A:1F:9C on Wi-Fi, and Wi-Fi driver ignores it (keeps 20:C1:9B:4C:46:B8)
        wifi_adapter_unchanged = [
            {
                "device_id": "2",
                "name": "Intel(R) Wi-Fi 6 AX200 160MHz",
                "net_connection_id": "Wi-Fi",
                "mac_address": "20:C1:9B:4C:46:B8",
                "pnp_device_id": "PCI\\VEN_8086&DEV_06F0&SUBSYS_00748086",
                "adapter_kind": "Wi-Fi",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            }
        ]
        with patch.object(self.mof, "get_detailed_network_adapters", return_value=wifi_adapter_unchanged), patch.object(
            self.spoofer, "restart_single_adapter", return_value=(True, "Restarted")
        ), patch("time.sleep", return_value=None):
            ok, msg = self.spoofer.spoof_mac_address(
                mac_addresses={"Wi-Fi": "28:98:7B:4A:1F:9C"},
                selected_adapters=["Wi-Fi"],
            )
            self.assertFalse(ok)
            self.assertIn("Driver Ignored MAC", msg)
            self.assertIn("28:98:7B:4A:1F:9C", msg)
            self.assertIn("20:C1:9B:4C:46:B8", msg)
            # Ensure ineffective Registry override was automatically rolled back
            net_cls = MOFManager.NETWORK_CLASS_KEY
            self.assertNotIn("NetworkAddress", self.fake_reg.store[("HKLM", f"{net_cls}\\0002")])

        # Scenario B: Driver applies the new MAC -> verification succeeds
        eth_before = [
            {
                "device_id": "1",
                "name": "Intel(R) Ethernet Connection I219-V",
                "net_connection_id": "Ethernet",
                "mac_address": "2C:F0:5D:FF:6B:24",
                "pnp_device_id": "PCI\\VEN_8086&DEV_15FB",
                "adapter_kind": "Ethernet",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            }
        ]
        eth_after = [
            {
                **eth_before[0],
                "mac_address": "28:98:7B:4A:1F:9C",
            }
        ]
        with patch.object(
            self.mof, "get_detailed_network_adapters", side_effect=[eth_before, eth_after]
        ), patch.object(self.spoofer, "restart_single_adapter", return_value=(True, "Restarted")):
            ok2, msg2 = self.spoofer.spoof_mac_address(
                mac_addresses={"Ethernet": "28:98:7B:4A:1F:9C"},
                selected_adapters=["Ethernet"],
            )
            self.assertTrue(ok2)
            self.assertIn("28:98:7B:4A:1F:9C (Verified Active)", msg2)



    # 20. وضع إجبار بقاء عنوان UAA (28:98:7B:4A:1F:9C) في الريجستري دون تراجع (Force Keep UAA Registry Mode)
    def test_20_force_keep_uaa_registry_without_rollback(self) -> None:
        wifi_adapter_unchanged = [
            {
                "device_id": "2",
                "name": "Intel(R) Wi-Fi 6 AX201 160MHz",
                "net_connection_id": "Wi-Fi",
                "mac_address": "20:C1:9B:4C:46:B8",
                "pnp_device_id": "PCI\\VEN_8086&DEV_06F0&SUBSYS_00748086",
                "adapter_kind": "Wi-Fi",
                "is_virtual": False,
                "net_enabled": True,
                "supports_mac_override": True,
            }
        ]
        with patch.object(self.mof, "get_detailed_network_adapters", return_value=wifi_adapter_unchanged), patch.object(
            self.spoofer, "restart_single_adapter", return_value=(True, "Restarted")
        ), patch("time.sleep", return_value=None):
            ok, msg = self.spoofer.spoof_mac_address(
                mac_addresses={"Wi-Fi": "28:98:7B:4A:1F:9C"},
                selected_adapters=["Wi-Fi"],
                force_keep_uaa_registry=True,
            )
            self.assertTrue(ok)
            self.assertIn("28:98:7B:4A:1F:9C", msg)
            self.assertIn("Forced in Registry without rollback", msg)
            net_cls = MOFManager.NETWORK_CLASS_KEY
            self.assertEqual(
                self.fake_reg.store[("HKLM", f"{net_cls}\\0002")]["NetworkAddress"][0],
                "28987B4A1F9C",
            )

    # 21. فحص وترقيع ملفات تعريف النواة (wdiwifi.sys / Netwtw10.sys) وحساب PE Checksum واستعادتها
    def test_21_uaa_kernel_driver_scanner_and_patcher_pe_checksum(self) -> None:
        from UAAKernelPatcher import UAAKernelPatcher
        import struct

        dos_hdr = bytearray(0x80)
        dos_hdr[0:2] = b"MZ"
        struct.pack_into("<I", dos_hdr, 0x3C, 0x80)
        pe_hdr = bytearray(0x100)
        pe_hdr[0:4] = b"PE\x00\x00"
        code_sec = (
            b"\x00" * 32
            + b"NdisReadNetworkAddress\x00"
            + "NetworkAddress".encode("utf-16le")
            + b"\x90\x90\x24\x03\x3C\x02\x75\x1A"
            + b"\x90\x90\xF6\x41\x00\x02\x74\x12"
            + b"\x00" * 64
        )
        raw_pe = bytes(dos_hdr + pe_hdr) + code_sec
        fake_sys_path = os.path.join(self.temp_dir, "Netwtw10.sys")
        with open(fake_sys_path, "wb") as f:
            f.write(raw_pe)

        patcher = UAAKernelPatcher(backup_dir=self.backup_dir)
        scan_res = patcher.scan_binary_for_uaa_locks(raw_pe)
        self.assertTrue(scan_res["imports_ndis_read_network_address"])
        self.assertEqual(scan_res["match_count"], 2)

        patch_rep = patcher.backup_and_patch_driver_file(fake_sys_path, apply_in_place=False)
        self.assertTrue(patch_rep["ok"])
        self.assertEqual(patch_rep["applied_patches_count"], 2)

        with open(patch_rep["patched_staging_path"], "rb") as pf:
            patched_data = pf.read()

        self.assertIn(b"\x24\x01\x3C\x00\x75\x1A", patched_data)
        self.assertIn(b"\xF6\x41\x00\xFF\x74\x12", patched_data)

        stored_csum = struct.unpack_from("<I", patched_data, 0x80 + 0x58)[0]
        self.assertEqual(stored_csum, patcher.calculate_pe_checksum(patched_data))

        restore_rep = patcher.restore_original_drivers()
        self.assertTrue(restore_rep["ok"])
        self.assertEqual(patcher.compute_sha256(fake_sys_path), hashlib.sha256(raw_pe).hexdigest().lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
