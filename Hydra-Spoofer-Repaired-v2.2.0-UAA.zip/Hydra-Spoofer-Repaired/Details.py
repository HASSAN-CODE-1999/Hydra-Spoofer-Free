import hashlib
import os
import platform
import socket
import subprocess
import sys
import uuid
from typing import Any, Dict, Optional

try:
    import psutil
except ImportError:
    psutil = None

from LoggerManager import DEFAULT_LOGGER, OperationState


def resource_path(relative_path: Optional[str] = None) -> str:
    """Get absolute path to bundled resource, works for dev and PyInstaller/Nuitka onefile mode."""
    if hasattr(sys, "_MEIPASS"):
        base_dir = getattr(sys, "_MEIPASS")
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
    if relative_path:
        cleaned = relative_path.lstrip("/\\")
        return os.path.join(base_dir, cleaned)
    return base_dir


applicationName = "HYDRA SYSTEM IDENTITY MANAGER"
__version__ = "2.1.0-UAA"
imgsPath = os.path.join(resource_path("imgs"), "")
hold_connection_flag = False
kill_switch = False
reg_key_path = rf"SOFTWARE\{applicationName}"
save_user_data = "key"

# Known Sysinternals Volumeid.exe SHA-256 hash bundled with project
EXPECTED_VOLUMEID_SHA256 = "22a2484d7fa799e6e71e310141614884f3bc8dad8ac749b6f1c475b5398a72f3"


def get_subprocess_kwargs() -> Dict[str, Any]:
    """Return platform-safe subprocess flags for hidden window execution on Windows."""
    kwargs: Dict[str, Any] = {}
    if sys.platform.startswith("win"):
        create_no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        kwargs["creationflags"] = create_no_window
        if hasattr(subprocess, "STARTUPINFO"):
            si = subprocess.STARTUPINFO()
            si.dwFlags |= getattr(subprocess, "STARTF_USESHOWWINDOW", 1)
            kwargs["startupinfo"] = si
    return kwargs


def debug_print(*args: Any) -> None:
    msg = " ".join(str(a) for a in args)
    DEFAULT_LOGGER.logger.debug(msg)
    if sys.argv and sys.argv[0].endswith(".py"):
        print(*args)


def get_hwid(real: bool = False, persist_to_registry: bool = False) -> str:
    """
    Safely read hardware identifier without terminating the application on error
    and without modifying the Windows Registry unless explicitly requested.
    """
    raw_data = ""
    if sys.platform.startswith("win"):
        try:
            ps_cmd = (
                "$c = (Get-CimInstance Win32_Processor | Select-Object -First 1).ProcessorId;"
                "$u = (Get-CimInstance Win32_ComputerSystemProduct | Select-Object -First 1).UUID;"
                "$raw = [string]$u + '|' + [string]$c;"
                "Write-Output $raw.Replace(' ', '').ToUpper()"
            )
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                capture_output=True,
                text=True,
                timeout=10,
                check=False,
                **get_subprocess_kwargs(),
            )
            candidate = (result.stdout or "").strip()
            if candidate and len(candidate.replace("|", "")) > 8:
                raw_data = candidate
        except Exception as e:
            DEFAULT_LOGGER.log_operation(
                operation_name="GetHWID",
                target_item="Win32_Processor/Win32_ComputerSystemProduct",
                result=OperationState.FAILED.value,
                exception=e,
            )

    if not raw_data:
        fallback_node = f"{platform.node()}|{platform.machine()}|{uuid.getnode()}"
        raw_data = fallback_node.upper()

    if persist_to_registry and sys.platform.startswith("win"):
        try:
            import DataStoring as DS
            DS.write_to_registry(rf"SOFTWARE\{applicationName}\Cache", "HWIDCache", raw_data)
        except Exception as e:
            debug_print("Optional HWID cache write skipped:", e)

    if real:
        return str(raw_data)
    return hashlib.sha224(raw_data.encode("utf-8")).hexdigest().upper()


def check_network_connectivity(
    local_only: bool = True,
    timeout: float = 3.0,
    max_retries: int = 2,
    include_public_ip: bool = False,
) -> Dict[str, Any]:
    """
    Reliable, non-blocking-friendly network connectivity check.
    - Distinguishes between Local Network (LAN / Wi-Fi / Ethernet link & IPv4) and Internet access.
    - Supports `local_only=True` diagnostic mode that NEVER sends the public IP to external servers.
    - Handles DNS, Timeout, SSL, and HTTPSConnectionPool errors gracefully with bounded retries.
    """
    report: Dict[str, Any] = {
        "local_link_up": False,
        "active_interfaces": [],
        "local_ipv4_addresses": [],
        "dns_working": False,
        "internet_reachable": False,
        "public_ip": None,
        "mode": "local_only" if local_only else "full_internet_check",
        "errors": [],
    }

    virtual_keywords = (
        "vmware",
        "virtualbox",
        "vbox",
        "hyper-v",
        "vethernet",
        "docker",
        "loopback",
        "teredo",
        "isatap",
        "wan miniport",
    )

    try:
        if psutil is not None:
            stats = psutil.net_if_stats()
            addrs = psutil.net_if_addrs()
            for iface, st in stats.items():
                lower_iface = iface.lower()
                if any(vk in lower_iface for vk in virtual_keywords):
                    continue
                if not st.isup:
                    continue
                iface_addrs = addrs.get(iface, [])
                ipv4_list = [
                    a.address
                    for a in iface_addrs
                    if a.family == socket.AF_INET
                    and not a.address.startswith("127.")
                    and not a.address.startswith("169.254.")
                ]
                if ipv4_list:
                    report["local_link_up"] = True
                    report["active_interfaces"].append(iface)
                    report["local_ipv4_addresses"].extend(ipv4_list)
        else:
            host_ip = socket.gethostbyname(socket.gethostname())
            if host_ip and not host_ip.startswith("127."):
                report["local_link_up"] = True
                report["active_interfaces"].append("PrimaryInterface")
                report["local_ipv4_addresses"].append(host_ip)
    except Exception as e:
        report["errors"].append(f"Interface inspection error: {e}")

    if local_only and not include_public_ip:
        return report

    dns_targets = [("1.1.1.1", 53), ("8.8.8.8", 53)]
    for host, port in dns_targets:
        try:
            with socket.create_connection((host, port), timeout=timeout):
                report["internet_reachable"] = True
                break
        except Exception as e:
            report["errors"].append(f"TCP reachability ({host}:{port}) failed: {e}")

    try:
        socket.getaddrinfo("www.microsoft.com", 443, proto=socket.IPPROTO_TCP)
        report["dns_working"] = True
    except Exception as e:
        report["errors"].append(f"DNS resolution failed: {e}")

    if include_public_ip:
        import requests
        from requests.exceptions import ConnectionError as ReqConnError
        from requests.exceptions import RequestException, SSLError, Timeout

        endpoints = [
            "https://api.ipify.org?format=text",
            "https://checkip.amazonaws.com",
            "https://icanhazip.com",
        ]
        attempts = 0
        for url in endpoints:
            if attempts >= max_retries:
                break
            attempts += 1
            try:
                resp = requests.get(url, timeout=timeout)
                if resp.status_code == 200 and resp.text.strip():
                    report["public_ip"] = resp.text.strip()
                    report["internet_reachable"] = True
                    break
            except SSLError as ssl_err:
                report["errors"].append(f"SSL error on {url}: {ssl_err}")
            except Timeout as to_err:
                report["errors"].append(f"Timeout on {url}: {to_err}")
            except ReqConnError as conn_err:
                report["errors"].append(f"ConnectionPool/Network error on {url}: {conn_err}")
            except RequestException as req_err:
                report["errors"].append(f"HTTP request error on {url}: {req_err}")
            except Exception as gen_err:
                report["errors"].append(f"Unexpected error on {url}: {gen_err}")

    return report


def get_public_ip(timeout: float = 3.0, allow_external: bool = False) -> Optional[str]:
    status = check_network_connectivity(
        local_only=not allow_external,
        timeout=timeout,
        max_retries=2,
        include_public_ip=allow_external,
    )
    if allow_external and status.get("public_ip"):
        return status["public_ip"]
    if status.get("local_link_up") and status.get("local_ipv4_addresses"):
        return status["local_ipv4_addresses"][0]
    return None
