import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
from typing import Any, Dict, List, Optional, Tuple

import Details
from LoggerManager import DEFAULT_LOGGER, OperationState


class UAAKernelPatcher:
    r"""
    Multi-Method UAA MAC Address Bypass Engine for Windows Wi-Fi Adapters
    (Specifically engineered for Intel Wi-Fi 6 AX201 v22.70.0.6+ `Netwtw10.sys` and Microsoft `wdiwifi.sys`).

    Why setting `28:98:7B:4A:1F:9C` in Registry alone still shows `20-C1-9B-4C-46-B8` in Windows Settings:
    - Writing `28987B4A1F9C` to Registry (`NetworkAddress`) only stores the requested value in the Registry.
    - When the Intel Wi-Fi driver (`Netwtw10.sys` + `wdiwifi.sys`) restarts, it calls `NdisReadNetworkAddress`
      and checks Bit 1 (`0x02`) of the first byte (`0x28` = `00101000b` -> Bit 1 is `0`).
    - Because the unpatched `.sys` driver in the Windows Kernel rejects any Wi-Fi MAC where Bit 1 is `0`,
      the driver falls back to the factory MAC `20-C1-9B-4C-46-B8` until you either:
        (A) Patch `wdiwifi.sys` & `Netwtw10.sys` via this engine + enable Test Signing + Reboot (with Secure Boot OFF), OR
        (B) Use the Hyper-V External Virtual Bridge (`vEthernet`), OR
        (C) Use a Linux system / USB Wi-Fi adapter / WISP router.
    """

    def __init__(self, backup_dir: str = "backups") -> None:
        self.backup_dir = os.path.join(backup_dir, "drivers")
        os.makedirs(self.backup_dir, exist_ok=True)
        self.manifest_path = os.path.join(self.backup_dir, "driver_patch_manifest.json")

    @staticmethod
    def compute_sha256(file_path: str) -> str:
        h = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest().lower()

    @staticmethod
    def calculate_pe_checksum(data: bytes) -> int:
        """Compute the standard Windows PE OptionalHeader.CheckSum required for kernel `.sys` drivers."""
        if len(data) < 0x40 or data[:2] != b"MZ":
            return 0
        e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
        if e_lfanew + 0x5C > len(data) or data[e_lfanew : e_lfanew + 4] != b"PE\x00\x00":
            return 0

        checksum_offset = e_lfanew + 0x58
        buf = bytearray(data)
        buf[checksum_offset : checksum_offset + 4] = b"\x00\x00\x00\x00"
        if len(buf) % 2 == 1:
            buf.append(0)

        checksum = 0
        mv = memoryview(buf).cast("H")
        for word in mv:
            checksum += word
            checksum = (checksum & 0xFFFF) + (checksum >> 16)

        checksum = (checksum & 0xFFFF) + (checksum >> 16)
        return (checksum + len(data)) & 0xFFFFFFFF

    @classmethod
    def update_pe_checksum_in_bytes(cls, data: bytes) -> bytes:
        if len(data) < 0x40 or data[:2] != b"MZ":
            return data
        e_lfanew = struct.unpack_from("<I", data, 0x3C)[0]
        if e_lfanew + 0x5C > len(data) or data[e_lfanew : e_lfanew + 4] != b"PE\x00\x00":
            return data
        new_sum = cls.calculate_pe_checksum(data)
        out = bytearray(data)
        struct.pack_into("<I", out, e_lfanew + 0x58, new_sum)
        return bytes(out)

    @staticmethod
    def _parse_pe_sections(binary_data: bytes) -> List[Dict[str, int]]:
        """Parse PE64 section headers to map between file offsets and Virtual Addresses (RVA)."""
        sections: List[Dict[str, int]] = []
        if len(binary_data) < 0x100 or binary_data[:2] != b"MZ":
            return sections
        try:
            e_lfanew = struct.unpack_from("<I", binary_data, 0x3C)[0]
            if e_lfanew + 0x18 > len(binary_data) or binary_data[e_lfanew : e_lfanew + 4] != b"PE\x00\x00":
                return sections
            num_sections = struct.unpack_from("<H", binary_data, e_lfanew + 6)[0]
            opt_hdr_size = struct.unpack_from("<H", binary_data, e_lfanew + 20)[0]
            sec_table_off = e_lfanew + 24 + opt_hdr_size
            for i in range(num_sections):
                sh_off = sec_table_off + i * 40
                if sh_off + 40 > len(binary_data):
                    break
                virt_size, virt_addr, raw_size, raw_ptr = struct.unpack_from("<IIII", binary_data, sh_off + 8)
                sections.append(
                    {
                        "virt_addr": virt_addr,
                        "virt_size": max(virt_size, raw_size),
                        "raw_ptr": raw_ptr,
                        "raw_size": raw_size,
                    }
                )
        except Exception:
            pass
        return sections

    @classmethod
    def _offset_to_rva(cls, file_offset: int, sections: List[Dict[str, int]]) -> Optional[int]:
        for s in sections:
            if s["raw_ptr"] <= file_offset < s["raw_ptr"] + s["raw_size"]:
                return s["virt_addr"] + (file_offset - s["raw_ptr"])
        return None

    @classmethod
    def _find_anchor_windows(cls, binary_data: bytes) -> List[Tuple[int, int, str]]:
        """
        Find code windows around RIP-relative references to `NdisReadNetworkAddress` (IAT)
        and `L"NetworkAddress"` (UTF-16LE string) so context-sensitive opcodes (like `test al, 2`)
        can be matched with 100% precision.
        """
        sections = cls._parse_pe_sections(binary_data)
        target_rvas: List[Tuple[int, str]] = []

        # 1. Locate ASCII "NdisReadNetworkAddress" Hint/Name and its 8-byte IAT slot
        for m in re.finditer(b"NdisReadNetworkAddress\\x00", binary_data):
            str_off = m.start()
            str_rva = cls._offset_to_rva(str_off, sections)
            if str_rva is not None and str_rva >= 2:
                hint_name_rva = str_rva - 2
                packed_rva = struct.pack("<Q", hint_name_rva)
                for iat_m in re.finditer(re.escape(packed_rva), binary_data):
                    iat_rva = cls._offset_to_rva(iat_m.start(), sections)
                    if iat_rva is not None:
                        target_rvas.append((iat_rva, "IAT:NdisReadNetworkAddress"))

        # 2. Locate UTF-16LE L"NetworkAddress" string RVA
        utf16_netaddr = "NetworkAddress".encode("utf-16le")
        for m in re.finditer(re.escape(utf16_netaddr), binary_data):
            rva = cls._offset_to_rva(m.start(), sections)
            if rva is not None:
                target_rvas.append((rva, "WSTR:NetworkAddress"))

        windows: List[Tuple[int, int, str]] = []
        if not target_rvas or not sections:
            return windows

        target_map = {rva: label for rva, label in target_rvas}

        # Scan for RIP-relative instructions:
        # - FF 15 <disp32> (call qword ptr [rip+disp32])
        # - 48/4C 8B/8D <modrm> <disp32> (mov/lea reg, [rip+disp32] where modrm & 0xC7 == 0x05)
        for m in re.finditer(rb"(?:\xFF\x15|[\x48\x4C][\x8B\x8D][\x05\x0D\x15\x1D\x25\x2D\x35\x3D])(....)", binary_data, re.DOTALL):
            instr_end_off = m.end()
            disp32 = struct.unpack("<i", m.group(1))[0]
            next_rip_rva = cls._offset_to_rva(instr_end_off, sections)
            if next_rip_rva is None:
                continue
            ref_rva = (next_rip_rva + disp32) & 0xFFFFFFFF
            if ref_rva in target_map:
                w_start = max(0, m.start() - 64)
                w_end = min(len(binary_data), instr_end_off + 384)
                windows.append((w_start, w_end, target_map[ref_rva]))

        return windows

    @classmethod
    def scan_binary_for_uaa_locks(cls, binary_data: bytes) -> Dict[str, Any]:
        """
        Scan a Windows driver binary (`wdiwifi.sys` or `Netwtw10.sys`) for `NdisReadNetworkAddress`
        and all x86_64 LAA Bit-1 (`0x02`) validation opcodes (both global high-confidence patterns
        and XREF-anchored patterns near `NdisReadNetworkAddress` / `L"NetworkAddress"`).
        """
        has_ndis_read = b"NdisReadNetworkAddress" in binary_data
        has_net_addr_str = b"NetworkAddress" in binary_data or "NetworkAddress".encode("utf-16le") in binary_data
        anchor_windows = cls._find_anchor_windows(binary_data)

        matches_by_offset: Dict[int, Dict[str, Any]] = {}

        def _add_match(offset: int, name: str, orig: bytes, patched: bytes, anchored: bool = False) -> None:
            if len(orig) != len(patched):
                return
            if offset not in matches_by_offset or anchored:
                matches_by_offset[offset] = {
                    "offset": offset,
                    "offset_hex": f"0x{offset:08X}",
                    "pattern_name": name + (" [XREF-Anchored]" if anchored else ""),
                    "original_bytes": orig.hex().upper(),
                    "patched_bytes": patched.hex().upper(),
                    "xref_anchored": anchored,
                }

        # --- GLOBAL HIGH-CONFIDENCE PATTERNS (Safe across entire binary) ---
        # 1. `and al, 3; cmp al, 2; jnz/jz` (24 03 3C 02 [75|74|0F84|0F85])
        for m in re.finditer(rb"\x24\x03\x3C\x02(\x75|\x74|\x0F\x84|\x0F\x85)", binary_data, re.DOTALL):
            orig = m.group(0)
            patched = b"\x24\x01\x3C\x00" + m.group(1)
            _add_match(m.start(), "MaskAndCompare_AL_03_02", orig, patched)

        # 2. `and reg8, 3; cmp reg8, 2; jnz/jz`
        pat2 = re.compile(
            rb"([\x40-\x41]?\x80[\xE0-\xE7])\x03([\x40-\x41]?\x80[\xF8-\xFF])\x02(\x75|\x74|\x0F\x84|\x0F\x85)",
            re.DOTALL,
        )
        for m in pat2.finditer(binary_data):
            p1, p2, jmp = m.group(1), m.group(2), m.group(3)
            if (p1[-1] & 0x07) == (p2[-1] & 0x07):
                orig = m.group(0)
                patched = p1 + b"\x01" + p2 + b"\x00" + jmp
                _add_match(m.start(), "MaskAndCompare_Reg8_03_02", orig, patched)

        # 3. `and reg32, 3; cmp reg32, 2; jnz/jz` (83 E0..E7 03 83 F8..FF 02)
        pat3 = re.compile(
            rb"(\x41?\x83[\xE0-\xE7])\x03(\x41?\x83[\xF8-\xFF])\x02(\x75|\x74|\x0F\x84|\x0F\x85)",
            re.DOTALL,
        )
        for m in pat3.finditer(binary_data):
            p1, p2, jmp = m.group(1), m.group(2), m.group(3)
            if (p1[-1] & 0x07) == (p2[-1] & 0x07):
                orig = m.group(0)
                patched = p1 + b"\x01" + p2 + b"\x00" + jmp
                _add_match(m.start(), "MaskAndCompare_Reg32_03_02", orig, patched)

        # 4. `test byte ptr [reg], 2; jz` (F6 00..07 02 [74|0F84])
        for m in re.finditer(rb"(\x41?\xF6[\x00-\x07])\x02(\x74|\x0F\x84)", binary_data, re.DOTALL):
            orig = m.group(0)
            patched = m.group(1) + b"\xFF" + m.group(2)
            _add_match(m.start(), "TestBytePtr_02_JZ", orig, patched)

        # 5. `test byte ptr [reg+disp8], 2; jz` (F6 40..47 disp8 02 [74|0F84])
        for m in re.finditer(rb"(\x41?\xF6[\x40-\x47][\x00-\xFF])\x02(\x74|\x0F\x84)", binary_data, re.DOTALL):
            orig = m.group(0)
            patched = m.group(1) + b"\xFF" + m.group(2)
            _add_match(m.start(), "TestBytePtrDisp8_02_JZ", orig, patched)

        # 6. `bt reg, 1; jb/jnc` (0F BA E0..E7 01 [72|0F82])
        for m in re.finditer(rb"(\x41?\x0F\xBA[\xE0-\xE7])\x01(\x72|\x0F\x82)", binary_data, re.DOTALL):
            orig = m.group(0)
            patched = m.group(1) + b"\x01\x90\x90"
            _add_match(m.start(), "BitTest_01_JNC", orig, patched)

        # --- XREF-ANCHORED PATTERNS (Inside NdisReadNetworkAddress / L"NetworkAddress" windows) ---
        for w_start, w_end, w_label in anchor_windows:
            chunk = binary_data[w_start:w_end]

            # A. `test al, 2; jz/jnz` (A8 02 [74|0F84])
            for m in re.finditer(rb"\xA8\x02(\x74|\x0F\x84)", chunk, re.DOTALL):
                orig = m.group(0)
                patched = b"\xA8\xFF" + m.group(1)
                _add_match(w_start + m.start(), f"TestAL_02_JZ ({w_label})", orig, patched, anchored=True)

            # B. `test reg8, 2; jz` ([40-41]? F6 C0..C7 02 [74|0F84])
            for m in re.finditer(rb"([\x40-\x41]?\xF6[\xC0-\xC7])\x02(\x74|\x0F\x84)", chunk, re.DOTALL):
                orig = m.group(0)
                patched = m.group(1) + b"\xFF" + m.group(2)
                _add_match(w_start + m.start(), f"TestReg8_02_JZ ({w_label})", orig, patched, anchored=True)

            # C. `test byte ptr [rsp+disp8], 2; jz` (F6 44 24 disp8 02 [74|0F84])
            for m in re.finditer(rb"(\xF6\x44\x24[\x00-\xFF])\x02(\x74|\x0F\x84)", chunk, re.DOTALL):
                orig = m.group(0)
                patched = m.group(1) + b"\xFF" + m.group(2)
                _add_match(w_start + m.start(), f"TestStackByte_02_JZ ({w_label})", orig, patched, anchored=True)

            # D. `test byte ptr [reg+disp32], 2; jz` (F6 80..87 disp32 02 [74|0F84])
            for m in re.finditer(rb"(\x41?\xF6[\x80-\x87]....)\x02(\x74|\x0F\x84)", chunk, re.DOTALL):
                orig = m.group(0)
                patched = m.group(1) + b"\xFF" + m.group(2)
                _add_match(w_start + m.start(), f"TestByteDisp32_02_JZ ({w_label})", orig, patched, anchored=True)

            # E. Instruction-scheduled `and al/reg8, 3 ... cmp al/reg8, 2` with up to 10 bytes in between
            for m in re.finditer(rb"\x24\x03(.{0,10}?)\x3C\x02(\x75|\x74|\x0F\x84|\x0F\x85)", chunk, re.DOTALL):
                orig = m.group(0)
                patched = b"\x24\x01" + m.group(1) + b"\x3C\x00" + m.group(2)
                _add_match(w_start + m.start(), f"Scheduled_AL_03_02 ({w_label})", orig, patched, anchored=True)

        matches = [matches_by_offset[k] for k in sorted(matches_by_offset.keys())]
        return {
            "imports_ndis_read_network_address": has_ndis_read,
            "references_network_address_key": has_net_addr_str,
            "xref_anchor_windows_found": len(anchor_windows),
            "match_count": len(matches),
            "matches": matches,
        }

    @classmethod
    def patch_driver_bytes(cls, binary_data: bytes, target_offsets: Optional[List[int]] = None) -> Tuple[bytes, List[Dict[str, Any]]]:
        """Apply the UAA Bit-1 bypass patch and recalculate the PE header checksum."""
        scan = cls.scan_binary_for_uaa_locks(binary_data)
        buf = bytearray(binary_data)
        applied: List[Dict[str, Any]] = []

        # If XREF-anchored matches exist, prioritize them; otherwise apply all matches
        anchored_matches = [m for m in scan["matches"] if m.get("xref_anchored")]
        candidates = anchored_matches if (anchored_matches and target_offsets is None) else scan["matches"]

        for m in candidates:
            off = m["offset"]
            if target_offsets is not None and off not in target_offsets:
                continue
            orig_bytes = bytes.fromhex(m["original_bytes"])
            patch_bytes = bytes.fromhex(m["patched_bytes"])
            if bytes(buf[off : off + len(orig_bytes)]) == orig_bytes and len(orig_bytes) == len(patch_bytes):
                buf[off : off + len(orig_bytes)] = patch_bytes
                applied.append(m)

        final_bytes = cls.update_pe_checksum_in_bytes(bytes(buf))
        return final_bytes, applied

    def check_boot_and_signing_status(self) -> Dict[str, Any]:
        """Check whether Windows Test Signing is ON and whether UEFI Secure Boot is blocking unsigned/test-signed drivers."""
        status: Dict[str, Any] = {
            "testsigning_enabled": False,
            "nointegritychecks_enabled": False,
            "secure_boot_enabled": None,
            "ready_for_patched_driver": False,
            "instructions": [],
        }
        if not sys.platform.startswith("win"):
            return status

        try:
            bcd = subprocess.run(
                ["bcdedit", "/enum", "{current}"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
                check=False,
                **Details.get_subprocess_kwargs(),
            )
            bcd_out = (bcd.stdout or "").lower()
            status["testsigning_enabled"] = bool(re.search(r"testsigning\s+yes", bcd_out))
            status["nointegritychecks_enabled"] = bool(re.search(r"nointegritychecks\s+yes", bcd_out))
        except Exception:
            pass

        try:
            sb = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", "Confirm-SecureBootUEFI"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
                check=False,
                **Details.get_subprocess_kwargs(),
            )
            sb_out = (sb.stdout or "").strip().lower()
            if "true" in sb_out:
                status["secure_boot_enabled"] = True
            elif "false" in sb_out:
                status["secure_boot_enabled"] = False
        except Exception:
            pass

        if status["secure_boot_enabled"] is True:
            status["instructions"].append(
                "CRITICAL: UEFI Secure Boot is currently ON. You MUST enter BIOS (press F10 on HP Laptop at boot) "
                "and set Secure Boot = Disabled so Windows allows Test Signing and patched Netwtw10.sys / wdiwifi.sys!"
            )
        if not status["testsigning_enabled"]:
            status["instructions"].append(
                "Test Signing is currently OFF (or pending reboot). Click '2. Patch wdiwifi/Netwtw' to enable it, then Restart Windows."
            )
        status["ready_for_patched_driver"] = (status["secure_boot_enabled"] is not True) and status["testsigning_enabled"]
        return status

    def locate_wifi_driver_files(self) -> List[str]:
        r"""Locate `wdiwifi.sys` and Intel `Netwtw*.sys` inside Windows System32\drivers and DriverStore\FileRepository."""
        sys_root = os.environ.get("SystemRoot", r"C:\Windows")
        drv_dir = os.path.join(sys_root, "System32", "drivers")
        candidates = [
            "wdiwifi.sys",
            "Netwtw10.sys",
            "Netwtw12.sys",
            "Netwtw14.sys",
            "Netwtw08.sys",
            "Netwtw06.sys",
            "Netwtw6e.sys",
            "nwifi.sys",
        ]
        found: List[str] = []
        seen_realpaths = set()

        def _add(p: str) -> None:
            if p and os.path.isfile(p):
                rp = os.path.normcase(os.path.abspath(p))
                if rp not in seen_realpaths:
                    seen_realpaths.add(rp)
                    found.append(p)

        for name in candidates:
            _add(os.path.join(drv_dir, name))

        # Check active service ImagePath in Registry (for DCH drivers stored in DriverStore\FileRepository)
        if sys.platform.startswith("win"):
            try:
                import winreg
                for svc_name in ("Netwtw10", "Netwtw12", "Netwtw14", "Netwtw08", "Netwtw06", "Netwtw6e", "wdiwifi"):
                    try:
                        k = winreg.OpenKey(
                            winreg.HKEY_LOCAL_MACHINE,
                            rf"SYSTEM\CurrentControlSet\Services\{svc_name}",
                            0,
                            winreg.KEY_READ,
                        )
                        img_path, _ = winreg.QueryValueEx(k, "ImagePath")
                        winreg.CloseKey(k)
                        if img_path:
                            cleaned = str(img_path).strip().lstrip("\\?")
                            if cleaned.lower().startswith("systemroot\\"):
                                cleaned = os.path.join(sys_root, cleaned[len("systemroot\\") :])
                            elif cleaned.lower().startswith("system32\\"):
                                cleaned = os.path.join(sys_root, cleaned)
                            _add(cleaned)
                    except Exception:
                        pass
            except Exception:
                pass

        # Also scan DriverStore\FileRepository\netwtw* for the active Intel Netwtw*.sys binary
        repo_dir = os.path.join(sys_root, "System32", "DriverStore", "FileRepository")
        if os.path.isdir(repo_dir):
            try:
                for entry in os.listdir(repo_dir):
                    if entry.lower().startswith("netwtw"):
                        sub = os.path.join(repo_dir, entry)
                        if os.path.isdir(sub):
                            for fn in os.listdir(sub):
                                if fn.lower().startswith("netwtw") and fn.lower().endswith(".sys"):
                                    _add(os.path.join(sub, fn))
            except Exception:
                pass

        return found

    def scan_system_wifi_drivers(self) -> Dict[str, Any]:
        files = self.locate_wifi_driver_files()
        results: Dict[str, Any] = {
            "boot_and_signing_status": self.check_boot_and_signing_status(),
            "drivers": {},
        }
        for fpath in files:
            try:
                with open(fpath, "rb") as f:
                    data = f.read()
                scan_info = self.scan_binary_for_uaa_locks(data)
                scan_info["file_path"] = fpath
                scan_info["size_bytes"] = len(data)
                scan_info["sha256"] = hashlib.sha256(data).hexdigest().lower()
                results["drivers"][os.path.basename(fpath)] = scan_info
            except Exception as e:
                results["drivers"][os.path.basename(fpath)] = {"file_path": fpath, "error": str(e)}
        return results

    def backup_and_patch_driver_file(self, driver_path: str, apply_in_place: bool = False) -> Dict[str, Any]:
        """
        Safely back up a `.sys` driver file with SHA-256 verification, generate the patched `.sys` binary
        with updated PE checksum, self-sign it, and replace it in System32\\drivers (using atomic rename
        so Windows NTFS allows replacing an active in-memory `.sys` driver without Sharing Violation).
        """
        if not os.path.isfile(driver_path):
            return {"ok": False, "error": f"Driver file not found: {driver_path}"}

        base_name = os.path.basename(driver_path)
        orig_sha = self.compute_sha256(driver_path)
        backup_file = os.path.join(self.backup_dir, f"{base_name}.orig.bak")
        patched_out = os.path.join(self.backup_dir, f"{base_name}.uaa_patched.sys")

        if not os.path.exists(backup_file):
            shutil.copy2(driver_path, backup_file)
            bkp_sha = self.compute_sha256(backup_file)
            if bkp_sha != orig_sha:
                return {"ok": False, "error": "Backup SHA-256 verification failed. Aborting."}

        with open(backup_file, "rb") as f:
            orig_bytes = f.read()

        patched_bytes, applied_patches = self.patch_driver_bytes(orig_bytes)
        if not applied_patches:
            return {
                "ok": False,
                "driver": base_name,
                "backup_path": backup_file,
                "error": f"No UAA Bit-1 lock sequence matched in {base_name}.",
            }

        with open(patched_out, "wb") as f:
            f.write(patched_bytes)

        patched_sha = self.compute_sha256(patched_out)
        pe_checksum = self.calculate_pe_checksum(patched_bytes)

        manifest: Dict[str, Any] = {}
        if os.path.exists(self.manifest_path):
            try:
                with open(self.manifest_path, "r", encoding="utf-8") as mf:
                    manifest = json.load(mf)
            except Exception:
                manifest = {}

        manifest[base_name] = {
            "target_path": driver_path,
            "backup_path": backup_file,
            "original_sha256": self.compute_sha256(backup_file),
            "patched_staging_path": patched_out,
            "patched_sha256": patched_sha,
            "pe_checksum_hex": f"0x{pe_checksum:08X}",
            "applied_patches": applied_patches,
        }
        with open(self.manifest_path, "w", encoding="utf-8") as mf:
            json.dump(manifest, mf, indent=2)

        result: Dict[str, Any] = {
            "ok": True,
            "driver": base_name,
            "backup_path": backup_file,
            "patched_staging_path": patched_out,
            "patched_sha256": patched_sha,
            "pe_checksum_hex": f"0x{pe_checksum:08X}",
            "applied_patches_count": len(applied_patches),
            "applied_patches": applied_patches,
            "installed_in_system32": False,
        }

        if apply_in_place and sys.platform.startswith("win"):
            try:
                # 1. Self-sign the staged driver so Windows Test Signing accepts it
                sign_ps = (
                    r"$cert = Get-ChildItem Cert:\LocalMachine\My -CodeSigningCert | "
                    "Where-Object { $_.Subject -like '*HydraUAADriverCert*' } | Select-Object -First 1; "
                    "if (-not $cert) { "
                    "  $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject 'CN=HydraUAADriverCert' "
                    r"  -CertStoreLocation Cert:\LocalMachine\My; "
                    "  $rootStore = New-Object System.Security.Cryptography.X509Certificates.X509Store('Root','LocalMachine'); "
                    "  $rootStore.Open('ReadWrite'); $rootStore.Add($cert); $rootStore.Close(); "
                    "  $pubStore = New-Object System.Security.Cryptography.X509Certificates.X509Store('TrustedPublisher','LocalMachine'); "
                    "  $pubStore.Open('ReadWrite'); $pubStore.Add($cert); $pubStore.Close(); "
                    "} "
                    f"Set-AuthenticodeSignature -FilePath '{patched_out.replace(chr(39), chr(39)*2)}' -Certificate $cert | Out-Null"
                )
                subprocess.run(
                    ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", sign_ps],
                    capture_output=True,
                    text=True,
                    timeout=20,
                    check=False,
                    **Details.get_subprocess_kwargs(),
                )
                # 2. Enable Test Signing in BCD
                bcd1 = subprocess.run(["bcdedit", "/set", "testsigning", "on"], capture_output=True, text=True, timeout=10, check=False, **Details.get_subprocess_kwargs())
                subprocess.run(["bcdedit", "/set", "nointegritychecks", "on"], capture_output=True, text=True, timeout=10, check=False, **Details.get_subprocess_kwargs())
                result["bcdedit_output"] = ((bcd1.stdout or "") + " " + (bcd1.stderr or "")).strip()

                # 3. Take ownership of target driver in System32\drivers
                subprocess.run(["takeown", "/f", driver_path], capture_output=True, timeout=10, check=False, **Details.get_subprocess_kwargs())
                subprocess.run(["icacls", driver_path, "/grant", "Administrators:F"], capture_output=True, timeout=10, check=False, **Details.get_subprocess_kwargs())
                subprocess.run(["icacls", driver_path, "/grant", "*S-1-5-32-544:F"], capture_output=True, timeout=10, check=False, **Details.get_subprocess_kwargs())

                # 4. Rename active driver in-place first (bypasses NTFS Sharing Violation on loaded .sys files!)
                old_active = driver_path + ".old_active"
                if os.path.exists(old_active):
                    try:
                        os.remove(old_active)
                    except OSError:
                        pass
                try:
                    os.replace(driver_path, old_active)
                except OSError:
                    pass

                shutil.copy2(patched_out, driver_path)
                result["installed_in_system32"] = True
                result["next_step"] = "IMPORTANT: Restart Windows now (with Secure Boot OFF in BIOS) so the patched driver loads!"
            except Exception as e:
                result["install_warning"] = (
                    f"Patched file generated at '{patched_out}', but live replacement in System32 encountered: {e}. "
                    "Make sure Secure Boot is Disabled in BIOS, disable Wi-Fi adapter temporarily, and click Patch again."
                )

        DEFAULT_LOGGER.log_operation(
            operation_name="PatchWiFiDriverUAA",
            target_item=base_name,
            previous_value=orig_sha[:16],
            new_value=patched_sha[:16],
            result=OperationState.REQUIRES_RESTART.value if result["installed_in_system32"] else OperationState.COMPLETED.value,
        )
        return result

    def restore_original_drivers(self) -> Dict[str, Any]:
        """Restore original signed `.sys` drivers from `backups/drivers/` and verify SHA-256."""
        if not os.path.exists(self.manifest_path):
            return {"ok": False, "message": "No driver patch manifest found in backups/drivers/."}

        with open(self.manifest_path, "r", encoding="utf-8") as mf:
            manifest = json.load(mf)

        restored: List[str] = []
        errors: List[str] = []
        for drv_name, info in manifest.items():
            bkp = info.get("backup_path")
            target = info.get("target_path")
            expected_sha = info.get("original_sha256")
            if not bkp or not os.path.isfile(bkp):
                errors.append(f"{drv_name}: Backup file missing ({bkp})")
                continue
            if expected_sha and self.compute_sha256(bkp) != expected_sha:
                errors.append(f"{drv_name}: Backup SHA-256 mismatch!")
                continue
            try:
                if target and os.path.exists(os.path.dirname(target)):
                    old_active = target + ".old_active"
                    if os.path.exists(old_active):
                        try:
                            os.remove(old_active)
                        except OSError:
                            pass
                    try:
                        os.replace(target, old_active)
                    except OSError:
                        pass
                    shutil.copy2(bkp, target)
                restored.append(drv_name)
            except Exception as e:
                errors.append(f"{drv_name}: {e}")

        return {
            "ok": len(errors) == 0 and len(restored) > 0,
            "restored": restored,
            "errors": errors,
            "message": f"Restored original signed drivers: {', '.join(restored)}" if restored else "; ".join(errors),
        }

    @staticmethod
    def configure_hyperv_uaa_bridge(wifi_adapter_description: str, target_uaa_mac: str) -> Tuple[bool, str]:
        """
        Create or update an External Hyper-V Virtual Switch (`vEthernet (Hydra-UAA-Bridge)`)
        bound to the Wi-Fi adapter and assign the exact UAA MAC (`28:98:7B:4A:1F:9C`) to the
        virtual switch adapter (which uses `vmswitch.sys` 802.3 and does NOT enforce the 2,6,A,E rule).
        """
        clean_mac = target_uaa_mac.replace(":", "").replace("-", "").strip().upper()
        if len(clean_mac) != 12:
            return False, f"Invalid 12-hex MAC address: {target_uaa_mac}"

        if not sys.platform.startswith("win"):
            return False, "Hyper-V Virtual Bridge requires Windows 10/11 Pro/Enterprise."

        escaped_desc = wifi_adapter_description.replace("'", "''")
        ps_script = (
            "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
            "$ErrorActionPreference = 'Stop'; "
            "if (-not (Get-Command New-VMSwitch -ErrorAction SilentlyContinue)) { "
            "  Write-Output 'ERROR: Hyper-V PowerShell module is not installed/enabled on this Windows edition. "
            "Use Button 2 (Patch wdiwifi/Netwtw + Restart with Secure Boot OFF) instead.'; exit 2 "
            "} "
            "$swName = 'Hydra-UAA-Bridge'; "
            "$existing = Get-VMSwitch -Name $swName -ErrorAction SilentlyContinue; "
            "if (-not $existing) { "
            f"  New-VMSwitch -Name $swName -NetAdapterInterfaceDescription '{escaped_desc}' -AllowManagementOS $true | Out-Null; "
            "} "
            "$vNic = Get-NetAdapter | Where-Object { $_.Name -like '*Hydra-UAA-Bridge*' -or $_.InterfaceDescription -like '*Hyper-V Virtual Ethernet*' } | Select-Object -First 1; "
            "if ($vNic) { "
            f"  Set-NetAdapterAdvancedProperty -Name $vNic.Name -RegistryKeyword 'NetworkAddress' -RegistryValue '{clean_mac}' -ErrorAction SilentlyContinue; "
            f"  Set-NetAdapter -Name $vNic.Name -MacAddress '{clean_mac}' -Confirm:$false -ErrorAction SilentlyContinue; "
            "  Restart-NetAdapter -Name $vNic.Name -Confirm:$false; "
            "  Write-Output ('SUCCESS: ' + $vNic.Name + ' -> ' + (Get-NetAdapter -Name $vNic.Name).MacAddress); "
            "} else { Write-Output 'ERROR: Virtual adapter not found after creating VMSwitch.'; exit 3 }"
        )
        try:
            res = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=35,
                check=False,
                **Details.get_subprocess_kwargs(),
            )
            out = ((res.stdout or "") + " " + (res.stderr or "")).strip()
            if res.returncode == 0 and "SUCCESS:" in out:
                return True, out
            return False, out or f"Hyper-V command exited with code {res.returncode}"
        except Exception as e:
            return False, f"Failed configuring Hyper-V UAA Bridge: {e}"
